import { EventEmitter } from "events";
import type { Response } from "express";

// ── SSE broadcast registry ────────────────────────────────────────────────────
// Each connected client gets an Express Response object stored here.
// When an urgent/emergency request is created, we fan-out to all clients.

const clients = new Set<Response>();

export const sseEmitter = new EventEmitter();
sseEmitter.setMaxListeners(500);

/** Register a new SSE client (res must already have SSE headers set). */
export function addSSEClient(res: Response): void {
  clients.add(res);
}

/** Remove a client (call on request "close" event). */
export function removeSSEClient(res: Response): void {
  clients.delete(res);
}

/** Broadcast a JSON payload to every connected SSE client. */
export function broadcastSSE(event: string, data: unknown): void {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of clients) {
    try {
      res.write(payload);
    } catch {
      clients.delete(res);
    }
  }
}

/** How many clients are currently connected. */
export function sseClientCount(): number {
  return clients.size;
}
