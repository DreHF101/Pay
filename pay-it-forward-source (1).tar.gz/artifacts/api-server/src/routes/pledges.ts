import { Router } from "express";
import { db, pledgesTable, pledgeRepaymentsTable, jobsTable, requestsTable, usersTable, communityFundTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

const router = Router();

async function enrichPledge(p: typeof pledgesTable.$inferSelect) {
  const repayments = await db
    .select()
    .from(pledgeRepaymentsTable)
    .where(eq(pledgeRepaymentsTable.pledge_id, p.id));

  const [job] = await db.select().from(jobsTable).where(eq(jobsTable.id, p.source_job_id)).limit(1);
  let sourceRequestTitle: string | null = null;
  if (job) {
    const [req] = await db.select().from(requestsTable).where(eq(requestsTable.id, job.request_id)).limit(1);
    sourceRequestTitle = req?.title ?? null;
  }

  return { ...p, repayments, source_request_title: sourceRequestTitle };
}

router.get("/mine", async (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: "Not authenticated" });

  const pledges = await db
    .select()
    .from(pledgesTable)
    .where(eq(pledgesTable.user_id, req.session.userId));

  const enriched = await Promise.all(pledges.map(enrichPledge));

  const open = enriched.filter((p) => p.status !== "fulfilled");
  const totalOwed = open.reduce((a, p) => a + (p.original_amount - p.amount_returned), 0);
  const lifetimeReceived = enriched.reduce((a, p) => a + p.original_amount, 0);
  const lifetimeRepaid = enriched.reduce((a, p) => a + p.amount_returned, 0);

  return res.json({
    pledges: enriched,
    open_count: open.length,
    total_owed: totalOwed,
    lifetime_received: lifetimeReceived,
    lifetime_repaid: lifetimeRepaid,
  });
});

router.post("/:id/repay", async (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: "Not authenticated" });
  const id = parseInt(req.params["id"] ?? "");
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });

  const [pledge] = await db
    .select()
    .from(pledgesTable)
    .where(and(eq(pledgesTable.id, id), eq(pledgesTable.user_id, req.session.userId)))
    .limit(1);
  if (!pledge) return res.status(404).json({ error: "Pledge not found" });

  const { amount, note } = req.body as { amount: number; note?: string };
  if (!amount || amount <= 0) return res.status(400).json({ error: "amount must be positive" });

  await db.insert(pledgeRepaymentsTable).values({
    pledge_id: id,
    amount,
    note: note ?? null,
  });

  const newAmountReturned = pledge.amount_returned + amount;
  const status = newAmountReturned >= pledge.original_amount ? "fulfilled" : "partial";

  await db
    .update(pledgesTable)
    .set({ amount_returned: newAmountReturned, status })
    .where(eq(pledgesTable.id, id));

  // Return to community fund
  const [fund] = await db.select().from(communityFundTable).limit(1);
  if (fund) {
    await db
      .update(communityFundTable)
      .set({ balance: fund.balance + amount, total_contributed: fund.total_contributed + amount })
      .where(eq(communityFundTable.id, fund.id));
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.session.userId)).limit(1);
  if (user) {
    await db
      .update(usersTable)
      .set({ pay_forward_total: user.pay_forward_total + amount })
      .where(eq(usersTable.id, user.id));
  }

  return res.json({ message: "Repayment recorded", new_balance: fund ? fund.balance + amount : amount });
});

export default router;
