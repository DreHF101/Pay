import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import requestsRouter from "./requests";
import jobsRouter from "./jobs";
import communityRouter from "./community";
import pledgesRouter from "./pledges";
import notificationsRouter from "./notifications";
import gratitudeRouter from "./gratitude";
import leaderboardRouter from "./leaderboard";
import helpersRouter from "./helpers";
import eventsRouter from "./events";
import seedRouter from "./seed";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/users", usersRouter);
router.use("/helpers", helpersRouter);
router.use("/requests", requestsRouter);
router.use("/jobs", jobsRouter);
router.use("/community", communityRouter);
router.use("/pledges", pledgesRouter);
router.use("/notifications", notificationsRouter);
router.use("/gratitude", gratitudeRouter);
router.use("/leaderboard", leaderboardRouter);
router.use("/events", eventsRouter);
router.use("/dev", seedRouter);

export default router;
