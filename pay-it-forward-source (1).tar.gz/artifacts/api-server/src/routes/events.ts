import { Router } from "express";
import { addSSEClient, removeSSEClient, sseClientCount } from "../lib/sseEmitter";

const router = Router();

/**
 * GET /api/events/stream
 *
 * Server-Sent Events endpoint.  Clients subscribe here to receive real-time
 * push events (new urgent/emergency requests, etc.) without polling.
 *
 * No auth required — event payloads contain only public request data.
 */
router.get("/stream", (req, res) => {
  // SSE headers
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no"); // Disable nginx buffering
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.flushHeaders();

  // Initial connected confirmation
  res.write(": connected\n\n");

  // Send current client count as info event
  res.write(`event: info\ndata: ${JSON.stringify({ clients: sseClientCount() + 1, message: "Connected to Pay It Forward live alerts" })}\n\n`);

  addSSEClient(res);

  // Heartbeat every 25s to keep connection alive through proxies
  const heartbeat = setInterval(() => {
    try {
      res.write(": ping\n\n");
    } catch {
      clearInterval(heartbeat);
    }
  }, 25_000);

  req.on("close", () => {
    clearInterval(heartbeat);
    removeSSEClient(res);
  });

  req.on("error", () => {
    clearInterval(heartbeat);
    removeSSEClient(res);
  });
});

export default router;
