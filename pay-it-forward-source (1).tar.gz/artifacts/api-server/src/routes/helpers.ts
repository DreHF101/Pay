import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq, and, like } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  const { availability, service } = req.query as Record<string, string | undefined>;

  const conditions = [];
  if (availability) conditions.push(eq(usersTable.availability, availability));

  const helpers = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      avatar_initials: usersTable.avatar_initials,
      avatar_color: usersTable.avatar_color,
      neighborhood: usersTable.neighborhood,
      availability: usersTable.availability,
      service_radius: usersTable.service_radius,
      services_offered: usersTable.services_offered,
      help_count: usersTable.help_count,
      trust_level: usersTable.trust_level,
      is_verified: usersTable.is_verified,
    })
    .from(usersTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .limit(50);

  let results = helpers;
  if (service) {
    results = helpers.filter((h) => h.services_offered && h.services_offered.includes(service));
  }

  return res.json(results);
});

export default router;
