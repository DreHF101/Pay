import { Router } from "express";
import { db, jobsTable, requestsTable, usersTable, notificationsTable, pledgesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

const router = Router();

async function enrichJob(job: typeof jobsTable.$inferSelect) {
  const [req] = await db
    .select()
    .from(requestsTable)
    .where(eq(requestsTable.id, job.request_id))
    .limit(1);

  const [helper] = await db
    .select({ name: usersTable.name })
    .from(usersTable)
    .where(eq(usersTable.id, job.helper_id))
    .limit(1);

  let requesterName: string | null = null;
  if (req) {
    const [requester] = await db
      .select({ name: usersTable.name })
      .from(usersTable)
      .where(eq(usersTable.id, req.requester_id))
      .limit(1);
    requesterName = req.is_anonymous ? "Anonymous" : (requester?.name ?? null);
  }

  return {
    ...job,
    completed_at: job.completed_at ? job.completed_at.toISOString() : null,
    request_title: req?.title ?? null,
    request_description: req?.description ?? null,
    request_category: req?.category ?? null,
    request_urgency: req?.urgency ?? null,
    request_funding_source: req?.funding_source ?? null,
    request_neighborhood: req?.neighborhood ?? null,
    helper_name: helper?.name ?? null,
    requester_name: requesterName,
    budget: req?.budget ?? null,
  };
}

router.get("/", async (req, res) => {
  const { request_id, helper_id, status } = req.query as Record<string, string | undefined>;
  const conditions = [];
  if (request_id) conditions.push(eq(jobsTable.request_id, parseInt(request_id)));
  if (helper_id) conditions.push(eq(jobsTable.helper_id, parseInt(helper_id)));
  if (status) conditions.push(eq(jobsTable.status, status));

  const jobs = await db
    .select()
    .from(jobsTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(jobsTable.created_at)
    .limit(100);

  const enriched = await Promise.all(jobs.map(enrichJob));
  return res.json(enriched);
});

router.post("/", async (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: "Not authenticated" });
  const { request_id } = req.body as { request_id: number };
  if (!request_id) return res.status(400).json({ error: "request_id required" });

  // Verify request exists
  const [helpReq] = await db
    .select()
    .from(requestsTable)
    .where(eq(requestsTable.id, request_id))
    .limit(1);
  if (!helpReq) return res.status(404).json({ error: "Request not found" });
  if (helpReq.requester_id === req.session.userId) {
    return res.status(400).json({ error: "Cannot claim your own request" });
  }

  // Check not already claimed
  const [existing] = await db
    .select()
    .from(jobsTable)
    .where(
      and(
        eq(jobsTable.request_id, request_id),
        eq(jobsTable.helper_id, req.session.userId)
      )
    )
    .limit(1);
  if (existing) return res.status(409).json({ error: "Already claimed" });

  const [job] = await db
    .insert(jobsTable)
    .values({ request_id, helper_id: req.session.userId, status: "accepted" })
    .returning();
  if (!job) return res.status(500).json({ error: "Failed to create job" });

  // Update request status to in_progress
  await db.update(requestsTable).set({ status: "in_progress" }).where(eq(requestsTable.id, request_id));

  // Notify requester
  await db.insert(notificationsTable).values({
    user_id: helpReq.requester_id,
    type: "helper_claimed",
    title: "Helper On The Way!",
    message: `Someone has accepted your request: "${helpReq.title}".`,
    related_id: job.id,
    related_type: "job",
  });

  return res.status(201).json(await enrichJob(job));
});

router.get("/:id", async (req, res) => {
  const id = parseInt(req.params["id"] ?? "");
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  const [job] = await db.select().from(jobsTable).where(eq(jobsTable.id, id)).limit(1);
  if (!job) return res.status(404).json({ error: "Job not found" });
  return res.json(await enrichJob(job));
});

router.patch("/:id", async (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: "Not authenticated" });
  const id = parseInt(req.params["id"] ?? "");
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });

  const [job] = await db.select().from(jobsTable).where(eq(jobsTable.id, id)).limit(1);
  if (!job) return res.status(404).json({ error: "Job not found" });
  if (job.helper_id !== req.session.userId) return res.status(403).json({ error: "Forbidden" });

  const { status, notes } = req.body as { status?: string; notes?: string };
  const updates: Partial<typeof jobsTable.$inferInsert> = {};
  if (typeof status === "string") updates.status = status;
  if (typeof notes === "string") updates.notes = notes;
  if (status === "completed") updates.completed_at = new Date();
  updates.updated_at = new Date();

  const [updated] = await db.update(jobsTable).set(updates).where(eq(jobsTable.id, id)).returning();
  if (!updated) return res.status(404).json({ error: "Job not found" });

  // On completion: update request, increment help_count, create pledge if community_fund
  if (status === "completed") {
    const [helpReq] = await db
      .select()
      .from(requestsTable)
      .where(eq(requestsTable.id, job.request_id))
      .limit(1);
    if (helpReq) {
      await db
        .update(requestsTable)
        .set({ status: "completed" })
        .where(eq(requestsTable.id, job.request_id));

      const [helper] = await db
        .select()
        .from(usersTable)
        .where(eq(usersTable.id, job.helper_id))
        .limit(1);
      if (helper) {
        await db
          .update(usersTable)
          .set({
            help_count: helper.help_count + 1,
            volunteer_hours: helper.volunteer_hours + 1,
          })
          .where(eq(usersTable.id, helper.id));
      }

      // Create pledge if funded from community fund
      if (helpReq.funding_source === "community_fund" && helpReq.budget) {
        await db.insert(pledgesTable).values({
          user_id: helpReq.requester_id,
          source_job_id: job.id,
          original_amount: helpReq.budget,
          repayment_timeline: helpReq.repayment_timeline ?? "when able",
        });
      }

      // Notify requester
      await db.insert(notificationsTable).values({
        user_id: helpReq.requester_id,
        type: "job_completed",
        title: "Help Completed!",
        message: `Your request "${helpReq.title}" has been marked complete.`,
        related_id: job.id,
        related_type: "job",
      });
    }
  }

  return res.json(await enrichJob(updated));
});

export default router;
