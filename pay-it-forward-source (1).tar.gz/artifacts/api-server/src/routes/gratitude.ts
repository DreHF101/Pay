import { Router } from "express";
import { db, gratitudeTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

async function enrichGratitude(g: typeof gratitudeTable.$inferSelect) {
  const [from] = await db
    .select({ name: usersTable.name, avatar_color: usersTable.avatar_color })
    .from(usersTable)
    .where(eq(usersTable.id, g.from_user_id))
    .limit(1);

  let toUserName: string | null = null;
  if (g.to_user_id) {
    const [to] = await db
      .select({ name: usersTable.name })
      .from(usersTable)
      .where(eq(usersTable.id, g.to_user_id))
      .limit(1);
    toUserName = to?.name ?? null;
  }

  return {
    ...g,
    from_user_name: from?.name ?? null,
    from_user_avatar_color: from?.avatar_color ?? null,
    to_user_name: toUserName,
  };
}

router.get("/", async (req, res) => {
  const { request_id } = req.query as { request_id?: string };

  let rows;
  if (request_id) {
    rows = await db
      .select()
      .from(gratitudeTable)
      .where(eq(gratitudeTable.request_id, parseInt(request_id)));
  } else {
    rows = await db.select().from(gratitudeTable).where(eq(gratitudeTable.is_public, true)).limit(50);
  }

  const enriched = await Promise.all(rows.map(enrichGratitude));
  return res.json(enriched);
});

router.post("/", async (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: "Not authenticated" });

  const { request_id, to_user_id, message, is_public } = req.body as {
    request_id: number;
    to_user_id?: number | null;
    message: string;
    is_public?: boolean;
  };

  if (!request_id || !message) return res.status(400).json({ error: "request_id and message required" });

  const [created] = await db
    .insert(gratitudeTable)
    .values({
      request_id,
      from_user_id: req.session.userId,
      to_user_id: to_user_id ?? null,
      message,
      is_public: is_public !== false,
    })
    .returning();

  if (!created) return res.status(500).json({ error: "Failed to create gratitude" });
  return res.status(201).json(await enrichGratitude(created));
});

export default router;
