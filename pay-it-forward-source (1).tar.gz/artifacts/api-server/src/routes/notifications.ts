import { Router } from "express";
import { db, notificationsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: "Not authenticated" });

  const notifications = await db
    .select()
    .from(notificationsTable)
    .where(eq(notificationsTable.user_id, req.session.userId))
    .limit(50);

  return res.json(notifications);
});

router.patch("/:id/read", async (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: "Not authenticated" });
  const id = parseInt(req.params["id"] ?? "");
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });

  await db
    .update(notificationsTable)
    .set({ read: true })
    .where(and(eq(notificationsTable.id, id), eq(notificationsTable.user_id, req.session.userId)));

  return res.json({ message: "Marked as read" });
});

router.post("/read-all", async (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: "Not authenticated" });

  await db
    .update(notificationsTable)
    .set({ read: true })
    .where(eq(notificationsTable.user_id, req.session.userId));

  return res.json({ message: "All marked as read" });
});

export default router;
