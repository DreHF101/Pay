import { Router } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

declare module "express-session" {
  interface SessionData {
    userId: number;
  }
}

const router = Router();

function avatarInitials(name: string): string {
  return name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

const COLORS = ["#4CAF50", "#2196F3", "#FF5722", "#9C27B0", "#FF9800", "#00BCD4", "#E91E63", "#607D8B"];
function pickColor(name: string): string {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return COLORS[h % COLORS.length]!;
}

function userToPublic(u: typeof usersTable.$inferSelect) {
  const { password_hash: _, ...rest } = u;
  return {
    ...rest,
    balance: u.community_balance + u.sponsored_balance,
  };
}

router.post("/register", async (req, res) => {
  const { name, email, password, neighborhood, city_id } = req.body as Record<string, string>;
  if (!name || !email || !password) {
    return res.status(400).json({ error: "name, email and password are required" });
  }
  const existing = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  if (existing.length > 0) return res.status(409).json({ error: "Email already in use" });

  const hash = await bcrypt.hash(password, 10);
  const [user] = await db
    .insert(usersTable)
    .values({
      name,
      email,
      password_hash: hash,
      neighborhood: neighborhood ?? "Fort Worth",
      city_id: city_id ?? "fort-worth-tx",
      avatar_initials: avatarInitials(name),
      avatar_color: pickColor(name),
    })
    .returning();
  if (!user) return res.status(500).json({ error: "Failed to create user" });
  req.session.userId = user.id;
  return res.status(201).json(userToPublic(user));
});

router.post("/login", async (req, res) => {
  const { email, password } = req.body as Record<string, string>;
  if (!email || !password) return res.status(400).json({ error: "email and password required" });
  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  if (!user) return res.status(401).json({ error: "Invalid credentials" });
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: "Invalid credentials" });
  req.session.userId = user.id;
  return res.json(userToPublic(user));
});

router.post("/logout", (req, res) => {
  req.session.destroy(() => {});
  return res.json({ message: "Logged out" });
});

router.get("/me", async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: "Not authenticated" });
  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, req.session.userId))
    .limit(1);
  if (!user) return res.status(404).json({ error: "User not found" });
  return res.json(userToPublic(user));
});

export default router;
