import { Router } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable, requestsTable, impactStoriesTable, gratitudeTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

const DEMO_USERS = [
  { name: "Maria Gonzalez", email: "maria@example.com", password: "password", neighborhood: "Near Southside", role: "neighbor" as const, avatar_color: "#4CAF50", avatar_initials: "MG", help_count: 23, volunteer_hours: 47, services_offered: "Transportation,Food Delivery,Elder Care", availability: "Available Now", service_radius: 10, trust_level: "trusted", is_verified: true, email_verified: true, phone_verified: true, id_verified: false, background_checked: false, community_trusted: true, reliability_pct: 97, lat: 32.7307, lng: -97.3185 },
  { name: "James Wilson", email: "james@example.com", password: "password", neighborhood: "Fairmount", role: "neighbor" as const, avatar_color: "#2196F3", avatar_initials: "JW", help_count: 41, volunteer_hours: 89, services_offered: "Home Repairs,Moving,Yard Work", availability: "Available Today", service_radius: 5, trust_level: "trusted", is_verified: true, email_verified: true, phone_verified: true, id_verified: true, background_checked: true, community_trusted: true, reliability_pct: 99, lat: 32.7255, lng: -97.3352 },
  { name: "Aisha Thompson", email: "aisha@example.com", password: "password", neighborhood: "Eastside", role: "neighbor" as const, avatar_color: "#9C27B0", avatar_initials: "AT", help_count: 12, volunteer_hours: 18, services_offered: "Childcare,Pet Care,Food Delivery", availability: "Available This Week", service_radius: 10, trust_level: "established", is_verified: false, email_verified: true, phone_verified: false, id_verified: false, background_checked: false, community_trusted: false, reliability_pct: 91, lat: 32.7491, lng: -97.2984 },
  { name: "Roberto Flores", email: "roberto@example.com", password: "password", neighborhood: "Polytechnic Heights", role: "neighbor" as const, avatar_color: "#FF5722", avatar_initials: "RF", help_count: 67, volunteer_hours: 134, services_offered: "Transportation,Moving,Home Repairs,Yard Work", availability: "Available Now", service_radius: 25, trust_level: "community_leader", is_verified: true, email_verified: true, phone_verified: true, id_verified: true, background_checked: true, community_trusted: true, reliability_pct: 100, lat: 32.7214, lng: -97.3050 },
  { name: "Linda Chen", email: "linda@example.com", password: "password", neighborhood: "Arlington Heights", role: "neighbor" as const, avatar_color: "#00BCD4", avatar_initials: "LC", help_count: 8, volunteer_hours: 12, services_offered: "Elder Care,Childcare", availability: "Available Today", service_radius: 5, trust_level: "established", is_verified: false, email_verified: true, phone_verified: false, id_verified: false, background_checked: false, community_trusted: false, reliability_pct: 88, lat: 32.7390, lng: -97.3764 },
  { name: "County Admin", email: "county@example.com", password: "password", neighborhood: "Downtown Fort Worth", role: "county" as const, avatar_color: "#607D8B", avatar_initials: "CA", help_count: 0, volunteer_hours: 0, services_offered: "", availability: "Available Now", service_radius: 50, trust_level: "trusted", is_verified: true, email_verified: true, phone_verified: false, id_verified: false, background_checked: false, community_trusted: false, reliability_pct: 90, lat: 32.7553, lng: -97.3308 },
];

const DEMO_REQUESTS = [
  { title: "Need a ride to Baylor Scott & White hospital", description: "My mom has a chemo appointment Thursday morning at 9am. I don't have a car and Uber is too expensive. Can anyone help get her there and back? About 6 miles each way.", category: "Transportation", urgency: "urgent" as const, neighborhood: "Near Southside", funding_source: "community_fund" as const, budget: 25 },
  { title: "Grocery run for elderly neighbor", description: "Ms. Johnson (82) on my block can't drive anymore. She needs someone to pick up groceries from H-E-B every two weeks. She'll have the list and money ready.", category: "Errands", urgency: "normal" as const, neighborhood: "Fairmount", funding_source: "pay_forward" as const, budget: 15 },
  { title: "Emergency — no power, baby needs formula heated", description: "Power outage in my area. I have a 4-month-old baby and need someone with power to help me heat formula. Please respond quickly!", category: "Emergency", urgency: "emergency" as const, neighborhood: "Eastside", funding_source: "volunteer" as const, budget: 0 },
  { title: "Help move furniture — 3rd floor apartment", description: "Moving from a 3rd floor walk-up to a ground floor unit in the same complex on Saturday. Have a couch, bed frame, dresser, and boxes. Will pay for pizza and your time.", category: "Moving", urgency: "normal" as const, neighborhood: "Polytechnic Heights", funding_source: "direct" as const, budget: 80 },
  { title: "Lawn mowing — been 3 weeks", description: "My husband is recovering from back surgery and I just had a baby. Lawn is getting out of hand. Need someone to mow and edge the front and back yard.", category: "Yard Work", urgency: "normal" as const, neighborhood: "Arlington Heights", funding_source: "pay_forward" as const, budget: 40 },
  { title: "Prescription pickup — can't leave house", description: "I tested positive for COVID and can't leave the house. My prescription is ready at Walgreens on Camp Bowie. Would really appreciate help picking it up today.", category: "Errands", urgency: "urgent" as const, neighborhood: "Haltom City", funding_source: "community_fund" as const, budget: 0 },
  { title: "Dog walking this week — broken leg", description: "I broke my leg last week and can't walk my two labs (Buster and Daisy). They need a 30-minute walk once a day. They're friendly and leash-trained.", category: "Pet Care", urgency: "normal" as const, neighborhood: "Wedgwood", funding_source: "direct" as const, budget: 20 },
  { title: "Help reading mail — vision problems", description: "My grandmother lives alone and is losing her vision. She has important medical and financial mail she needs help reading and organizing. Looking for a trustworthy person who can visit weekly.", category: "Elder Care", urgency: "normal" as const, neighborhood: "Como", funding_source: "pay_forward" as const, budget: 0 },
  { title: "EMERGENCY: Elderly man fell, needs assistance", description: "My neighbor Mr. Davis (78) fell in his backyard. He is okay but needs help getting inside and may need someone to stay with him until family arrives.", category: "Emergency", urgency: "emergency" as const, neighborhood: "Riverside", funding_source: "volunteer" as const, budget: 0 },
  { title: "Childcare needed Saturday morning", description: "I have a job interview Saturday at 10am. I need someone to watch my 3-year-old for about 2 hours. She's well-behaved and loves coloring books.", category: "Childcare", urgency: "urgent" as const, neighborhood: "North Fort Worth", funding_source: "direct" as const, budget: 30 },
];

const DEMO_STORIES = [
  { name: "Maria Gonzalez", neighborhood: "Near Southside", story: "Last month my car broke down the day before my job interview. I posted here not knowing what to expect. Within 30 minutes, Roberto offered to drive me. I got the job. This community changed my life.", category: "Transportation", avatar_color: "#4CAF50", avatar_initials: "MG" },
  { name: "James Wilson", neighborhood: "Fairmount", story: "I helped Mrs. Rodriguez move her furniture after her husband passed. She said she hadn't had anyone help her in years. We ended up talking for two hours over coffee. This is what community looks like.", category: "Moving Help", avatar_color: "#2196F3", avatar_initials: "JW" },
  { name: "Anonymous Neighbor", neighborhood: "Eastside", story: "During the ice storm I was stuck with no food for 3 days. Three different neighbors I'd never met brought groceries. When I recovered I spent a month helping others. Pay it forward is real.", category: "Emergency", avatar_color: "#9C27B0", avatar_initials: "AN" },
  { name: "Roberto Flores", neighborhood: "Polytechnic Heights", story: "I've completed over 60 jobs through this app. The best part isn't the money — it's knowing the people in my neighborhood by name. I've never felt more connected to Fort Worth in my life.", category: "General Help", avatar_color: "#FF5722", avatar_initials: "RF" },
  { name: "Linda Chen", neighborhood: "Arlington Heights", story: "My dad has dementia and I can't always be there. The helpers who check on him treat him like family. Last week Aisha brought him tamales and stayed to watch a Cowboys game. I cried.", category: "Elder Care", avatar_color: "#00BCD4", avatar_initials: "LC" },
];

if (process.env["NODE_ENV"] !== "production") {
  router.post("/seed", async (req, res) => {
    let created = 0;
    let skipped = 0;

    const seededUsers: typeof usersTable.$inferSelect[] = [];
    for (const u of DEMO_USERS) {
      const [existing] = await db.select().from(usersTable).where(eq(usersTable.email, u.email)).limit(1);
      if (existing) { seededUsers.push(existing); skipped++; continue; }
      const hash = await bcrypt.hash(u.password, 10);
      const [inserted] = await db.insert(usersTable).values({
        name: u.name, email: u.email, password_hash: hash,
        neighborhood: u.neighborhood, city_id: "fort-worth-tx",
        role: u.role, avatar_color: u.avatar_color, avatar_initials: u.avatar_initials,
        help_count: u.help_count, volunteer_hours: u.volunteer_hours,
        services_offered: u.services_offered, availability: u.availability,
        service_radius: u.service_radius, trust_level: u.trust_level,
        is_verified: u.is_verified, email_verified: u.email_verified,
        phone_verified: u.phone_verified, id_verified: u.id_verified,
        background_checked: u.background_checked, community_trusted: u.community_trusted,
        reliability_pct: u.reliability_pct, lat: u.lat, lng: u.lng,
      }).returning();
      if (inserted) { seededUsers.push(inserted); created++; }
    }

    const primaryUser = seededUsers[0];
    if (primaryUser) {
      for (let i = 0; i < DEMO_REQUESTS.length; i++) {
        const r = DEMO_REQUESTS[i]!;
        const requester = seededUsers[i % seededUsers.length]!;
        const [inserted] = await db.insert(requestsTable).values({
          requester_id: requester.id, title: r.title, description: r.description,
          category: r.category, urgency: r.urgency, neighborhood: r.neighborhood,
          city_id: "fort-worth-tx", funding_source: r.funding_source, budget: r.budget, status: "open",
        }).returning();
        if (inserted) created++;
      }

      for (const s of DEMO_STORIES) {
        await db.insert(impactStoriesTable).values({
          user_id: primaryUser.id, name: s.name, neighborhood: s.neighborhood,
          story: s.story, category: s.category, avatar_color: s.avatar_color, avatar_initials: s.avatar_initials,
        });
        created++;
      }

      const seededRequests = await db.select({ id: requestsTable.id }).from(requestsTable).limit(3);
      const gratitudeMessages = [
        "Thank you so much for the help with groceries last week — you really saved us!",
        "You went above and beyond. My mom is still talking about how kind you were.",
        "Couldn't have made it to my appointment without you. You're a true neighbor.",
      ];
      for (let i = 0; i < Math.min(3, seededRequests.length); i++) {
        const from = seededUsers[i]!;
        const to = seededUsers[(i + 1) % seededUsers.length]!;
        const reqId = seededRequests[i]!.id;
        await db.insert(gratitudeTable).values({ from_user_id: from.id, to_user_id: to.id, message: gratitudeMessages[i]!, request_id: reqId });
        created++;
      }
    }

    return res.json({ message: "Seed complete", created, skipped });
  });
}

export default router;
