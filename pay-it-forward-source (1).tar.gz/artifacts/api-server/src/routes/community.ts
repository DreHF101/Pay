import { Router } from "express";
import {
  db,
  communityFundTable,
  payForwardLogTable,
  usersTable,
  requestsTable,
  jobsTable,
  gratitudeTable,
  notificationsTable,
  impactStoriesTable,
} from "@workspace/db";
import { eq, and, desc, gte } from "drizzle-orm";

const router = Router();

async function ensureFund(city_id = "fort-worth-tx") {
  const [existing] = await db
    .select()
    .from(communityFundTable)
    .where(eq(communityFundTable.city_id, city_id))
    .limit(1);
  if (existing) return existing;
  const [created] = await db
    .insert(communityFundTable)
    .values({
      city_id,
      balance: 2450.00,
      total_contributed: 8750.00,
      total_disbursed: 6300.00,
      people_helped: 47,
      hours_donated: 312,
      requests_funded: 89,
      neighbors_helped: 234,
      rides_provided: 156,
      meals_delivered: 89,
      emergency_responses: 23,
      repeat_connections: 67,
      households_supported: 134,
      mentorship_relationships: 28,
      families_assisted: 78,
    })
    .returning();
  return created!;
}

router.get("/fund", async (req, res) => {
  const fund = await ensureFund();

  // Count pending fund requests
  const pendingRows = await db
    .select()
    .from(requestsTable)
    .where(and(eq(requestsTable.funding_source, "community_fund"), eq(requestsTable.status, "open")));

  return res.json({
    ...fund,
    pending_fund_requests: pendingRows.length,
  });
});

router.post("/fund/contribute", async (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: "Not authenticated" });
  const { amount, note } = req.body as { amount: number; note?: string };
  if (!amount || amount <= 0) return res.status(400).json({ error: "amount must be positive" });

  const fund = await ensureFund();
  await db
    .update(communityFundTable)
    .set({
      balance: fund.balance + amount,
      total_contributed: fund.total_contributed + amount,
    })
    .where(eq(communityFundTable.id, fund.id));

  await db.insert(payForwardLogTable).values({
    from_user_id: req.session.userId,
    amount,
    note: note ?? null,
  });

  // Update user pay_forward_total
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.session.userId)).limit(1);
  if (user) {
    await db
      .update(usersTable)
      .set({ pay_forward_total: user.pay_forward_total + amount })
      .where(eq(usersTable.id, user.id));
  }

  const updatedFund = await ensureFund();
  return res.json({ message: "Contribution added", new_balance: updatedFund.balance });
});

router.get("/fund/requests", async (req, res) => {
  const { status } = req.query as { status?: string };
  const conditions = [eq(requestsTable.funding_source, "community_fund")];
  if (status) conditions.push(eq(requestsTable.status, status));

  const rows = await db
    .select()
    .from(requestsTable)
    .where(and(...conditions))
    .orderBy(requestsTable.created_at)
    .limit(50);

  const enriched = await Promise.all(
    rows.map(async (r) => {
      const [u] = await db.select({ name: usersTable.name }).from(usersTable).where(eq(usersTable.id, r.requester_id)).limit(1);
      return { ...r, requester_name: r.is_anonymous ? "Anonymous" : (u?.name ?? null), scheduled_for: r.scheduled_for ?? null };
    })
  );

  return res.json(enriched);
});

router.post("/fund/requests/:id/approve", async (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: "Not authenticated" });
  const id = parseInt(req.params["id"] ?? "");

  const [actor] = await db
    .select({ role: usersTable.role })
    .from(usersTable)
    .where(eq(usersTable.id, req.session.userId))
    .limit(1);
  if (actor?.role !== "admin" && actor?.role !== "county") {
    return res.status(403).json({ error: "Forbidden" });
  }

  const [row] = await db.select().from(requestsTable).where(eq(requestsTable.id, id)).limit(1);
  if (!row) return res.status(404).json({ error: "Request not found" });

  const fund = await ensureFund(row.city_id);
  if (row.budget && fund.balance < row.budget) {
    return res.status(400).json({ error: "Insufficient fund balance" });
  }

  await db
    .update(requestsTable)
    .set({ status: "funded" })
    .where(eq(requestsTable.id, id));

  if (row.budget) {
    await db
      .update(communityFundTable)
      .set({
        balance: fund.balance - row.budget,
        total_disbursed: fund.total_disbursed + row.budget,
        requests_funded: fund.requests_funded + 1,
      })
      .where(eq(communityFundTable.id, fund.id));

    // Update requester sponsored_balance
    const [requester] = await db.select().from(usersTable).where(eq(usersTable.id, row.requester_id)).limit(1);
    if (requester) {
      await db
        .update(usersTable)
        .set({ sponsored_balance: requester.sponsored_balance + row.budget })
        .where(eq(usersTable.id, requester.id));
    }
  }

  await db.insert(notificationsTable).values({
    user_id: row.requester_id,
    type: "fund_approved",
    title: "Funding Approved!",
    message: `Your request "${row.title}" has been approved for community fund assistance.`,
    related_id: row.id,
    related_type: "request",
  });

  return res.json({ message: "Approved", amount_disbursed: row.budget ?? 0 });
});

router.post("/fund/requests/:id/deny", async (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: "Not authenticated" });
  const id = parseInt(req.params["id"] ?? "");

  const [actor] = await db
    .select({ role: usersTable.role })
    .from(usersTable)
    .where(eq(usersTable.id, req.session.userId))
    .limit(1);
  if (actor?.role !== "admin" && actor?.role !== "county") {
    return res.status(403).json({ error: "Forbidden" });
  }

  const [row] = await db.select().from(requestsTable).where(eq(requestsTable.id, id)).limit(1);
  if (!row) return res.status(404).json({ error: "Request not found" });

  await db.update(requestsTable).set({ status: "cancelled" }).where(eq(requestsTable.id, id));

  await db.insert(notificationsTable).values({
    user_id: row.requester_id,
    type: "fund_denied",
    title: "Request Not Funded",
    message: `Your request "${row.title}" was not approved for community fund assistance.`,
    related_id: row.id,
    related_type: "request",
  });

  return res.json({ message: "Denied" });
});

router.get("/fund/log", async (req, res) => {
  const logs = await db
    .select()
    .from(payForwardLogTable)
    .orderBy(desc(payForwardLogTable.created_at))
    .limit(50);
  return res.json(logs);
});

router.get("/activity", async (req, res) => {
  const [recentRequests, recentJobs, recentGratitude, recentContributions] = await Promise.all([
    db.select().from(requestsTable).orderBy(desc(requestsTable.created_at)).limit(10),
    db.select().from(jobsTable).orderBy(desc(jobsTable.created_at)).limit(10),
    db.select().from(gratitudeTable).orderBy(desc(gratitudeTable.created_at)).limit(10),
    db.select().from(payForwardLogTable).orderBy(desc(payForwardLogTable.created_at)).limit(10),
  ]);

  const enrichedRequests = await Promise.all(
    recentRequests.map(async (r) => {
      const [u] = await db.select({ name: usersTable.name }).from(usersTable).where(eq(usersTable.id, r.requester_id)).limit(1);
      return { ...r, requester_name: r.is_anonymous ? "Anonymous" : (u?.name ?? null), scheduled_for: r.scheduled_for ?? null };
    })
  );

  const enrichedJobs = await Promise.all(
    recentJobs.map(async (j) => {
      const [r] = await db.select().from(requestsTable).where(eq(requestsTable.id, j.request_id)).limit(1);
      const [h] = await db.select({ name: usersTable.name }).from(usersTable).where(eq(usersTable.id, j.helper_id)).limit(1);
      return {
        ...j,
        completed_at: j.completed_at ? j.completed_at.toISOString() : null,
        request_title: r?.title ?? null,
        request_description: r?.description ?? null,
        request_category: r?.category ?? null,
        request_urgency: r?.urgency ?? null,
        request_funding_source: r?.funding_source ?? null,
        request_neighborhood: r?.neighborhood ?? null,
        helper_name: h?.name ?? null,
        requester_name: null,
        budget: r?.budget ?? null,
      };
    })
  );

  const enrichedGratitude = await Promise.all(
    recentGratitude.map(async (g) => {
      const [from] = await db.select({ name: usersTable.name, avatar_color: usersTable.avatar_color }).from(usersTable).where(eq(usersTable.id, g.from_user_id)).limit(1);
      const toUser = g.to_user_id
        ? await db.select({ name: usersTable.name }).from(usersTable).where(eq(usersTable.id, g.to_user_id)).limit(1)
        : [];
      return {
        ...g,
        from_user_name: from?.name ?? null,
        from_user_avatar_color: from?.avatar_color ?? null,
        to_user_name: toUser[0]?.name ?? null,
      };
    })
  );

  const stats = await ensureFund();

  return res.json({
    recent_requests: enrichedRequests,
    recent_completions: enrichedJobs,
    recent_gratitude: enrichedGratitude,
    recent_contributions: recentContributions,
    stats,
  });
});

router.post("/stories", async (req, res) => {
  const { name, neighborhood, story, category, avatar_color, avatar_initials } = req.body as Record<string, string>;
  if (!name || !neighborhood || !story || !category) {
    return res.status(400).json({ error: "name, neighborhood, story, and category are required" });
  }
  const userId: number | undefined = (req.session as any).userId;
  const initials = avatar_initials ?? name.split(" ").map((w: string) => w[0]).join("").toUpperCase().slice(0, 2);
  const colors = ["#4CAF50", "#2196F3", "#FF5722", "#9C27B0", "#FF9800", "#00BCD4", "#E91E63"];
  const color = avatar_color ?? colors[name.charCodeAt(0) % colors.length]!;

  const [created] = await db
    .insert(impactStoriesTable)
    .values({ user_id: userId ?? null, name, neighborhood, story, category, avatar_color: color, avatar_initials: initials })
    .returning();

  return res.status(201).json(created);
});

router.get("/stories", async (req, res) => {
  const stories = await db
    .select()
    .from(impactStoriesTable)
    .orderBy(desc(impactStoriesTable.created_at))
    .limit(20);

  // Weekly stats from actual data
  const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const recentRequests = await db
    .select()
    .from(requestsTable)
    .where(gte(requestsTable.created_at, oneWeekAgo));
  const recentCompletions = await db
    .select()
    .from(jobsTable)
    .where(and(eq(jobsTable.status, "completed"), gte(jobsTable.created_at, oneWeekAgo)));

  const totalVolunteerHours = await db.select({ hours: usersTable.volunteer_hours }).from(usersTable);
  const totalHours = totalVolunteerHours.reduce((a, u) => a + u.hours, 0);

  return res.json({
    stories,
    weekly_stats: {
      people_helped: recentCompletions.length,
      seniors_helped: Math.floor(recentCompletions.length * 0.3),
      veterans_helped: Math.floor(recentCompletions.length * 0.15),
      volunteer_hours: totalHours,
      requests_this_week: recentRequests.length,
      completions_this_week: recentCompletions.length,
    },
  });
});

router.get("/county-report", async (req, res) => {
  const { zip_code } = req.query as { zip_code?: string };

  const allRequests = await db.select().from(requestsTable).orderBy(desc(requestsTable.created_at)).limit(100);
  const fund = await ensureFund();

  const categoryMap: Record<string, number> = {};
  for (const r of allRequests) {
    categoryMap[r.category] = (categoryMap[r.category] ?? 0) + 1;
  }

  const topCategories = Object.entries(categoryMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([category, count]) => ({ category, count }));

  const recentRequests = await Promise.all(
    allRequests.slice(0, 20).map(async (r) => {
      const [u] = await db.select({ name: usersTable.name }).from(usersTable).where(eq(usersTable.id, r.requester_id)).limit(1);
      return { ...r, requester_name: r.is_anonymous ? "Anonymous" : (u?.name ?? null), scheduled_for: r.scheduled_for ?? null };
    })
  );

  return res.json({
    zip_code: zip_code ?? null,
    total_requests: allRequests.length,
    open_requests: allRequests.filter((r) => r.status === "open").length,
    funded_requests: allRequests.filter((r) => r.status === "funded").length,
    completed_requests: allRequests.filter((r) => r.status === "completed").length,
    community_fund_balance: fund.balance,
    total_disbursed: fund.total_disbursed,
    top_categories: topCategories,
    recent_requests: recentRequests,
  });
});

export default router;
