import { Router } from "express";
import { db, requestsTable, usersTable, notificationsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { broadcastSSE } from "../lib/sseEmitter";

const router = Router();

async function withRequesterName(req: typeof requestsTable.$inferSelect) {
  const [user] = await db
    .select({
      name: usersTable.name,
      trust_level: usersTable.trust_level,
      is_verified: usersTable.is_verified,
      help_count: usersTable.help_count,
      reliability_pct: usersTable.reliability_pct,
      background_checked: usersTable.background_checked,
    })
    .from(usersTable)
    .where(eq(usersTable.id, req.requester_id))
    .limit(1);
  return {
    ...req,
    requester_name: req.is_anonymous ? "Anonymous" : (user?.name ?? null),
    requester_trust_level: req.is_anonymous ? null : (user?.trust_level ?? "newcomer"),
    requester_is_verified: req.is_anonymous ? false : (user?.is_verified ?? false),
    requester_help_count: req.is_anonymous ? 0 : (user?.help_count ?? 0),
    requester_reliability_pct: req.is_anonymous ? null : (user?.reliability_pct ?? 90),
    requester_background_checked: req.is_anonymous ? false : (user?.background_checked ?? false),
    scheduled_for: req.scheduled_for ?? null,
  };
}

router.get("/", async (req, res) => {
  const { city_id, category, status, urgency, funding_source, requester_id } = req.query as Record<
    string,
    string | undefined
  >;

  const conditions = [];
  if (city_id) conditions.push(eq(requestsTable.city_id, city_id));
  if (category) conditions.push(eq(requestsTable.category, category));
  if (status) conditions.push(eq(requestsTable.status, status));
  if (urgency) conditions.push(eq(requestsTable.urgency, urgency));
  if (funding_source) conditions.push(eq(requestsTable.funding_source, funding_source));
  if (requester_id) conditions.push(eq(requestsTable.requester_id, parseInt(requester_id)));

  const rows = await db
    .select()
    .from(requestsTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(requestsTable.created_at)
    .limit(100);

  const result = await Promise.all(rows.map(withRequesterName));
  return res.json(result);
});

router.post("/", async (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: "Not authenticated" });

  const {
    title,
    description,
    category,
    neighborhood,
    urgency,
    budget,
    funding_source,
    is_anonymous,
    recurring,
    is_business,
    business_name,
    repayment_timeline,
  } = req.body as Record<string, string | number | boolean | undefined>;

  if (!title || !description || !category) {
    return res.status(400).json({ error: "title, description, category are required" });
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.session.userId)).limit(1);
  if (!user) return res.status(401).json({ error: "User not found" });

  const urgencyStr = urgency ? String(urgency) : "normal";

  const [created] = await db
    .insert(requestsTable)
    .values({
      requester_id: user.id,
      title: String(title),
      description: String(description),
      category: String(category),
      neighborhood: neighborhood ? String(neighborhood) : user.neighborhood,
      city_id: user.city_id,
      urgency: urgencyStr,
      budget: budget ? Number(budget) : undefined,
      funding_source: funding_source ? String(funding_source) : "direct",
      is_anonymous: Boolean(is_anonymous),
      recurring: recurring ? String(recurring) : "one_time",
      is_business: Boolean(is_business),
      business_name: business_name ? String(business_name) : undefined,
      repayment_timeline: repayment_timeline ? String(repayment_timeline) : undefined,
    })
    .returning();

  if (!created) return res.status(500).json({ error: "Failed to create request" });

  await db
    .update(usersTable)
    .set({ request_count: user.request_count + 1 })
    .where(eq(usersTable.id, user.id));

  const result = await withRequesterName(created);

  // ── Real-time SSE broadcast for urgent/emergency requests ──────────────────
  // Payload intentionally omits requester_name: this broadcast reaches all
  // connected clients including unauthenticated visitors, so we only expose
  // public-safe fields (title, neighborhood, urgency) — no identity data.
  if (urgencyStr === "emergency" || urgencyStr === "urgent") {
    broadcastSSE("new_urgent_request", {
      id: result.id,
      title: result.title,
      category: result.category,
      neighborhood: result.neighborhood,
      urgency: result.urgency,
      funding_source: result.funding_source,
      created_at: result.created_at,
    });
  }

  return res.status(201).json(result);
});

router.get("/:id", async (req, res) => {
  const id = parseInt(req.params["id"] ?? "");
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  const [row] = await db.select().from(requestsTable).where(eq(requestsTable.id, id)).limit(1);
  if (!row) return res.status(404).json({ error: "Request not found" });
  return res.json(await withRequesterName(row));
});

router.patch("/:id", async (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: "Not authenticated" });
  const id = parseInt(req.params["id"] ?? "");
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });

  const [row] = await db.select().from(requestsTable).where(eq(requestsTable.id, id)).limit(1);
  if (!row) return res.status(404).json({ error: "Request not found" });

  const [actor] = await db
    .select({ role: usersTable.role })
    .from(usersTable)
    .where(eq(usersTable.id, req.session.userId))
    .limit(1);
  const isAdmin = actor?.role === "admin" || actor?.role === "county";
  const isOwner = row.requester_id === req.session.userId;

  if (!isOwner && !isAdmin) return res.status(403).json({ error: "Forbidden" });

  const { title, description, status, urgency } = req.body as Record<string, string | undefined>;

  const updates: Partial<typeof requestsTable.$inferInsert> = {};
  if (typeof title === "string") updates.title = title;
  if (typeof description === "string") updates.description = description;
  if (typeof status === "string") updates.status = status;
  if (typeof urgency === "string") updates.urgency = urgency;
  updates.updated_at = new Date();

  const [updated] = await db.update(requestsTable).set(updates).where(eq(requestsTable.id, id)).returning();
  if (!updated) return res.status(404).json({ error: "Request not found" });

  if (status && status !== row.status) {
    await db.insert(notificationsTable).values({
      user_id: row.requester_id,
      type: "request_update",
      title: "Request Updated",
      message: `Your request "${row.title}" status changed to ${status}.`,
      related_id: row.id,
      related_type: "request",
    });
  }

  return res.json(await withRequesterName(updated));
});

export default router;
