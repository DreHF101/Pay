import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/:id", async (req, res) => {
  const id = parseInt(req.params["id"] ?? "");
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, id)).limit(1);
  if (!user) return res.status(404).json({ error: "User not found" });
  const { password_hash: _, ...pub } = user;
  return res.json(pub);
});

router.patch("/:id", async (req, res) => {
  if (!req.session?.userId) return res.status(401).json({ error: "Not authenticated" });
  const id = parseInt(req.params["id"] ?? "");
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  if (req.session.userId !== id) return res.status(403).json({ error: "Forbidden" });

  const { name, bio, neighborhood, city_id, availability, service_radius, services_offered, avatar_color } =
    req.body as Record<string, string | number | undefined>;

  const updates: Partial<typeof usersTable.$inferInsert> = {};
  if (typeof name === "string") updates.name = name;
  if (typeof bio === "string") updates.bio = bio;
  if (typeof neighborhood === "string") updates.neighborhood = neighborhood;
  if (typeof city_id === "string") updates.city_id = city_id;
  if (typeof availability === "string") updates.availability = availability;
  if (service_radius !== undefined) updates.service_radius = Number(service_radius);
  if (typeof services_offered === "string") updates.services_offered = services_offered;
  if (typeof avatar_color === "string") updates.avatar_color = avatar_color;

  const [updated] = await db.update(usersTable).set(updates).where(eq(usersTable.id, id)).returning();
  if (!updated) return res.status(404).json({ error: "User not found" });
  const { password_hash: _, ...pub } = updated;
  return res.json({ ...pub, balance: updated.community_balance + updated.sponsored_balance });
});

export default router;
