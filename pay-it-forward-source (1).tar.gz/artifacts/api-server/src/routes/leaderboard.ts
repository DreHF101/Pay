import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  const { city_id } = req.query as { city_id?: string };

  const baseSelect = {
    id: usersTable.id,
    name: usersTable.name,
    avatar_color: usersTable.avatar_color,
    avatar_initials: usersTable.avatar_initials,
    neighborhood: usersTable.neighborhood,
    city_id: usersTable.city_id,
    help_count: usersTable.help_count,
    volunteer_hours: usersTable.volunteer_hours,
    trust_level: usersTable.trust_level,
    is_verified: usersTable.is_verified,
    pay_forward_total: usersTable.pay_forward_total,
  };

  const whereClause = city_id ? eq(usersTable.city_id, city_id) : undefined;

  const [topHelpers, topContributors] = await Promise.all([
    db
      .select(baseSelect)
      .from(usersTable)
      .where(whereClause)
      .orderBy(desc(usersTable.help_count))
      .limit(10),
    db
      .select(baseSelect)
      .from(usersTable)
      .where(whereClause)
      .orderBy(desc(usersTable.pay_forward_total))
      .limit(10),
  ]);

  return res.json({
    top_helpers: topHelpers,
    top_contributors: topContributors,
    city_id: city_id ?? null,
  });
});

export default router;
