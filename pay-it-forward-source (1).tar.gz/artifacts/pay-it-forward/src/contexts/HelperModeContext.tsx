import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface HelperModeContextType {
  isHelperMode: boolean;
  setHelperMode: (value: boolean) => void;
}

const HelperModeContext = createContext<HelperModeContextType | undefined>(undefined);

export function HelperModeProvider({ children }: { children: ReactNode }) {
  const [isHelperMode, setIsHelperMode] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("uberMode");
    if (saved) {
      setIsHelperMode(saved === "true");
    }
  }, []);

  const setHelperMode = (value: boolean) => {
    setIsHelperMode(value);
    localStorage.setItem("uberMode", value.toString());
  };

  return (
    <HelperModeContext.Provider value={{ isHelperMode, setHelperMode }}>
      {children}
    </HelperModeContext.Provider>
  );
}

export function useHelperMode() {
  const context = useContext(HelperModeContext);
  if (context === undefined) {
    throw new Error("useHelperMode must be used within a HelperModeProvider");
  }
  return context;
}
