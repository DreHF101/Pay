import { useState, useCallback, useRef } from "react";
import Map, { Marker, Popup, Source, Layer, NavigationControl, type MapRef } from "react-map-gl/mapbox";
import "mapbox-gl/dist/mapbox-gl.css";
import { Navigation, Zap, Clock, MapPin, ChevronRight, ExternalLink, X } from "lucide-react";

const MAPBOX_TOKEN = import.meta.env.VITE_MAPBOX_TOKEN as string;

// Fort Worth center — NOTE: Mapbox uses [lng, lat] everywhere
const FW_CENTER = { lng: -97.3308, lat: 32.7555 };

// Helper simulated position (Downtown Fort Worth) [lng, lat]
const HELPER_POS: [number, number] = [-97.3308, 32.7553];

const NEIGHBORHOOD_COORDS: Record<string, [number, number]> = {
  "Near Southside":      [-97.3185, 32.7307],
  "Fairmount":           [-97.3352, 32.7255],
  "Downtown Fort Worth": [-97.3308, 32.7553],
  "Eastside":            [-97.2984, 32.7491],
  "Arlington Heights":   [-97.3764, 32.7390],
  "Haltom City":         [-97.2697, 32.7993],
  "North Fort Worth":    [-97.3388, 32.8123],
  "Benbrook":            [-97.4619, 32.6826],
  "Wedgwood":            [-97.3820, 32.6940],
  "Como":                [-97.4063, 32.7266],
  "Riverside":           [-97.3026, 32.7690],
  "Polytechnic Heights": [-97.3050, 32.7214],
};

const URGENCY_COLORS: Record<string, string> = {
  emergency: "#ef4444",
  urgent:    "#f97316",
  normal:    "#3b82f6",
  low:       "#6b7280",
};

function getCoords(neighborhood: string, id: number): [number, number] {
  const base = NEIGHBORHOOD_COORDS[neighborhood];
  const fallback: [number, number] = [-97.3308, 32.7555];
  const coords = base ?? fallback;
  // small jitter so pins don't stack — [lng, lat]
  const jLng = ((id * 13 + 7) % 40 - 20) * 0.0008;
  const jLat = ((id * 17 + 3) % 40 - 20) * 0.0008;
  return [coords[0] + jLng, coords[1] + jLat];
}

interface DirectionStep {
  maneuver: { instruction: string };
  distance: number;
  duration: number;
}

interface RouteData {
  geometry: GeoJSON.LineString;
  legs: Array<{ steps: DirectionStep[] }>;
  duration: number; // seconds
  distance: number; // meters
}

export interface PatrolMapRequest {
  id: number;
  title: string;
  description?: string;
  category: string;
  neighborhood: string;
  urgency: string;
  status: string;
  budget?: number | null;
  lat?: number | null;
  lng?: number | null;
}

interface Props {
  requests: PatrolMapRequest[];
  onHelp: (id: number) => void;
  claimedIds: Set<number>;
}

async function fetchRoute(
  startLng: number, startLat: number,
  endLng: number, endLat: number
): Promise<RouteData | null> {
  try {
    const url =
      `https://api.mapbox.com/directions/v5/mapbox/driving/` +
      `${startLng},${startLat};${endLng},${endLat}` +
      `?steps=true&geometries=geojson&access_token=${MAPBOX_TOKEN}`;
    const res = await fetch(url);
    const data = (await res.json()) as { routes?: RouteData[] };
    return data.routes?.[0] ?? null;
  } catch {
    return null;
  }
}

function formatDist(meters: number) {
  const miles = meters / 1609.34;
  return miles < 0.1 ? `${Math.round(meters * 3.281)} ft` : `${miles.toFixed(1)} mi`;
}

function formatDuration(seconds: number) {
  if (seconds < 60) return `${Math.round(seconds)}s`;
  const m = Math.round(seconds / 60);
  return m < 60 ? `${m} min` : `${Math.floor(m / 60)}h ${m % 60}m`;
}

export default function PatrolMap({ requests, claimedIds, onHelp }: Props) {
  const mapRef = useRef<MapRef>(null);
  const [selected, setSelected] = useState<PatrolMapRequest | null>(null);
  const [route, setRoute] = useState<RouteData | null>(null);
  const [loadingRoute, setLoadingRoute] = useState(false);
  const [activeStepIdx, setActiveStepIdx] = useState(0);

  const handleMarkerClick = useCallback((req: PatrolMapRequest) => {
    setSelected(req);
    setRoute(null);
    setActiveStepIdx(0);
    const [lng, lat] = getCoords(req.neighborhood, req.id);
    mapRef.current?.flyTo({ center: [lng, lat], zoom: 14, duration: 700 });
  }, []);

  const handleGetDirections = useCallback(async (req: PatrolMapRequest) => {
    setLoadingRoute(true);
    const [destLng, destLat] = getCoords(req.neighborhood, req.id);
    const result = await fetchRoute(HELPER_POS[0], HELPER_POS[1], destLng, destLat);
    setRoute(result);
    setActiveStepIdx(0);
    setLoadingRoute(false);

    if (result && mapRef.current) {
      const coords = result.geometry.coordinates as [number, number][];
      const lngs = coords.map((c) => c[0]);
      const lats = coords.map((c) => c[1]);
      mapRef.current.fitBounds(
        [[Math.min(...lngs), Math.min(...lats)], [Math.max(...lngs), Math.max(...lats)]],
        { padding: 60, duration: 800 }
      );
    }
  }, []);

  const googleMapsHref = (req: PatrolMapRequest) => {
    const [lng, lat] = getCoords(req.neighborhood, req.id);
    return `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
  };

  const routeGeoJSON: GeoJSON.Feature<GeoJSON.LineString> | null = route
    ? { type: "Feature", properties: {}, geometry: route.geometry }
    : null;

  const steps = route?.legs?.[0]?.steps ?? [];

  return (
    <div className="flex flex-col gap-3">
      {/* ── Mapbox Map ── */}
      <div
        className="relative rounded-xl overflow-hidden border border-border"
        style={{ height: 340 }}
      >
        <Map
          ref={mapRef}
          mapboxAccessToken={MAPBOX_TOKEN}
          initialViewState={{ longitude: FW_CENTER.lng, latitude: FW_CENTER.lat, zoom: 11 }}
          mapStyle="mapbox://styles/mapbox/streets-v12"
          style={{ width: "100%", height: "100%" }}
        >
          <NavigationControl position="top-right" />

          {/* Route line */}
          {routeGeoJSON && (
            <Source id="route-source" type="geojson" data={routeGeoJSON}>
              <Layer
                id="route-line"
                type="line"
                paint={{ "line-color": "#6366f1", "line-width": 4, "line-opacity": 0.85 }}
                layout={{ "line-join": "round", "line-cap": "round" }}
              />
            </Source>
          )}

          {/* Helper location — pulsing green */}
          <Marker longitude={HELPER_POS[0]} latitude={HELPER_POS[1]} anchor="center">
            <div className="relative w-5 h-5">
              <div className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-60" />
              <div className="relative w-5 h-5 rounded-full bg-green-500 border-2 border-white shadow-lg" />
            </div>
          </Marker>

          {/* Request pins */}
          {requests.map((req) => {
            const [lng, lat] = getCoords(req.neighborhood, req.id);
            const color = URGENCY_COLORS[req.urgency] ?? "#6b7280";
            const isSelected = selected?.id === req.id;
            const isClaimed = claimedIds.has(req.id);

            return (
              <Marker
                key={req.id}
                longitude={lng}
                latitude={lat}
                anchor="center"
                onClick={(e: { originalEvent: Event }) => {
                  e.originalEvent.stopPropagation();
                  handleMarkerClick(req);
                }}
              >
                <div
                  className="relative cursor-pointer transition-transform"
                  style={{ transform: isSelected ? "scale(1.35)" : "scale(1)" }}
                >
                  <div
                    className={`w-5 h-5 rounded-full border-2 border-white shadow-md flex items-center justify-center ${isClaimed ? "opacity-50" : ""}`}
                    style={{ backgroundColor: color }}
                  >
                    {req.urgency === "emergency" && !isClaimed && (
                      <Zap className="w-2.5 h-2.5 text-white" />
                    )}
                  </div>
                  {req.urgency === "emergency" && !isClaimed && (
                    <div
                      className="absolute inset-0 rounded-full animate-ping opacity-50"
                      style={{ backgroundColor: color }}
                    />
                  )}
                </div>
              </Marker>
            );
          })}

          {/* Popup */}
          {selected && (() => {
            const [lng, lat] = getCoords(selected.neighborhood, selected.id);
            const isClaimed = claimedIds.has(selected.id);
            const color = URGENCY_COLORS[selected.urgency] ?? "#6b7280";
            return (
              <Popup
                longitude={lng}
                latitude={lat}
                anchor="bottom"
                offset={16}
                closeButton={false}
                onClose={() => setSelected(null)}
                maxWidth="240px"
              >
                <div className="p-1">
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <h4 className="font-semibold text-sm leading-tight">{selected.title}</h4>
                    <button
                      onClick={() => setSelected(null)}
                      className="text-muted-foreground hover:text-foreground shrink-0 mt-0.5"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-1 mb-2">
                    <span
                      className="text-xs px-1.5 py-0.5 rounded-full font-medium"
                      style={{ backgroundColor: `${color}22`, color }}
                    >
                      {selected.urgency.charAt(0).toUpperCase() + selected.urgency.slice(1)}
                    </span>
                    <span className="text-xs bg-muted px-1.5 py-0.5 rounded-full">
                      {selected.category}
                    </span>
                  </div>

                  <div className="flex items-center gap-1 text-xs text-muted-foreground mb-2.5">
                    <MapPin className="w-3 h-3" />
                    {selected.neighborhood}
                    {selected.budget != null && (
                      <span className="ml-auto font-bold text-foreground">${selected.budget}</span>
                    )}
                  </div>

                  <div className="flex gap-1.5">
                    {isClaimed ? (
                      <span className="flex-1 text-center text-xs text-green-600 font-semibold py-1.5 bg-green-50 rounded-lg">
                        ✓ You&apos;re helping!
                      </span>
                    ) : (
                      <button
                        onClick={() => { onHelp(selected.id); setSelected(null); }}
                        className="flex-1 text-xs bg-primary text-primary-foreground rounded-lg py-1.5 font-semibold hover:bg-primary/90 transition-colors"
                      >
                        I Can Help ✓
                      </button>
                    )}
                    <button
                      onClick={() => handleGetDirections(selected)}
                      disabled={loadingRoute}
                      className="flex items-center gap-0.5 text-xs bg-blue-100 text-blue-700 rounded-lg px-2 py-1.5 font-medium hover:bg-blue-200 transition-colors disabled:opacity-50"
                    >
                      <Navigation className="w-3 h-3" />
                      {loadingRoute ? "…" : "Route"}
                    </button>
                    <a
                      href={googleMapsHref(selected)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-0.5 text-xs bg-muted text-muted-foreground rounded-lg px-2 py-1.5 font-medium hover:bg-muted/70 transition-colors"
                      title="Open in Google Maps"
                    >
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              </Popup>
            );
          })()}
        </Map>

        {/* Legend */}
        <div className="absolute bottom-3 left-3 bg-background/90 backdrop-blur-sm rounded-xl px-3 py-2 shadow border border-border text-xs space-y-1 pointer-events-none">
          {[
            { color: "#ef4444", label: "Emergency" },
            { color: "#f97316", label: "Urgent" },
            { color: "#3b82f6", label: "Normal" },
            { color: "#22c55e", label: "You" },
          ].map(({ color, label }) => (
            <div key={label} className="flex items-center gap-1.5">
              <span
                className="w-2.5 h-2.5 rounded-full shrink-0"
                style={{ backgroundColor: color }}
              />
              <span className="text-muted-foreground">{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* ── Turn-by-Turn Directions Panel ── */}
      {route && (
        <div className="bg-card border border-indigo-200 rounded-xl overflow-hidden">
          {/* ETA + distance summary */}
          <div className="flex items-center gap-3 bg-indigo-50 px-4 py-2.5 border-b border-indigo-100">
            <Navigation className="w-4 h-4 text-indigo-600 shrink-0" />
            <span className="text-sm font-semibold text-indigo-800 flex-1">
              {formatDuration(route.duration)} · {formatDist(route.distance)}
            </span>
            {selected && (
              <a
                href={googleMapsHref(selected)}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-xs text-indigo-600 font-medium hover:underline shrink-0"
              >
                Open in Maps <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>

          {/* Steps list */}
          <div className="max-h-52 overflow-y-auto divide-y divide-border">
            {steps.map((step, idx) => (
              <button
                key={idx}
                onClick={() => setActiveStepIdx(idx)}
                className={`w-full text-left flex items-start gap-3 px-4 py-2.5 transition-colors ${
                  idx === activeStepIdx ? "bg-indigo-50" : "hover:bg-muted/40"
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full shrink-0 flex items-center justify-center text-[10px] font-bold mt-0.5 ${
                    idx === activeStepIdx
                      ? "bg-indigo-600 text-white"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  {idx + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium leading-snug">
                    {step.maneuver.instruction}
                  </p>
                  <div className="flex items-center gap-3 mt-0.5 text-xs text-muted-foreground">
                    <span className="flex items-center gap-0.5">
                      <MapPin className="w-2.5 h-2.5" />
                      {formatDist(step.distance)}
                    </span>
                    <span className="flex items-center gap-0.5">
                      <Clock className="w-2.5 h-2.5" />
                      {formatDuration(step.duration)}
                    </span>
                  </div>
                </div>
                {idx === activeStepIdx && (
                  <ChevronRight className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
