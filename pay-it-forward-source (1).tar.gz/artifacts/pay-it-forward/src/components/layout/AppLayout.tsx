import { Link, useLocation } from "wouter";
import { ReactNode, useState } from "react";
import { useHelperMode } from "@/contexts/HelperModeContext";
import { useAuth } from "@/contexts/AuthContext";
import {
  Home,
  HeartHandshake,
  PlusCircle,
  User,
  Bell,
  LogOut,
  MapPin,
  Zap,
  Trophy,
  Sparkles,
  Menu,
  X,
  DollarSign,
  Settings2,
  Navigation,
} from "lucide-react";
import { useLogout } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getGetMeQueryKey } from "@workspace/api-client-react";

export function AppLayout({ children }: { children: ReactNode }) {
  const { isHelperMode, setHelperMode } = useHelperMode();
  const { user } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const qc = useQueryClient();
  const logout = useLogout();

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => {
        qc.setQueryData(getGetMeQueryKey(), null);
        window.location.href = "/login";
      },
    });
  };

  const desktopNavItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/community", label: "Community", icon: HeartHandshake },
    { href: "/opportunities", label: "Community Missions", icon: Sparkles },
    { href: "/activity", label: "My Impact", icon: Bell },
    { href: "/leaderboard", label: "Leaderboard", icon: Trophy },
  ];

  const standardBottomNav = [
    { href: "/", label: "Home", icon: Home },
    { href: "/community", label: "Community", icon: HeartHandshake },
    { href: "/opportunities", label: "Missions", icon: Sparkles },
    { href: "/activity", label: "My Impact", icon: Bell },
    { href: "/profile", label: "Profile", icon: User },
  ];

  // Helper mode nav — Uber/DoorDash style: each tab is a distinct work destination
  // "/" = Dispatch (the patrol map — home shows PatrolView in helper mode)
  // "/opportunities" = All Missions (full browsable list with filters)
  // "/activity" = Earnings (job history, payment record, daily summary)
  // "/helper-mode" = Settings (availability, radius, services — purely settings now)
  // "/profile" = Profile (public helper profile, badges, stats)
  const helperBottomNav = [
    { href: "/", label: "Dispatch", icon: Navigation },
    { href: "/opportunities", label: "All Missions", icon: Sparkles },
    { href: "/activity", label: "Earnings", icon: DollarSign },
    { href: "/helper-mode", label: "Settings", icon: Settings2 },
    { href: "/profile", label: "Profile", icon: User },
  ];

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background relative pb-16 md:pb-0">
      {/* ── Standard Top Nav ── */}
      {!isHelperMode && (
        <header className="sticky top-0 z-50 w-full border-b bg-card/90 backdrop-blur-md">
          <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
            <Link href="/" className="font-serif font-bold text-xl text-primary flex items-center gap-2 shrink-0">
              <HeartHandshake className="w-6 h-6" />
              <span className="hidden sm:inline">Pay It Forward</span>
            </Link>

            <nav className="hidden md:flex items-center gap-5 flex-1 justify-center">
              {desktopNavItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`text-sm font-medium transition-colors hover:text-primary whitespace-nowrap ${
                    location === item.href ? "text-primary" : "text-muted-foreground"
                  }`}
                >
                  {item.label}
                </Link>
              ))}
              {(user?.role === "admin" || user?.role === "county") && (
                <Link href="/county" className="text-sm font-medium text-muted-foreground hover:text-primary">
                  County Portal
                </Link>
              )}
            </nav>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => setHelperMode(true)}
                className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-border text-xs font-semibold text-muted-foreground hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all"
                title="Switch to Helper Mode"
                data-testid="button-enable-helper-mode"
              >
                <Zap className="w-3.5 h-3.5" />
                Helper Mode
              </button>

              {user ? (
                <>
                  <Link
                    href="/post"
                    className="hidden md:flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm font-semibold hover:bg-primary/90 transition-colors"
                    data-testid="nav-ask-help"
                  >
                    <PlusCircle className="w-4 h-4" />
                    Ask for Help
                  </Link>
                  <Link href="/profile" className="hidden md:block">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold"
                      style={{ backgroundColor: user.avatar_color ?? "#4CAF50" }}
                    >
                      {user.avatar_initials ?? user.name.slice(0, 2).toUpperCase()}
                    </div>
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="hidden md:block text-muted-foreground hover:text-foreground"
                    title="Sign out"
                    data-testid="button-logout"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </>
              ) : (
                <Link
                  href="/login"
                  className="bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm font-semibold"
                  data-testid="nav-sign-in"
                >
                  Sign In
                </Link>
              )}

              <button
                className="md:hidden text-muted-foreground hover:text-foreground p-1"
                onClick={() => setMobileMenuOpen((v) => !v)}
                data-testid="button-mobile-menu"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {mobileMenuOpen && (
            <div className="md:hidden border-t bg-card px-4 py-3 space-y-1">
              {desktopNavItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    location === item.href ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </Link>
              ))}
              {(user?.role === "admin" || user?.role === "county") && (
                <Link href="/county" onClick={() => setMobileMenuOpen(false)} className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground">
                  County Portal
                </Link>
              )}
              <div className="border-t border-border pt-2 mt-2 flex flex-col gap-1">
                <button
                  onClick={() => { setHelperMode(true); setMobileMenuOpen(false); }}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold text-primary hover:bg-primary/10 transition-colors"
                  data-testid="button-mobile-helper-mode"
                >
                  <Zap className="w-4 h-4" /> Switch to Helper Mode
                </button>
                {user ? (
                  <button onClick={handleLogout} className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground">
                    <LogOut className="w-4 h-4" /> Sign Out
                  </button>
                ) : (
                  <Link href="/login" onClick={() => setMobileMenuOpen(false)} className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold text-primary">
                    Sign In
                  </Link>
                )}
              </div>
            </div>
          )}
        </header>
      )}

      {/* ── Helper Mode Header ── */}
      {isHelperMode && (
        <header className="sticky top-0 z-50 w-full bg-primary text-primary-foreground shadow-md">
          <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-300 animate-pulse" />
              <span className="font-bold text-sm">
                {user?.availability ?? "Online"} · Helper Mode
              </span>
            </div>
            <div className="flex items-center gap-3">
              <Link href="/helper-mode" className="text-primary-foreground/80 hover:text-white text-xs font-medium" data-testid="helper-mode-settings-link">
                Settings
              </Link>
              <button
                onClick={() => setHelperMode(false)}
                className="flex items-center gap-1 bg-white/15 hover:bg-white/25 rounded-full px-3 py-1 text-xs font-semibold transition-colors"
                data-testid="button-disable-helper-mode"
              >
                <Zap className="w-3 h-3" /> Exit
              </button>
              {user && (
                <button onClick={handleLogout} className="text-primary-foreground/70 hover:text-white" data-testid="helper-mode-logout">
                  <LogOut className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </header>
      )}

      <main className="flex-1 w-full max-w-5xl mx-auto p-4 md:p-6 lg:p-8">
        {children}
      </main>

      {/* ── Helper Mode Bottom Nav ── */}
      {isHelperMode && (
        <nav
          className="fixed bottom-0 left-0 right-0 bg-card border-t z-50 flex justify-around items-center py-2 px-2"
          style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}
          data-testid="helper-mode-bottom-nav"
        >
          {helperBottomNav.map((navItem) => (
            <Link
              key={navItem.href}
              href={navItem.href}
              className={`flex flex-col items-center gap-0.5 px-2 py-1 rounded-lg transition-colors min-w-[48px] ${
                location === navItem.href ? "text-primary" : "text-muted-foreground"
              }`}
              data-testid={`helper-nav-${navItem.label.toLowerCase().replace(/ /g, "-")}`}
            >
              <navItem.icon className="w-5 h-5" />
              <span className="text-[10px] font-medium">{navItem.label}</span>
            </Link>
          ))}
        </nav>
      )}

      {/* ── Standard Bottom Nav (mobile) ── */}
      {!isHelperMode && (
        <nav
          className="md:hidden fixed bottom-0 left-0 right-0 bg-card border-t z-50 flex justify-around items-center py-2"
          style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}
          data-testid="standard-bottom-nav"
        >
          {standardBottomNav.map((navItem, idx) => {
            if (idx === 2) {
              return (
                <div key="fab" className="flex flex-col items-center -mt-5">
                  <Link
                    href="/post"
                    className="w-12 h-12 bg-primary text-primary-foreground rounded-full shadow-lg flex items-center justify-center hover:bg-primary/90 transition-colors"
                    data-testid="nav-fab-post"
                  >
                    <PlusCircle className="w-6 h-6" />
                  </Link>
                  <span className="text-[10px] font-medium text-muted-foreground mt-1">Post</span>
                </div>
              );
            }
            return (
              <Link
                key={navItem.href}
                href={navItem.href}
                className={`flex flex-col items-center gap-0.5 px-2 py-1 min-w-[48px] transition-colors ${
                  location === navItem.href ? "text-primary" : "text-muted-foreground"
                }`}
                data-testid={`nav-${navItem.label.toLowerCase().replace(/ /g, "-")}`}
              >
                <navItem.icon className="w-5 h-5" />
                <span className="text-[10px] font-medium">{navItem.label}</span>
              </Link>
            );
          })}
        </nav>
      )}

      {/* ── Helper Mode FAB (post a request while on duty) ── */}
      {isHelperMode && location !== "/post" && (
        <Link
          href="/post"
          className="fixed bottom-20 right-5 w-14 h-14 bg-secondary text-secondary-foreground rounded-full shadow-xl flex items-center justify-center hover:scale-105 active:scale-95 transition-transform z-50"
          data-testid="helper-mode-fab"
        >
          <PlusCircle className="w-6 h-6" />
        </Link>
      )}
    </div>
  );
}
