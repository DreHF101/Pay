import { CheckCircle2, Shield, Star, Zap } from "lucide-react";

export interface ReputationUser {
  trust_level: string;
  help_count: number;
  volunteer_hours: number;
  reliability_pct: number;
  is_verified: boolean;
  email_verified: boolean;
  phone_verified: boolean;
  id_verified: boolean;
  background_checked: boolean;
  community_trusted: boolean;
}

const TRUST_META: Record<string, { label: string; color: string; bg: string; stars: number }> = {
  community_leader: { label: "Community Hero", color: "text-purple-700", bg: "bg-purple-100", stars: 5 },
  trusted:          { label: "Trusted Neighbor", color: "text-green-700", bg: "bg-green-100", stars: 4 },
  verified:         { label: "Verified Neighbor", color: "text-blue-700", bg: "bg-blue-100", stars: 3 },
  newcomer:         { label: "New Neighbor", color: "text-amber-700", bg: "bg-amber-100", stars: 2 },
};

function reliabilityColor(pct: number) {
  if (pct >= 95) return "text-green-600";
  if (pct >= 85) return "text-amber-600";
  return "text-red-500";
}

function reliabilityBarColor(pct: number) {
  if (pct >= 95) return "bg-green-500";
  if (pct >= 85) return "bg-amber-500";
  return "bg-red-500";
}

/* ─── Full version — used on Profile page ─── */
export function ReputationCard({ user }: { user: ReputationUser }) {
  const meta = TRUST_META[user.trust_level] ?? TRUST_META["newcomer"]!;
  const trustScore = Math.min(
    999,
    user.help_count * 8 + user.volunteer_hours * 2 + (user.is_verified ? 100 : 0)
  );

  const verifs = [
    { key: "email_verified", label: "Email", done: user.email_verified },
    { key: "phone_verified", label: "Phone", done: user.phone_verified },
    { key: "id_verified", label: "ID", done: user.id_verified },
    { key: "background_checked", label: "BGC", done: user.background_checked },
    { key: "community_trusted", label: "Community", done: user.community_trusted },
  ];

  return (
    <div className="bg-card border border-border rounded-2xl p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center gap-2">
        <Shield className="w-4 h-4 text-primary" />
        <span className="font-semibold text-sm">Reputation Economy</span>
      </div>

      {/* Trust Score + Level */}
      <div className="flex items-center justify-between">
        <div>
          <div className={`text-3xl font-bold ${meta.color}`}>{trustScore}</div>
          <div className="text-xs text-muted-foreground">Trust Score</div>
        </div>
        <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${meta.bg} ${meta.color}`}>
          {meta.label}
        </span>
      </div>

      {/* Stars */}
      <div className="flex gap-0.5">
        {[1, 2, 3, 4, 5].map((i) => (
          <Star
            key={i}
            className={`w-4 h-4 ${i <= meta.stars ? `${meta.color} fill-current` : "text-muted-foreground/30"}`}
          />
        ))}
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="bg-muted/50 rounded-xl p-2">
          <div className={`text-xl font-bold ${meta.color}`}>{user.help_count}</div>
          <div className="text-xs text-muted-foreground">Jobs Done</div>
        </div>
        <div className="bg-muted/50 rounded-xl p-2">
          <div className="text-xl font-bold text-amber-600">{user.volunteer_hours}</div>
          <div className="text-xs text-muted-foreground">Hours</div>
        </div>
        <div className="bg-muted/50 rounded-xl p-2">
          <div className={`text-xl font-bold ${reliabilityColor(user.reliability_pct)}`}>
            {user.reliability_pct}%
          </div>
          <div className="text-xs text-muted-foreground">Reliability</div>
        </div>
      </div>

      {/* Reliability bar */}
      <div>
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs text-muted-foreground">Reliability Rate</span>
          <span className={`text-xs font-semibold ${reliabilityColor(user.reliability_pct)}`}>
            {user.reliability_pct}%
          </span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all ${reliabilityBarColor(user.reliability_pct)}`}
            style={{ width: `${user.reliability_pct}%` }}
          />
        </div>
      </div>

      {/* Verification badges */}
      <div>
        <div className="text-xs text-muted-foreground mb-2">Verification Badges</div>
        <div className="flex flex-wrap gap-1.5">
          {verifs.map((v) => (
            <span
              key={v.key}
              className={`inline-flex items-center gap-0.5 text-xs px-2 py-0.5 rounded-full border font-medium ${
                v.done
                  ? "bg-green-50 text-green-700 border-green-200"
                  : "bg-muted text-muted-foreground border-border opacity-50"
              }`}
            >
              {v.done ? <CheckCircle2 className="w-3 h-3" /> : null}
              {v.label}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── Compact version — used on request cards ─── */
export function ReputationMini({
  user,
  label = "Requester",
}: {
  user: ReputationUser;
  label?: string;
}) {
  const meta = TRUST_META[user.trust_level] ?? TRUST_META["newcomer"]!;

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <span className="text-xs text-muted-foreground">{label}:</span>
      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${meta.bg} ${meta.color}`}>
        {meta.label}
      </span>
      {user.is_verified && (
        <span className="flex items-center gap-0.5 text-xs text-primary font-medium">
          <CheckCircle2 className="w-3 h-3" />
          Verified
        </span>
      )}
      <span className={`text-xs font-semibold ${reliabilityColor(user.reliability_pct)}`}>
        {user.reliability_pct}% reliable
      </span>
      {user.background_checked && (
        <span className="flex items-center gap-0.5 text-xs text-blue-600 font-medium">
          <Shield className="w-3 h-3" />
          BGC
        </span>
      )}
      {user.help_count > 10 && (
        <span className="flex items-center gap-0.5 text-xs text-amber-600 font-medium">
          <Zap className="w-3 h-3" />
          {user.help_count} jobs
        </span>
      )}
    </div>
  );
}
