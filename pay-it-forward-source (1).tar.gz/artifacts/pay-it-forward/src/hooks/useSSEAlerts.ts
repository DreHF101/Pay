import { useEffect, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { getListRequestsQueryKey, getGetActivityFeedQueryKey } from "@workspace/api-client-react";

interface UrgentRequestPayload {
  id: number;
  title: string;
  description: string;
  category: string;
  neighborhood: string;
  urgency: "emergency" | "urgent";
  funding_source: string;
  budget: number | null;
  requester_name: string | null;
  created_at: string;
}

const URGENCY_EMOJI: Record<string, string> = {
  emergency: "🚨",
  urgent: "⚡",
};

/**
 * Connects to /api/events/stream (SSE) and shows a toast when an
 * emergency or urgent neighbor request is posted anywhere in Fort Worth.
 *
 * Also invalidates the requests query so the list auto-refreshes.
 *
 * Reconnects automatically with exponential back-off on disconnect.
 */
export function useSSEAlerts() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const retryMs = useRef(1000);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    let source: EventSource | null = null;
    let destroyed = false;

    function connect() {
      if (destroyed) return;

      const base = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");
      const url = `${base}/api/events/stream`;

      source = new EventSource(url);

      source.addEventListener("new_urgent_request", (evt: MessageEvent) => {
        try {
          const data = JSON.parse(evt.data) as UrgentRequestPayload;
          const emoji = URGENCY_EMOJI[data.urgency] ?? "⚡";
          const label = data.urgency === "emergency" ? "Emergency" : "Urgent";

          toast({
            title: `${emoji} ${label} — ${data.neighborhood}`,
            description: data.title,
            duration: 10_000,
          });

          // Refresh the requests list so the new card appears immediately
          qc.invalidateQueries({ queryKey: getListRequestsQueryKey() });
          qc.invalidateQueries({ queryKey: getGetActivityFeedQueryKey() });

          retryMs.current = 1000; // reset back-off on success
        } catch {
          // Ignore parse errors
        }
      });

      source.addEventListener("info", (evt: MessageEvent) => {
        try {
          const data = JSON.parse(evt.data) as { clients: number; message: string };
          console.info(`[SSE] ${data.message} (${data.clients} helpers online)`);
        } catch {
          // Ignore
        }
      });

      source.onerror = () => {
        source?.close();
        source = null;
        if (!destroyed) {
          // Exponential back-off: 1s → 2s → 4s → 8s → 30s max
          timerRef.current = setTimeout(() => {
            retryMs.current = Math.min(retryMs.current * 2, 30_000);
            connect();
          }, retryMs.current);
        }
      };
    }

    connect();

    return () => {
      destroyed = true;
      source?.close();
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [toast, qc]);
}
