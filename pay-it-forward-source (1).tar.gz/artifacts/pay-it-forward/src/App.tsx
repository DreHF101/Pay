import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { HelperModeProvider } from "@/contexts/HelperModeContext";
import { AppLayout } from "@/components/layout/AppLayout";
import { useSSEAlerts } from "@/hooks/useSSEAlerts";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home";
import CommunityPage from "@/pages/community";
import PostPage from "@/pages/post";
import OpportunitiesPage from "@/pages/opportunities";
import HelperModePage from "@/pages/helper-mode";
import ActivityPage from "@/pages/activity";
import CountyPage from "@/pages/county";
import ProfilePage from "@/pages/profile";
import LeaderboardPage from "@/pages/leaderboard";
import LoginPage from "@/pages/login";
import RegisterPage from "@/pages/register";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
    },
  },
});

function AlertsWatcher() {
  useSSEAlerts();
  return null;
}

function Router() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/community" component={CommunityPage} />
        <Route path="/post" component={PostPage} />
        <Route path="/opportunities" component={OpportunitiesPage} />
        <Route path="/helper-mode" component={HelperModePage} />
        <Route path="/activity" component={ActivityPage} />
        <Route path="/county" component={CountyPage} />
        <Route path="/profile" component={ProfilePage} />
        <Route path="/leaderboard" component={LeaderboardPage} />
        <Route path="/login" component={LoginPage} />
        <Route path="/register" component={RegisterPage} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <HelperModeProvider>
          <TooltipProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <AlertsWatcher />
              <Router />
            </WouterRouter>
            <Toaster />
          </TooltipProvider>
        </HelperModeProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
