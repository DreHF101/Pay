import { useState } from "react";
import { motion } from "framer-motion";
import {
  useListRequests, useCreateJob,
  getListRequestsQueryKey, getListJobsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { useHelperMode } from "@/contexts/HelperModeContext";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { MapPin, Clock, Zap, CheckCircle2, Filter, HeartHandshake, Shield } from "lucide-react";
import { ReputationMini } from "@/components/ReputationBadges";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

const URGENCY_COLORS: Record<string, string> = {
  emergency: "bg-red-100 text-red-700 border-red-200",
  urgent: "bg-orange-100 text-orange-700 border-orange-200",
  normal: "bg-blue-100 text-blue-700 border-blue-200",
  low: "bg-muted text-muted-foreground",
};

const FUNDING_LABELS: Record<string, string> = {
  community_fund: "Community Fund",
  pay_forward: "Pay It Forward",
  volunteer: "Volunteer",
  direct: "Direct Pay",
};

const FUNDING_COLORS: Record<string, string> = {
  community_fund: "bg-primary/10 text-primary",
  pay_forward: "bg-secondary/20 text-secondary-foreground",
  volunteer: "bg-green-100 text-green-700",
  direct: "bg-muted text-muted-foreground",
};

const CATEGORIES = [
  "Transportation", "Food Delivery", "Elder Care", "Childcare", "Home Repairs",
  "Moving", "Financial Assistance", "Yard Work", "Technology Help", "Pet Care",
  "Medical", "Mental Health", "Education", "Other",
];

const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.06 } } };
const item = { hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0, transition: { duration: 0.3 } } };

export default function OpportunitiesPage() {
  const { user } = useAuth();
  const { isHelperMode } = useHelperMode();
  const { toast } = useToast();
  const qc = useQueryClient();

  // "" = no filter (show all) — never initialize to a label string
  const [category, setCategory] = useState("");
  const [urgency, setUrgency] = useState("");
  const [fundingSource, setFundingSource] = useState("");
  const [claimedIds, setClaimedIds] = useState<Set<number>>(new Set());

  const params: Record<string, string> = { status: "open" };
  if (category) params["category"] = category;
  if (urgency) params["urgency"] = urgency;
  if (fundingSource) params["funding_source"] = fundingSource;

  const { data: requests, isLoading } = useListRequests(params, {
    query: { queryKey: getListRequestsQueryKey(params) },
  });

  const createJob = useCreateJob();

  function handleHelp(requestId: number) {
    if (!user) {
      toast({
        title: "Sign in to help",
        description: "Create a free account to help your neighbors.",
        variant: "destructive",
      });
      return;
    }
    createJob.mutate({ data: { request_id: requestId } }, {
      onSuccess: () => {
        setClaimedIds((prev) => new Set([...prev, requestId]));
        qc.invalidateQueries({ queryKey: getListRequestsQueryKey() });
        qc.invalidateQueries({ queryKey: getListJobsQueryKey() });
        toast({
          title: "You're helping a neighbor!",
          description: "They've been notified. Thank you for stepping up.",
        });
      },
      onError: (err: any) => {
        toast({
          title: "Could not take this request",
          description: err?.data?.error ?? "Try again.",
          variant: "destructive",
        });
      },
    });
  }

  // In Helper Mode, sort by simulated distance
  const sorted = isHelperMode
    ? [...(requests ?? [])].sort((a, b) => (a.id % 5) - (b.id % 5))
    : (requests ?? []);

  const emergencyCount = sorted.filter((r) => r.urgency === "emergency").length;
  const filtersActive = !!(category || urgency || fundingSource);

  return (
    <div className="pb-8">
      {/* ── Page header ── */}
      <div className="mb-5">
        <h1 className="font-serif text-2xl font-bold mb-1">
          {isHelperMode ? "Nearby Requests" : "Help a Neighbor"}
        </h1>
        <p className="text-sm text-muted-foreground">
          {isHelperMode
            ? "Your neighbors are nearby and need your help today"
            : "Real people in Fort Worth who could use a hand"}
        </p>
      </div>

      {/* ── Emergency banner ── */}
      {emergencyCount > 0 && (
        <div className="flex items-center gap-3 bg-red-50 border border-red-200 rounded-xl px-4 py-3 mb-4">
          <Zap className="w-4 h-4 text-red-600 shrink-0 animate-pulse" />
          <p className="text-sm text-red-700 font-medium">
            {emergencyCount} emergency request{emergencyCount !== 1 ? "s" : ""} — please respond if you can
          </p>
        </div>
      )}

      {/* ── Filters ── */}
      <div className="flex flex-wrap gap-2 mb-5 p-3 bg-muted/40 rounded-xl items-center">
        <Filter className="w-3.5 h-3.5 text-muted-foreground shrink-0" />

        <Select
          value={category || "all"}
          onValueChange={(v) => setCategory(v === "all" ? "" : v)}
        >
          <SelectTrigger className="w-auto h-8 text-xs bg-card min-w-[130px]" data-testid="filter-category">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {CATEGORIES.map((c) => (
              <SelectItem key={c} value={c}>{c}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={urgency || "all"}
          onValueChange={(v) => setUrgency(v === "all" ? "" : v)}
        >
          <SelectTrigger className="w-auto h-8 text-xs bg-card min-w-[110px]" data-testid="filter-urgency">
            <SelectValue placeholder="Any Urgency" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Any Urgency</SelectItem>
            <SelectItem value="emergency">Emergency</SelectItem>
            <SelectItem value="urgent">Urgent</SelectItem>
            <SelectItem value="normal">Normal</SelectItem>
            <SelectItem value="low">Low</SelectItem>
          </SelectContent>
        </Select>

        <Select
          value={fundingSource || "all"}
          onValueChange={(v) => setFundingSource(v === "all" ? "" : v)}
        >
          <SelectTrigger className="w-auto h-8 text-xs bg-card min-w-[120px]" data-testid="filter-funding">
            <SelectValue placeholder="Any Funding" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Any Funding</SelectItem>
            <SelectItem value="volunteer">Volunteer</SelectItem>
            <SelectItem value="direct">Direct Pay</SelectItem>
            <SelectItem value="community_fund">Community Fund</SelectItem>
            <SelectItem value="pay_forward">Pay It Forward</SelectItem>
          </SelectContent>
        </Select>

        {filtersActive && (
          <button
            className="text-xs text-muted-foreground underline hover:text-foreground"
            onClick={() => { setCategory(""); setUrgency(""); setFundingSource(""); }}
            data-testid="button-clear-filters"
          >
            Clear
          </button>
        )}
      </div>

      {/* ── Results ── */}
      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-36 rounded-xl" />)}
        </div>
      ) : sorted.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <CheckCircle2 className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="font-medium">
            {filtersActive ? "No requests match those filters" : "No open requests right now"}
          </p>
          <p className="text-sm">
            {filtersActive ? "Try clearing the filters." : "Check back soon — or post a request."}
          </p>
          {!filtersActive && (
            <Link href="/post">
              <Button className="mt-4">Post a Request</Button>
            </Link>
          )}
        </div>
      ) : (
        <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-3">
          {sorted.map((req) => {
            const alreadyHelping = claimedIds.has(req.id) || req.status !== "open";
            // Simulated distance in Helper Mode (0.3–3.0 miles)
            const distMi = isHelperMode ? (((req.id * 7 + 3) % 28) / 10 + 0.3).toFixed(1) : null;

            return (
              <motion.div key={req.id} variants={item}>
                <div
                  className={`bg-card border rounded-xl p-4 transition-colors ${
                    alreadyHelping
                      ? "border-green-200 bg-green-50/30"
                      : "border-card-border hover:border-primary/40"
                  }`}
                  data-testid={`card-request-${req.id}`}
                >
                  <div className="flex items-start gap-3">
                    {/* Left: text */}
                    <div className="flex-1 min-w-0">
                      {/* Badges row */}
                      <div className="flex flex-wrap items-center gap-1.5 mb-1.5">
                        {req.urgency === "emergency" && (
                          <span className="flex items-center gap-0.5 text-xs font-bold text-red-600 animate-pulse">
                            <Zap className="w-3 h-3" /> EMERGENCY
                          </span>
                        )}
                        <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${URGENCY_COLORS[req.urgency] ?? ""}`}>
                          {req.urgency.charAt(0).toUpperCase() + req.urgency.slice(1)}
                        </span>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${FUNDING_COLORS[req.funding_source] ?? ""}`}>
                          {FUNDING_LABELS[req.funding_source] ?? req.funding_source}
                        </span>
                        <Badge variant="secondary" className="text-xs">{req.category}</Badge>
                        {distMi && (
                          <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium">
                            {distMi} mi
                          </span>
                        )}
                        {req.recurring && req.recurring !== "one_time" && (
                          <span className="text-xs text-primary font-medium capitalize">{req.recurring}</span>
                        )}
                      </div>

                      <h3 className="font-semibold text-sm leading-snug">{req.title}</h3>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{req.description}</p>

                      <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />{req.neighborhood}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(req.created_at).toLocaleDateString()}
                        </span>
                        {!req.is_anonymous && req.requester_name && (
                          <span>by {req.requester_name}</span>
                        )}
                      </div>

                      {/* Requester reputation mini-badges */}
                      {!req.is_anonymous && req.requester_trust_level && (
                        <div className="mt-2 pt-2 border-t border-border/60">
                          <ReputationMini
                            user={{
                              trust_level: req.requester_trust_level,
                              help_count: req.requester_help_count ?? 0,
                              volunteer_hours: 0,
                              reliability_pct: req.requester_reliability_pct ?? 90,
                              is_verified: req.requester_is_verified,
                              email_verified: false,
                              phone_verified: false,
                              id_verified: false,
                              background_checked: req.requester_background_checked,
                              community_trusted: false,
                            }}
                            label="Requester"
                          />
                        </div>
                      )}
                    </div>

                    {/* Right: budget + action */}
                    <div className="flex flex-col items-end gap-2 shrink-0">
                      {req.budget != null && (
                        <span className="text-sm font-bold text-foreground">${req.budget}</span>
                      )}
                      {alreadyHelping ? (
                        <span className="flex items-center gap-1 text-xs text-green-600 font-medium whitespace-nowrap">
                          <CheckCircle2 className="w-4 h-4" /> Helping!
                        </span>
                      ) : (
                        <Button
                          size="sm"
                          onClick={() => handleHelp(req.id)}
                          disabled={createJob.isPending}
                          data-testid={`button-help-${req.id}`}
                          className="whitespace-nowrap"
                        >
                          <HeartHandshake className="w-3.5 h-3.5 mr-1" />
                          I Can Help
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      )}

      {sorted.length > 0 && (
        <p className="text-center text-xs text-muted-foreground mt-6">
          {sorted.length} neighbor request{sorted.length !== 1 ? "s" : ""} in Fort Worth
        </p>
      )}
    </div>
  );
}
