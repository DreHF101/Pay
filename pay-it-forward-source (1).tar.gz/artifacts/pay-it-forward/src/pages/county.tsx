import { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  useGetCountyReport, useListFundRequests, useApproveFundRequest, useDenyFundRequest,
  useLogin, getGetMeQueryKey, getGetCountyReportQueryKey, getListFundRequestsQueryKey,
  getGetCommunityFundQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Building2, CheckCircle2, XCircle, Download, BarChart3, FileText,
  Users, MapPin, AlertTriangle, Loader2, LogIn, Lock,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.07 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0 } };

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export default function CountyPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [zipCode, setZipCode] = useState("");
  const [filterZip, setFilterZip] = useState("");

  const isAdmin = user?.role === "admin" || user?.role === "county";

  const { data: report, isLoading: reportLoading } = useGetCountyReport(
    filterZip ? { zip_code: filterZip } : {},
    { query: { queryKey: getGetCountyReportQueryKey(filterZip ? { zip_code: filterZip } : {}) } }
  );

  const { data: pendingRequests } = useListFundRequests(
    { status: "open" },
    { query: { enabled: isAdmin, queryKey: getListFundRequestsQueryKey({ status: "open" }) } }
  );

  const approveFund = useApproveFundRequest();
  const denyFund = useDenyFundRequest();
  const login = useLogin();

  const form = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  function handleAdminLogin(values: z.infer<typeof loginSchema>) {
    login.mutate({ data: values }, {
      onSuccess: (u) => {
        qc.setQueryData(getGetMeQueryKey(), u);
        if (u.role !== "admin" && u.role !== "county") {
          toast({ title: "Access denied", description: "This portal requires admin credentials.", variant: "destructive" });
          qc.setQueryData(getGetMeQueryKey(), null);
        } else {
          toast({ title: "Welcome", description: `Signed in as ${u.name}` });
        }
      },
      onError: () => toast({ title: "Login failed", description: "Invalid credentials.", variant: "destructive" }),
    });
  }

  function handleApprove(id: number) {
    approveFund.mutate({ id }, {
      onSuccess: (r) => {
        qc.invalidateQueries({ queryKey: getListFundRequestsQueryKey() });
        qc.invalidateQueries({ queryKey: getGetCommunityFundQueryKey() });
        toast({ title: "Approved!", description: `$${r.amount_disbursed ?? 0} disbursed from community fund.` });
      },
    });
  }

  function handleDeny(id: number) {
    denyFund.mutate({ id }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListFundRequestsQueryKey() });
        toast({ title: "Request denied." });
      },
    });
  }

  function handleExport() {
    if (!report) return;
    const rows = [
      ["Title", "Category", "Status", "Neighborhood", "Funding Source", "Budget", "Created"],
      ...report.recent_requests.map((r) => [
        r.title, r.category, r.status, r.neighborhood,
        r.funding_source, r.budget ?? "", new Date(r.created_at).toLocaleDateString(),
      ]),
    ];
    const csv = rows.map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `pif-county-report-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    toast({ title: "Report exported", description: "CSV downloaded to your device." });
  }

  return (
    <div className="pb-8 max-w-3xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <Building2 className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h1 className="font-serif text-2xl font-bold">County Government Portal</h1>
          <p className="text-sm text-muted-foreground">Tarrant County Community Services — Fort Worth, TX</p>
        </div>
      </div>

      {/* Admin Login */}
      {!isAdmin && (
        <div className="bg-card border border-card-border rounded-2xl p-6 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Lock className="w-4 h-4 text-muted-foreground" />
            <h3 className="font-semibold">Admin Access</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            Sign in with county administrator credentials to approve fund requests and access full reporting.
          </p>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleAdminLogin)} className="flex flex-col sm:flex-row gap-3">
              <FormField control={form.control} name="email" render={({ field }) => (
                <FormItem className="flex-1">
                  <FormControl>
                    <Input type="email" placeholder="county@example.com" {...field} data-testid="input-admin-email" />
                  </FormControl>
                </FormItem>
              )} />
              <FormField control={form.control} name="password" render={({ field }) => (
                <FormItem className="flex-1">
                  <FormControl>
                    <Input type="password" placeholder="Password" {...field} data-testid="input-admin-password" />
                  </FormControl>
                </FormItem>
              )} />
              <Button type="submit" disabled={login.isPending} className="w-full sm:w-auto" data-testid="button-admin-login">
                {login.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <><LogIn className="w-4 h-4 mr-1" /> Sign In</>}
              </Button>
            </form>
          </Form>
          <p className="text-xs text-muted-foreground mt-2">
            Demo: <code className="bg-muted px-1 rounded">county@example.com</code> / <code className="bg-muted px-1 rounded">password</code>
          </p>
        </div>
      )}

      {/* Admin: Pending fund requests */}
      {isAdmin && (pendingRequests ?? []).length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 mb-6">
          <h3 className="font-semibold text-amber-800 mb-4 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" />
            Pending Fund Requests ({pendingRequests?.length})
          </h3>
          <div className="space-y-3">
            {(pendingRequests ?? []).map((req) => (
              <div key={req.id} className="flex items-center justify-between bg-white rounded-xl p-4 border border-amber-100">
                <div>
                  <p className="font-semibold text-sm">{req.title}</p>
                  <div className="flex gap-2 mt-1 text-xs text-muted-foreground">
                    <span>{req.neighborhood}</span>
                    <span>{req.category}</span>
                    {req.budget && <span className="font-semibold text-foreground">${req.budget}</span>}
                  </div>
                  {req.description && <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{req.description}</p>}
                </div>
                <div className="flex gap-2 shrink-0 ml-4">
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-destructive border-destructive/30 hover:bg-destructive/5 h-8 text-xs"
                    onClick={() => handleDeny(req.id)}
                    data-testid={`button-deny-${req.id}`}
                  >
                    <XCircle className="w-3.5 h-3.5 mr-1" /> Deny
                  </Button>
                  <Button
                    size="sm"
                    className="h-8 text-xs"
                    onClick={() => handleApprove(req.id)}
                    data-testid={`button-approve-${req.id}`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Approve
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Report filters */}
      <div className="bg-card border border-card-border rounded-2xl p-5 mb-6">
        <h3 className="font-semibold mb-3 flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-primary" />
          Community Report
          {isAdmin && (
            <Badge variant="secondary" className="ml-auto">CDBG Eligible Data</Badge>
          )}
        </h3>
        <div className="flex gap-2">
          <Input
            placeholder="Filter by ZIP code (optional)"
            value={zipCode}
            onChange={(e) => setZipCode(e.target.value)}
            data-testid="input-zip-filter"
          />
          <Button variant="outline" onClick={() => setFilterZip(zipCode)} data-testid="button-filter-zip">
            Filter
          </Button>
          {filterZip && (
            <Button variant="ghost" onClick={() => { setFilterZip(""); setZipCode(""); }}>
              Clear
            </Button>
          )}
        </div>
      </div>

      {reportLoading ? (
        <div className="space-y-3">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 rounded-xl" />)}</div>
      ) : report ? (
        <div className="space-y-6">
          {/* Summary stats */}
          <motion.div variants={stagger} initial="hidden" animate="show" className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: "Total Requests", value: report.total_requests, color: "text-foreground" },
              { label: "Open", value: report.open_requests, color: "text-amber-600" },
              { label: "Funded", value: report.funded_requests, color: "text-primary" },
              { label: "Completed", value: report.completed_requests, color: "text-green-600" },
            ].map((s) => (
              <motion.div key={s.label} variants={item} className="bg-card border border-card-border rounded-xl p-4 text-center">
                <div className={`text-2xl font-bold ${s.color}`}>{s.value}</div>
                <div className="text-xs text-muted-foreground">{s.label}</div>
              </motion.div>
            ))}
          </motion.div>

          {/* Fund summary */}
          <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 flex flex-wrap gap-6">
            <div>
              <p className="text-xs text-muted-foreground">Community Fund Balance</p>
              <p className="text-2xl font-bold text-primary">${report.community_fund_balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Total Disbursed (CDBG)</p>
              <p className="text-2xl font-bold">${report.total_disbursed.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
            </div>
          </div>

          {/* Top categories */}
          <div className="bg-card border border-card-border rounded-xl p-5">
            <h4 className="font-semibold text-sm mb-3">Top Request Categories</h4>
            <div className="space-y-2">
              {report.top_categories.map((cat) => (
                <div key={cat.category} className="flex items-center gap-3">
                  <span className="text-sm text-muted-foreground w-32">{cat.category}</span>
                  <div className="flex-1 bg-muted rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-primary h-2 rounded-full"
                      style={{ width: `${Math.min(100, (cat.count / report.total_requests) * 100)}%` }}
                    />
                  </div>
                  <span className="text-sm font-bold w-6 text-right">{cat.count}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Export */}
          <div className="flex justify-end">
            <Button variant="outline" onClick={handleExport} data-testid="button-export-report">
              <Download className="w-4 h-4 mr-2" />
              Export CSV Report
            </Button>
          </div>

          {/* Recent requests table */}
          <div className="bg-card border border-card-border rounded-xl overflow-hidden">
            <div className="px-5 py-3 border-b border-border flex items-center justify-between">
              <h4 className="font-semibold text-sm flex items-center gap-2">
                <FileText className="w-4 h-4 text-muted-foreground" />
                Recent Requests
              </h4>
              <span className="text-xs text-muted-foreground">Last 20</span>
            </div>
            <div className="divide-y divide-border">
              {report.recent_requests.slice(0, 10).map((req) => (
                <div key={req.id} className="flex items-center gap-4 px-5 py-3">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{req.title}</p>
                    <p className="text-xs text-muted-foreground">{req.neighborhood} • {req.category}</p>
                  </div>
                  <Badge variant="outline" className="text-xs capitalize shrink-0">
                    {req.status.replace("_", " ")}
                  </Badge>
                  {req.budget && <span className="text-xs font-bold shrink-0">${req.budget}</span>}
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
