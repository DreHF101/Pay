import { useState } from "react";
import { motion } from "framer-motion";
import { useGetLeaderboard, getGetLeaderboardQueryKey } from "@workspace/api-client-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle2, Trophy, HandCoins, Timer } from "lucide-react";

const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.07 } } };
const item = { hidden: { opacity: 0, x: -10 }, show: { opacity: 1, x: 0 } };

const TRUST_COLORS: Record<string, string> = {
  newcomer: "bg-muted text-muted-foreground",
  verified: "bg-blue-100 text-blue-700",
  trusted: "bg-green-100 text-green-700",
  community_leader: "bg-purple-100 text-purple-700",
};

function RankBadge({ rank }: { rank: number }) {
  if (rank === 1) return <span className="text-lg">🥇</span>;
  if (rank === 2) return <span className="text-lg">🥈</span>;
  if (rank === 3) return <span className="text-lg">🥉</span>;
  return <span className="w-6 text-sm font-bold text-muted-foreground text-center">{rank}</span>;
}

export default function LeaderboardPage() {
  const { data, isLoading } = useGetLeaderboard({}, {
    query: { queryKey: getGetLeaderboardQueryKey({}) },
  });

  return (
    <div className="pb-8">
      <div className="mb-6">
        <h1 className="font-serif text-2xl font-bold mb-1">Community Leaderboard</h1>
        <p className="text-sm text-muted-foreground">Celebrating Fort Worth's most dedicated neighbors</p>
      </div>

      <Tabs defaultValue="helpers">
        <TabsList className="w-full grid grid-cols-2 mb-6">
          <TabsTrigger value="helpers" data-testid="tab-top-helpers">
            <Trophy className="w-3.5 h-3.5 mr-1.5" /> Top Helpers
          </TabsTrigger>
          <TabsTrigger value="contributors" data-testid="tab-top-contributors">
            <HandCoins className="w-3.5 h-3.5 mr-1.5" /> Top Contributors
          </TabsTrigger>
        </TabsList>

        <TabsContent value="helpers">
          {isLoading ? (
            <div className="space-y-3">{[1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-16 rounded-xl" />)}</div>
          ) : (
            <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-2">
              {(data?.top_helpers ?? []).map((entry, idx) => (
                <motion.div
                  key={entry.id}
                  variants={item}
                  className={`flex items-center gap-4 p-4 rounded-xl border transition-colors ${
                    idx === 0 ? "bg-amber-50 border-amber-200" : "bg-card border-card-border"
                  }`}
                  data-testid={`leaderboard-helper-${entry.id}`}
                >
                  <RankBadge rank={idx + 1} />
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-sm font-bold shrink-0"
                    style={{ backgroundColor: entry.avatar_color ?? "#4CAF50" }}
                  >
                    {entry.avatar_initials ?? entry.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-sm">{entry.name}</span>
                      {entry.is_verified && <CheckCircle2 className="w-3.5 h-3.5 text-primary" />}
                      <Badge className={`text-xs ${TRUST_COLORS[entry.trust_level] ?? ""}`}>
                        {entry.trust_level.replace("_", " ")}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{entry.neighborhood}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-bold text-primary text-lg">{entry.help_count}</p>
                    <p className="text-xs text-muted-foreground">helps</p>
                    {entry.volunteer_hours > 0 && (
                      <p className="text-xs text-muted-foreground flex items-center gap-0.5 justify-end">
                        <Timer className="w-3 h-3" />{entry.volunteer_hours}h
                      </p>
                    )}
                  </div>
                </motion.div>
              ))}
              {(data?.top_helpers ?? []).length === 0 && (
                <div className="text-center py-14 text-muted-foreground">
                  <Trophy className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  <p>No helpers yet. Be the first!</p>
                </div>
              )}
            </motion.div>
          )}
        </TabsContent>

        <TabsContent value="contributors">
          {isLoading ? (
            <div className="space-y-3">{[1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-16 rounded-xl" />)}</div>
          ) : (
            <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-2">
              {(data?.top_contributors ?? []).map((entry, idx) => (
                <motion.div
                  key={entry.id}
                  variants={item}
                  className={`flex items-center gap-4 p-4 rounded-xl border transition-colors ${
                    idx === 0 ? "bg-green-50 border-green-200" : "bg-card border-card-border"
                  }`}
                  data-testid={`leaderboard-contributor-${entry.id}`}
                >
                  <RankBadge rank={idx + 1} />
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-sm font-bold shrink-0"
                    style={{ backgroundColor: entry.avatar_color ?? "#4CAF50" }}
                  >
                    {entry.avatar_initials ?? entry.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-sm">{entry.name}</span>
                      {entry.is_verified && <CheckCircle2 className="w-3.5 h-3.5 text-primary" />}
                    </div>
                    <p className="text-xs text-muted-foreground">{entry.neighborhood}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-bold text-green-600 text-lg">${entry.pay_forward_total.toFixed(0)}</p>
                    <p className="text-xs text-muted-foreground">paid forward</p>
                  </div>
                </motion.div>
              ))}
              {(data?.top_contributors ?? []).length === 0 && (
                <div className="text-center py-14 text-muted-foreground">
                  <HandCoins className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  <p>No contributions yet. Be the first!</p>
                </div>
              )}
            </motion.div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
