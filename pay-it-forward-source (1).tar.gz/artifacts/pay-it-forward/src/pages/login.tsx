import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link, useLocation } from "wouter";
import { useLogin, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { HeartHandshake, Loader2, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const DEMO_ACCOUNTS = [
  { label: "Maria (Neighbor)", email: "maria@example.com", password: "password", desc: "Active community member" },
  { label: "James (Helper)", email: "james@example.com", password: "password", desc: "Top-rated helper, 41 jobs" },
  { label: "Roberto (Pro)", email: "roberto@example.com", password: "password", desc: "67 jobs, 100% reliability" },
  { label: "County Admin", email: "county@example.com", password: "password", desc: "County portal access" },
];

const schema = z.object({
  email: z.string().email("Valid email required"),
  password: z.string().min(1, "Password required"),
});

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const login = useLogin();

  const form = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
    defaultValues: { email: "", password: "" },
  });

  function onSubmit(values: z.infer<typeof schema>) {
    login.mutate({ data: values }, {
      onSuccess: (user) => {
        qc.setQueryData(getGetMeQueryKey(), user);
        setLocation("/");
      },
      onError: () => {
        toast({
          title: "Login failed",
          description: "Check your email and password, or use a demo account below.",
          variant: "destructive",
        });
      },
    });
  }

  function demoLogin(email: string, password: string) {
    form.setValue("email", email);
    form.setValue("password", password);
    login.mutate({ data: { email, password } }, {
      onSuccess: (user) => {
        qc.setQueryData(getGetMeQueryKey(), user);
        setLocation("/");
      },
      onError: () => {
        toast({
          title: "Demo login failed",
          description: "Demo accounts may not be seeded yet. Contact support.",
          variant: "destructive",
        });
      },
    });
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary text-primary-foreground mb-4">
            <HeartHandshake className="w-7 h-7" />
          </div>
          <h1 className="font-serif text-2xl font-bold text-foreground">Welcome back</h1>
          <p className="text-muted-foreground text-sm mt-1">Sign in to your Pay It Forward account</p>
        </div>

        {/* Demo quick-login cards */}
        <div className="mb-4">
          <p className="text-xs font-semibold text-muted-foreground mb-2 flex items-center gap-1.5">
            <Zap className="w-3 h-3" /> Quick Demo Login
          </p>
          <div className="grid grid-cols-2 gap-2">
            {DEMO_ACCOUNTS.map((acc) => (
              <button
                key={acc.email}
                onClick={() => demoLogin(acc.email, acc.password)}
                disabled={login.isPending}
                className="text-left p-2.5 rounded-xl border border-border hover:border-primary/50 hover:bg-primary/5 transition-colors text-xs"
              >
                <div className="font-semibold text-foreground">{acc.label}</div>
                <div className="text-muted-foreground text-[10px] mt-0.5">{acc.desc}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 mb-4">
          <div className="flex-1 h-px bg-border" />
          <span className="text-xs text-muted-foreground">or sign in manually</span>
          <div className="flex-1 h-px bg-border" />
        </div>

        <div className="bg-card border border-card-border rounded-2xl p-6 shadow-sm">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="email" render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="you@example.com" data-testid="input-email" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="password" render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="••••••••" data-testid="input-password" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <Button type="submit" className="w-full" disabled={login.isPending} data-testid="button-login">
                {login.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Sign In"}
              </Button>
            </form>
          </Form>
        </div>

        <p className="text-center text-sm text-muted-foreground mt-4">
          New to the community?{" "}
          <Link href="/register" className="text-primary font-medium hover:underline">
            Create an account
          </Link>
        </p>
      </div>
    </div>
  );
}
