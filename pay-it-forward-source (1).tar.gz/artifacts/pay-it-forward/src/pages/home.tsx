import { useState } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  useGetActivityFeed,
  useGetCommunityFund,
  useListImpactStories,
  useCreateImpactStory,
  getGetActivityFeedQueryKey,
  getGetCommunityFundQueryKey,
  getListImpactStoriesQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { useHelperMode } from "@/contexts/HelperModeContext";
import { PatrolView } from "@/pages/helper-mode";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  MapPin, Clock, PlusCircle, HeartHandshake, Users, Timer,
  ArrowRight, CheckCircle2, Heart, HandCoins, Sparkles, Zap,
  DollarSign, TrendingUp, BookOpen, PenLine, X, Loader2,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const URGENCY_COLORS: Record<string, string> = {
  emergency: "bg-red-100 text-red-700 border-red-200",
  urgent: "bg-orange-100 text-orange-700 border-orange-200",
  normal: "bg-blue-100 text-blue-700 border-blue-200",
  low: "bg-muted text-muted-foreground",
};

const FUNDING_LABELS: Record<string, string> = {
  community_fund: "Community Fund",
  pay_forward: "Pay It Forward",
  volunteer: "Volunteer",
  direct: "Direct Pay",
};

const FUNDING_COLORS: Record<string, string> = {
  community_fund: "bg-primary/10 text-primary",
  pay_forward: "bg-secondary/10 text-secondary-foreground",
  volunteer: "bg-green-100 text-green-700",
  direct: "bg-muted text-muted-foreground",
};

const STORY_AVATAR_COLORS = [
  "#4CAF50", "#2196F3", "#9C27B0", "#FF5722", "#00BCD4",
  "#E91E63", "#FF9800", "#795548",
];

const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.07 } } };
const item = { hidden: { opacity: 0, y: 14 }, show: { opacity: 1, y: 0, transition: { duration: 0.35 } } };

function greeting(name: string) {
  const h = new Date().getHours();
  const prefix = h < 12 ? "Good Morning" : h < 17 ? "Good Afternoon" : "Good Evening";
  return `${prefix}, ${name.split(" ")[0]}`;
}

export default function HomePage() {
  const { user } = useAuth();
  const { isHelperMode } = useHelperMode();

  // ── Helper mode: render the Patrol dispatch view directly ──────────────────
  if (isHelperMode) {
    return <PatrolView />;
  }

  return <HomeContent />;
}

const STORY_CATEGORIES = ["General Help", "Transportation", "Moving Help", "Elder Care", "Childcare", "Emergency", "Food/Groceries", "Pet Care", "Home Repairs", "Yard Work", "Other"];

function ShareStoryForm({ onClose }: { onClose: () => void }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const createStory = useCreateImpactStory();
  const [name, setName] = useState(user?.name ?? "");
  const [neighborhood, setNeighborhood] = useState(user?.neighborhood ?? "");
  const [story, setStory] = useState("");
  const [category, setCategory] = useState("General Help");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !story.trim() || story.length < 10) {
      toast({ title: "Please fill in all fields", description: "Story must be at least 10 characters.", variant: "destructive" });
      return;
    }
    createStory.mutate({ data: { name: name.trim(), neighborhood: neighborhood.trim() || "Fort Worth", story: story.trim(), category } }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListImpactStoriesQueryKey() });
        toast({ title: "Story shared! 🎉", description: "Your story is now visible to the community." });
        onClose();
      },
      onError: () => {
        toast({ title: "Couldn't share story", description: "Try again in a moment.", variant: "destructive" });
      },
    });
  }

  return (
    <motion.form
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: "auto" }}
      exit={{ opacity: 0, height: 0 }}
      onSubmit={handleSubmit}
      className="bg-primary/5 border border-primary/20 rounded-xl p-4 mb-4 space-y-3"
    >
      <div className="flex items-center justify-between">
        <p className="text-sm font-semibold text-primary flex items-center gap-1.5">
          <PenLine className="w-4 h-4" /> Share your story with Fort Worth
        </p>
        <button type="button" onClick={onClose} className="text-muted-foreground hover:text-foreground">
          <X className="w-4 h-4" />
        </button>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1 block">Your Name</label>
          <input
            className="w-full rounded-lg border border-border bg-background px-3 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
            value={name} onChange={(e) => setName(e.target.value)} placeholder="Maria Gonzalez" required
          />
        </div>
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1 block">Neighborhood</label>
          <input
            className="w-full rounded-lg border border-border bg-background px-3 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
            value={neighborhood} onChange={(e) => setNeighborhood(e.target.value)} placeholder="Near Southside"
          />
        </div>
      </div>
      <div>
        <label className="text-xs font-medium text-muted-foreground mb-1 block">Category</label>
        <select
          className="w-full rounded-lg border border-border bg-background px-3 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
          value={category} onChange={(e) => setCategory(e.target.value)}
        >
          {STORY_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
        </select>
      </div>
      <div>
        <label className="text-xs font-medium text-muted-foreground mb-1 block">Your Story</label>
        <textarea
          className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary resize-none"
          rows={3} value={story} onChange={(e) => setStory(e.target.value)}
          placeholder="Tell the community what happened — a moment of kindness, a neighbor who showed up, how someone made a real difference..."
          required
        />
        <p className="text-[10px] text-muted-foreground mt-0.5">{story.length} chars (min 10)</p>
      </div>
      <Button type="submit" size="sm" className="w-full" disabled={createStory.isPending}>
        {createStory.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-1.5" /> : null}
        {createStory.isPending ? "Sharing..." : "Share with the Community"}
      </Button>
    </motion.form>
  );
}

function HomeContent() {
  const { user } = useAuth();
  const [showStoryForm, setShowStoryForm] = useState(false);
  const { data: feed, isLoading: feedLoading } = useGetActivityFeed({
    query: { queryKey: getGetActivityFeedQueryKey() },
  });
  const { data: fund } = useGetCommunityFund({
    query: { queryKey: getGetCommunityFundQueryKey() },
  });
  const { data: stories, isLoading: storiesLoading } = useListImpactStories({
    query: { queryKey: getListImpactStoriesQueryKey() },
  });

  return (
    <div className="space-y-8 pb-8">

      {/* ── Hero ── */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="relative overflow-hidden rounded-2xl bg-primary text-primary-foreground p-6 md:p-8"
      >
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            <MapPin className="w-4 h-4 opacity-80" />
            <span className="text-sm font-medium opacity-80">Fort Worth, TX</span>
          </div>
          <h1 className="font-serif text-2xl md:text-3xl font-bold leading-tight mb-2">
            {user ? `Welcome back, ${user.name.split(" ")[0]}` : "Neighbor helping neighbor"}
          </h1>
          <p className="text-sm opacity-80 mb-5 max-w-md">
            A community where helping people is a way of life — and a sustainable livelihood.
          </p>
          <div className="flex flex-wrap gap-3">
            {user ? (
              <>
                <Link href="/post">
                  <Button variant="secondary" size="sm" className="font-semibold" data-testid="hero-ask-help">
                    <PlusCircle className="w-4 h-4 mr-1.5" /> Ask for Help
                  </Button>
                </Link>
                <Link href="/opportunities">
                  <Button variant="outline" size="sm" className="bg-white/10 border-white/20 text-white hover:bg-white/20 font-semibold" data-testid="hero-see-missions">
                    <Sparkles className="w-4 h-4 mr-1.5" /> See Community Missions
                  </Button>
                </Link>
              </>
            ) : (
              <>
                <Link href="/register">
                  <Button variant="secondary" size="sm" className="font-semibold" data-testid="hero-join">
                    Join the Community
                  </Button>
                </Link>
                <Link href="/opportunities">
                  <Button variant="outline" size="sm" className="bg-white/10 border-white/20 text-white hover:bg-white/20 font-semibold">
                    Browse Neighbor Requests
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
        <div className="absolute right-0 top-0 w-48 h-48 bg-white/5 rounded-full -translate-y-1/4 translate-x-1/4" />
        <div className="absolute right-16 bottom-0 w-24 h-24 bg-white/5 rounded-full translate-y-1/2" />
      </motion.div>

      {/* ── Community Impact Stats ── */}
      {fund && (
        <div>
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Fort Worth Impact — Today</h2>
          <motion.div variants={stagger} initial="hidden" animate="show" className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { icon: Users, label: "People Helped", value: fund.neighbors_helped },
              { icon: Timer, label: "Hours Donated", value: fund.hours_donated },
              { icon: HandCoins, label: "Fund Balance", value: `$${fund.balance.toLocaleString()}` },
              { icon: CheckCircle2, label: "Acts of Service", value: fund.requests_funded },
            ].map((stat) => (
              <motion.div key={stat.label} variants={item} className="bg-card border border-card-border rounded-xl p-4 text-center">
                <stat.icon className="w-5 h-5 text-primary mx-auto mb-1.5" />
                <div className="text-xl font-bold text-foreground">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      )}

      {/* ── Community Stories feed ── */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="font-serif text-xl font-semibold flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-primary" /> Community Stories
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">Real moments of kindness in Fort Worth</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowStoryForm((s) => !s)}
              className="flex items-center gap-1.5 text-xs font-medium text-primary hover:opacity-80 transition-opacity bg-primary/10 rounded-full px-3 py-1.5"
            >
              <PenLine className="w-3.5 h-3.5" />
              {showStoryForm ? "Cancel" : "Share Yours"}
            </button>
            <Link href="/community" className="text-sm text-primary font-medium flex items-center gap-1 hover:underline">
              See all <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        <AnimatePresence>
          {showStoryForm && <ShareStoryForm onClose={() => setShowStoryForm(false)} />}
        </AnimatePresence>

        {storiesLoading ? (
          <div className="flex gap-3 overflow-x-auto pb-2">
            {[1, 2, 3].map((i) => <Skeleton key={i} className="h-40 w-64 shrink-0 rounded-xl" />)}
          </div>
        ) : (stories?.stories ?? []).length === 0 ? (
          <div className="text-center py-8 text-muted-foreground border border-dashed border-border rounded-xl">
            <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-30" />
            <p className="text-sm">No stories yet — be the first to share one.</p>
            <Button size="sm" variant="outline" className="mt-3" onClick={() => setShowStoryForm(true)}>
              Share a Story
            </Button>
          </div>
        ) : (
          <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4">
            {(stories?.stories ?? []).slice(0, 6).map((story, idx) => (
              <div
                key={story.id}
                className="shrink-0 w-64 bg-card border border-card-border rounded-xl p-4 flex flex-col gap-2"
                data-testid={`story-card-${story.id}`}
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0"
                    style={{ backgroundColor: story.avatar_color ?? STORY_AVATAR_COLORS[idx % STORY_AVATAR_COLORS.length] }}
                  >
                    {story.avatar_initials ?? story.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-foreground truncate">{story.name}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{story.neighborhood}</p>
                  </div>
                </div>
                <p className="text-xs text-foreground leading-relaxed line-clamp-4 italic">"{story.story}"</p>
                <span className="mt-auto inline-flex self-start items-center gap-1 text-[10px] bg-primary/10 text-primary rounded-full px-2 py-0.5 font-medium">
                  {story.category}
                </span>
              </div>
            ))}
            <Link href="/community" className="shrink-0 w-24 flex flex-col items-center justify-center gap-1 text-primary hover:opacity-80 transition-opacity">
              <ArrowRight className="w-6 h-6" />
              <span className="text-xs font-medium text-center">More stories</span>
            </Link>
          </div>
        )}
      </section>

      {/* ── Neighbor Requests feed ── */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-serif text-xl font-semibold">Neighbor Requests</h2>
            <p className="text-xs text-muted-foreground mt-0.5">Fort Worth neighbors who need a hand</p>
          </div>
          <Link href="/opportunities" className="text-sm text-primary font-medium flex items-center gap-1 hover:underline">
            See all <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {feedLoading ? (
          <div className="space-y-3">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-28 rounded-xl" />)}</div>
        ) : (
          <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-3">
            {(feed?.recent_requests ?? []).slice(0, 5).map((req) => (
              <motion.div key={req.id} variants={item}>
                <Link href="/opportunities">
                  <div
                    className="bg-card border border-card-border rounded-xl p-4 hover:border-primary/40 transition-colors cursor-pointer"
                    data-testid={`card-neighbor-request-${req.id}`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap mb-1.5">
                          {req.urgency === "emergency" && (
                            <span className="flex items-center gap-1 text-xs font-bold text-red-600">
                              <Zap className="w-3 h-3 animate-pulse" /> EMERGENCY
                            </span>
                          )}
                          <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${URGENCY_COLORS[req.urgency] ?? ""}`}>
                            {req.urgency.charAt(0).toUpperCase() + req.urgency.slice(1)}
                          </span>
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${FUNDING_COLORS[req.funding_source] ?? ""}`}>
                            {FUNDING_LABELS[req.funding_source] ?? req.funding_source}
                          </span>
                        </div>
                        <h3 className="font-semibold text-sm text-foreground leading-snug">{req.title}</h3>
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{req.description}</p>
                      </div>
                      {req.budget && (
                        <div className="text-right shrink-0">
                          <span className="text-sm font-bold text-foreground">${req.budget}</span>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-3 mt-2.5 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{req.neighborhood}</span>
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{new Date(req.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
            {(feed?.recent_requests ?? []).length === 0 && (
              <div className="text-center py-10 text-muted-foreground">
                <HeartHandshake className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p>No open requests right now. Be the first to ask for help.</p>
              </div>
            )}
          </motion.div>
        )}
      </section>

      {/* ── Community Gratitude ── */}
      {(feed?.recent_gratitude ?? []).length > 0 && (
        <section>
          <h2 className="font-serif text-xl font-semibold mb-1">Community Gratitude</h2>
          <p className="text-xs text-muted-foreground mb-4">Thank-you notes flowing through Fort Worth</p>
          <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-2">
            {(feed?.recent_gratitude ?? []).slice(0, 4).map((g) => (
              <motion.div key={g.id} variants={item} className="flex gap-3 bg-card border border-card-border rounded-xl p-4">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0"
                  style={{ backgroundColor: g.from_user_avatar_color ?? "#4CAF50" }}
                >
                  {g.from_user_name?.slice(0, 2).toUpperCase() ?? "?"}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground leading-relaxed italic">"{g.message}"</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {g.from_user_name ?? "A neighbor"}
                    {g.to_user_name ? ` thanked ${g.to_user_name}` : " shared gratitude"}
                  </p>
                </div>
                <Heart className="w-4 h-4 text-green-500 shrink-0 mt-0.5 ml-auto" />
              </motion.div>
            ))}
          </motion.div>
        </section>
      )}

      {/* ── CTA for guests ── */}
      {!user && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="rounded-2xl overflow-hidden"
        >
          <div className="bg-primary/5 border border-primary/20 rounded-2xl p-6">
            <HeartHandshake className="w-10 h-10 text-primary mx-auto mb-3" />
            <h3 className="font-serif text-lg font-semibold mb-2 text-center">What if helping paid as well as any job?</h3>
            <p className="text-sm text-muted-foreground mb-4 text-center max-w-xs mx-auto">
              Wake up. Open the app. Help a neighbor with groceries, a ride, yard work.
              Earn income. Pay it forward when someone needs you.
            </p>

            <div className="flex flex-col gap-2 mb-5 text-xs">
              {[
                { step: "Need Help", desc: "Post a request to the community" },
                { step: "Community Responds", desc: "Verified neighbors offer to help" },
                { step: "Helper Assists", desc: "Someone shows up, task gets done" },
                { step: "Pay It Forward", desc: "Pay now, later, or gift it to the fund" },
                { step: "Helper Earns", desc: "Real daily income from community service" },
              ].map((s, i) => (
                <div key={s.step} className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-primary text-primary-foreground text-[10px] flex items-center justify-center font-bold shrink-0">{i + 1}</div>
                  <div>
                    <span className="font-semibold text-foreground">{s.step}</span>
                    <span className="text-muted-foreground"> — {s.desc}</span>
                  </div>
                </div>
              ))}
            </div>

            <Link href="/register">
              <Button className="w-full font-semibold" data-testid="cta-join">
                <Zap className="w-4 h-4 mr-1.5" /> Join Fort Worth's Mutual Aid Network
              </Button>
            </Link>
          </div>
        </motion.div>
      )}
    </div>
  );
}
