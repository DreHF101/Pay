import { useState, useEffect, lazy, Suspense } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { useHelperMode } from "@/contexts/HelperModeContext";
import {
  useListRequests, useCreateJob, useUpdateUser,
  getListRequestsQueryKey, getListJobsQueryKey, getGetMeQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Zap, MapPin, Clock, CheckCircle2, HeartHandshake,
  DollarSign, TrendingUp, Settings2, Navigation, List, Map,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

const PatrolMap = lazy(() => import("@/components/PatrolMap"));

const AVAILABILITY_OPTIONS = [
  { value: "Available Now", label: "Available Now", description: "Ready to help immediately", color: "bg-green-100 text-green-700 border-green-200" },
  { value: "Available Today", label: "Available Today", description: "Can help sometime today", color: "bg-blue-100 text-blue-700 border-blue-200" },
  { value: "Available This Week", label: "Available This Week", description: "Have time this week", color: "bg-amber-100 text-amber-700 border-amber-200" },
  { value: "Not Available", label: "Not Available", description: "Taking a break", color: "bg-muted text-muted-foreground border-border" },
];

const SERVICE_RADIUS_OPTIONS = [
  { value: 2, label: "2 mi", desc: "My block" },
  { value: 5, label: "5 mi", desc: "My neighborhood" },
  { value: 10, label: "10 mi", desc: "Fort Worth" },
  { value: 25, label: "25 mi", desc: "Greater DFW" },
];

const URGENCY_RING: Record<string, string> = {
  emergency: "border-red-400 bg-red-50",
  urgent: "border-orange-300 bg-orange-50",
  normal: "border-card-border bg-card",
  low: "border-card-border bg-card",
};

const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.07 } } };
const item = { hidden: { opacity: 0, x: -12 }, show: { opacity: 1, x: 0, transition: { duration: 0.3 } } };

function simDist(id: number): string {
  return (((id * 7 + 3) % 28) / 10 + 0.2).toFixed(1);
}

// ── Patrol View (exported so home.tsx can render it directly) ─────────────────
export function PatrolView() {
  const { user } = useAuth();
  const { setHelperMode } = useHelperMode();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [claimedIds, setClaimedIds] = useState<Set<number>>(new Set());
  const [showSettings, setShowSettings] = useState(false);
  const [viewMode, setViewMode] = useState<"list" | "map">("list");
  const [availability, setAvailability] = useState(user?.availability ?? "Available Now");
  const [radius, setRadius] = useState<number>(user?.service_radius ?? 10);
  const updateUser = useUpdateUser();
  const createJob = useCreateJob();

  const { data: requests, isLoading } = useListRequests(
    { status: "open" },
    { query: { queryKey: getListRequestsQueryKey({ status: "open" }) } }
  );

  const sorted = [...(requests ?? [])].sort(
    (a, b) => parseFloat(simDist(a.id)) - parseFloat(simDist(b.id))
  );

  const emergencyCount = sorted.filter((r) => r.urgency === "emergency").length;

  const todayEarnings = user ? (user.help_count % 10) * 18 + 24 : 0;
  const pendingEarnings = sorted.filter((r) => claimedIds.has(r.id)).length * 22;

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return "Good Morning";
    if (h < 17) return "Good Afternoon";
    return "Good Evening";
  };

  function handleHelp(requestId: number) {
    createJob.mutate({ data: { request_id: requestId } }, {
      onSuccess: () => {
        setClaimedIds((prev) => new Set([...prev, requestId]));
        qc.invalidateQueries({ queryKey: getListRequestsQueryKey() });
        qc.invalidateQueries({ queryKey: getListJobsQueryKey() });
        toast({
          title: "You're helping a neighbor!",
          description: "They've been notified. Head over when ready.",
        });
      },
      onError: (err: any) => {
        toast({ title: "Couldn't accept", description: err?.data?.error ?? "Try again.", variant: "destructive" });
      },
    });
  }

  function handleSavePrefs() {
    if (!user) return;
    updateUser.mutate({ id: user.id, data: { availability, service_radius: radius } }, {
      onSuccess: (updated) => {
        qc.setQueryData(getGetMeQueryKey(), updated);
        setShowSettings(false);
        toast({ title: "Preferences saved!" });
      },
    });
  }

  return (
    <div className="pb-20">
      {/* ── Patrol header ── */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl bg-primary text-primary-foreground p-5 mb-5 relative overflow-hidden"
      >
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-2">
            <span className="flex items-center gap-1.5 text-xs font-bold bg-white/20 rounded-full px-3 py-1">
              <div className="w-1.5 h-1.5 rounded-full bg-green-300 animate-pulse" />
              ON PATROL
            </span>
            <button
              className="text-xs opacity-70 hover:opacity-100 flex items-center gap-1"
              onClick={() => setHelperMode(false)}
            >
              Go offline
            </button>
          </div>
          <p className="text-sm opacity-80 mb-1">{greeting()}, {user?.name.split(" ")[0]}</p>
          <p className="font-serif text-xl font-bold">Your neighbors need you</p>
          <p className="text-xs opacity-70 mt-1">{user?.neighborhood} · {radius} mi radius</p>
        </div>
        <div className="absolute right-0 top-0 w-32 h-32 bg-white/5 rounded-full -translate-y-1/3 translate-x-1/3" />
      </motion.div>

      {/* ── Earnings strip ── */}
      <div className="grid grid-cols-3 gap-2 mb-5">
        {[
          { icon: DollarSign, label: "Today's Earnings", value: `$${todayEarnings}`, color: "text-green-600" },
          { icon: TrendingUp, label: "Pending", value: `$${pendingEarnings}`, color: "text-amber-600" },
          { icon: HeartHandshake, label: "Lives Touched", value: user?.help_count ?? 0, color: "text-primary" },
        ].map((s) => (
          <div key={s.label} className="bg-card border border-card-border rounded-xl p-3 text-center">
            <s.icon className={`w-4 h-4 mx-auto mb-1 ${s.color}`} />
            <div className={`text-base font-bold ${s.color}`}>{s.value}</div>
            <div className="text-[10px] text-muted-foreground leading-tight">{s.label}</div>
          </div>
        ))}
      </div>

      {/* ── Emergency banner ── */}
      {emergencyCount > 0 && (
        <div className="flex items-center gap-3 bg-red-50 border border-red-200 rounded-xl px-4 py-3 mb-4">
          <Zap className="w-4 h-4 text-red-600 shrink-0 animate-pulse" />
          <p className="text-sm text-red-700 font-semibold">
            {emergencyCount} emergency nearby — please respond if you can
          </p>
        </div>
      )}

      {/* ── Inline settings toggle ── */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-semibold text-sm flex items-center gap-2">
          <Navigation className="w-4 h-4 text-primary" />
          Nearby Requests
        </h2>
        <div className="flex items-center gap-2">
          {/* Map / List toggle */}
          <div className="flex items-center rounded-lg border border-border overflow-hidden">
            <button
              className={`flex items-center gap-1 px-2 py-1 text-xs transition-colors ${viewMode === "list" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
              onClick={() => setViewMode("list")}
            >
              <List className="w-3 h-3" /> List
            </button>
            <button
              className={`flex items-center gap-1 px-2 py-1 text-xs transition-colors ${viewMode === "map" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
              onClick={() => setViewMode("map")}
            >
              <Map className="w-3 h-3" /> Map
            </button>
          </div>
          <button
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"
            onClick={() => setShowSettings((s) => !s)}
          >
            <Settings2 className="w-3.5 h-3.5" />
            {showSettings ? "Hide" : "Settings"}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {showSettings && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-5 bg-muted/40 rounded-xl p-4 space-y-4"
          >
            <div>
              <p className="text-xs font-semibold mb-2">Availability</p>
              <div className="grid grid-cols-2 gap-2">
                {AVAILABILITY_OPTIONS.map((opt) => (
                  <label
                    key={opt.value}
                    className={`flex items-center gap-2 p-2 rounded-lg border text-xs cursor-pointer transition-colors ${
                      availability === opt.value ? `${opt.color} border-current` : "border-border"
                    }`}
                  >
                    <input type="radio" className="accent-primary" checked={availability === opt.value} onChange={() => setAvailability(opt.value)} />
                    {opt.label}
                  </label>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs font-semibold mb-2">Service Radius</p>
              <div className="grid grid-cols-4 gap-1.5">
                {SERVICE_RADIUS_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    className={`p-2 rounded-lg border text-xs transition-colors ${
                      radius === opt.value ? "border-primary bg-primary/5 text-primary" : "border-border"
                    }`}
                    onClick={() => setRadius(opt.value)}
                  >
                    <div className="font-bold">{opt.label}</div>
                    <div className="text-muted-foreground text-[10px]">{opt.desc}</div>
                  </button>
                ))}
              </div>
            </div>
            <Button size="sm" className="w-full" onClick={handleSavePrefs} disabled={updateUser.isPending}>
              Save
            </Button>
            <Link href="/helper-mode">
              <button className="w-full text-center text-xs text-primary hover:underline">
                Full Settings →
              </button>
            </Link>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Map view ── */}
      {viewMode === "map" && !isLoading && (
        <div className="mb-4">
          <Suspense fallback={<Skeleton className="h-[360px] rounded-xl" />}>
            <PatrolMap
              requests={sorted}
              claimedIds={claimedIds}
              onHelp={handleHelp}
            />
          </Suspense>
          <p className="text-center text-xs text-muted-foreground mt-2">
            Tap a pin to view details and accept
          </p>
        </div>
      )}

      {/* ── Nearby request cards (list view) ── */}
      {viewMode === "list" && isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-32 rounded-xl" />)}
        </div>
      ) : viewMode === "list" && sorted.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <CheckCircle2 className="w-10 h-10 mx-auto mb-2 opacity-30" />
          <p className="font-medium">All clear — no open requests right now</p>
          <p className="text-sm">Check back soon, neighbors always need help.</p>
        </div>
      ) : viewMode === "list" ? (
        <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-3">
          {sorted.map((req) => {
            const dist = simDist(req.id);
            const claimed = claimedIds.has(req.id) || req.status !== "open";
            return (
              <motion.div key={req.id} variants={item}>
                <div
                  className={`border-2 rounded-xl p-4 transition-all ${
                    claimed ? "border-green-300 bg-green-50/40" : URGENCY_RING[req.urgency] ?? "border-card-border bg-card"
                  }`}
                  data-testid={`patrol-card-${req.id}`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`shrink-0 w-10 h-10 rounded-xl flex flex-col items-center justify-center text-center ${
                      req.urgency === "emergency" ? "bg-red-100" : req.urgency === "urgent" ? "bg-orange-100" : "bg-muted"
                    }`}>
                      <span className={`text-[11px] font-bold leading-none ${
                        req.urgency === "emergency" ? "text-red-600" : req.urgency === "urgent" ? "text-orange-600" : "text-muted-foreground"
                      }`}>{dist}</span>
                      <span className="text-[9px] text-muted-foreground">mi</span>
                    </div>

                    <div className="flex-1 min-w-0">
                      {req.urgency === "emergency" && (
                        <span className="text-xs font-bold text-red-600 flex items-center gap-0.5 mb-0.5">
                          <Zap className="w-3 h-3 animate-pulse" /> EMERGENCY
                        </span>
                      )}
                      <h3 className="font-semibold text-sm leading-snug">{req.title}</h3>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{req.description}</p>
                      <div className="flex flex-wrap gap-2 mt-1.5 text-xs text-muted-foreground">
                        <span className="flex items-center gap-0.5"><MapPin className="w-3 h-3" />{req.neighborhood}</span>
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">{req.category}</Badge>
                        {req.budget && <span className="font-bold text-foreground">${req.budget}</span>}
                      </div>
                    </div>

                    <div className="shrink-0">
                      {claimed ? (
                        <span className="flex items-center gap-1 text-xs text-green-600 font-semibold whitespace-nowrap">
                          <CheckCircle2 className="w-4 h-4" /> Accepted
                        </span>
                      ) : (
                        <Button
                          size="sm"
                          onClick={() => handleHelp(req.id)}
                          disabled={createJob.isPending}
                          className="text-xs whitespace-nowrap"
                          data-testid={`patrol-help-${req.id}`}
                        >
                          I Can Help
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      ) : null}

      <p className="text-center text-xs text-muted-foreground mt-6">
        {sorted.length} neighbor request{sorted.length !== 1 ? "s" : ""} within {radius} miles
      </p>
    </div>
  );
}

// ── Settings View ─────────────────────────────────────────────────────────────
function SettingsView() {
  const { user } = useAuth();
  const { isHelperMode, setHelperMode } = useHelperMode();
  const { toast } = useToast();
  const qc = useQueryClient();
  const updateUser = useUpdateUser();

  const [availability, setAvailability] = useState(user?.availability ?? "Available Now");
  const [radius, setRadius] = useState<number>(user?.service_radius ?? 10);
  const [services, setServices] = useState<string[]>(
    user?.services_offered ? user.services_offered.split(",").map((s) => s.trim()) : []
  );

  useEffect(() => {
    if (user) {
      setAvailability(user.availability ?? "Available Now");
      setRadius(user.service_radius ?? 10);
      setServices(user.services_offered ? user.services_offered.split(",").map((s) => s.trim()) : []);
    }
  }, [user]);

  const SERVICES = [
    { value: "Transportation", icon: "🚗" },
    { value: "Elder Care", icon: "👴" },
    { value: "Moving", icon: "📦" },
    { value: "Childcare", icon: "👶" },
    { value: "Food Delivery", icon: "🛒" },
    { value: "Home Repairs", icon: "🔧" },
    { value: "Yard Work", icon: "🌿" },
    { value: "Pet Care", icon: "🐾" },
  ];

  function toggleService(svc: string) {
    setServices((prev) => prev.includes(svc) ? prev.filter((s) => s !== svc) : [...prev, svc]);
  }

  function handleSave() {
    if (!user) return;
    updateUser.mutate(
      { id: user.id, data: { availability, service_radius: radius, services_offered: services.join(",") } },
      {
        onSuccess: (updated) => {
          qc.setQueryData(getGetMeQueryKey(), updated);
          toast({ title: "Helper profile saved!", description: "Your preferences have been updated." });
        },
        onError: () => toast({ title: "Error", description: "Could not save.", variant: "destructive" }),
      }
    );
  }

  return (
    <div className="max-w-xl mx-auto pb-16 space-y-6">
      <div>
        <h1 className="font-serif text-2xl font-bold mb-1">Helper Settings</h1>
        <p className="text-sm text-muted-foreground">Configure your availability and service preferences</p>
      </div>

      {/* Patrol toggle */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl p-5 border-2 bg-card border-card-border"
      >
        <div className="flex items-center justify-between">
          <div>
            <p className="font-semibold flex items-center gap-2">
              <Zap className="w-4 h-4 text-primary" />
              {isHelperMode ? "Currently On Patrol" : "Go On Patrol"}
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">
              {isHelperMode
                ? "You're live — neighbors can see you're available"
                : "Toggle on to see nearby requests sorted by distance"}
            </p>
          </div>
          <Switch checked={isHelperMode} onCheckedChange={setHelperMode} data-testid="switch-helper-mode" />
        </div>
        {isHelperMode && (
          <Link href="/">
            <Button size="sm" variant="outline" className="mt-3 w-full text-xs">
              <Navigation className="w-3.5 h-3.5 mr-1.5" /> Go to Dispatch →
            </Button>
          </Link>
        )}
      </motion.div>

      {/* Availability */}
      <div className="bg-card border border-card-border rounded-2xl p-5">
        <h3 className="font-semibold mb-3 flex items-center gap-2">
          <Clock className="w-4 h-4 text-primary" /> Availability
        </h3>
        <div className="grid grid-cols-1 gap-2">
          {AVAILABILITY_OPTIONS.map((opt) => (
            <label
              key={opt.value}
              className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-colors ${
                availability === opt.value ? `${opt.color} border-current` : "border-border hover:border-primary/30 bg-background"
              }`}
            >
              <input type="radio" className="accent-primary" checked={availability === opt.value} onChange={() => setAvailability(opt.value)} />
              <div>
                <p className="text-sm font-semibold">{opt.label}</p>
                <p className="text-xs opacity-70">{opt.description}</p>
              </div>
            </label>
          ))}
        </div>
      </div>

      {/* Service Radius */}
      <div className="bg-card border border-card-border rounded-2xl p-5">
        <h3 className="font-semibold mb-3 flex items-center gap-2">
          <MapPin className="w-4 h-4 text-primary" /> Service Radius
        </h3>
        <div className="grid grid-cols-2 gap-2">
          {SERVICE_RADIUS_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              className={`p-3 rounded-xl border text-left transition-colors ${
                radius === opt.value ? "border-primary bg-primary/5 text-primary" : "border-border hover:border-primary/30"
              }`}
              onClick={() => setRadius(opt.value)}
            >
              <p className="text-sm font-bold">{opt.label}</p>
              <p className="text-xs text-muted-foreground">{opt.desc}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Services */}
      <div className="bg-card border border-card-border rounded-2xl p-5">
        <h3 className="font-semibold mb-3">What Can You Offer?</h3>
        <div className="grid grid-cols-2 gap-2">
          {SERVICES.map((svc) => {
            const selected = services.includes(svc.value);
            return (
              <button
                key={svc.value}
                className={`flex items-center gap-2 p-3 rounded-xl border text-left transition-colors ${
                  selected ? "border-primary bg-primary/5 text-primary" : "border-border hover:border-primary/30"
                }`}
                onClick={() => toggleService(svc.value)}
              >
                <span className="text-base">{svc.icon}</span>
                <span className="text-sm font-medium">{svc.value}</span>
                {selected && <CheckCircle2 className="w-3.5 h-3.5 ml-auto" />}
              </button>
            );
          })}
        </div>
      </div>

      <Button className="w-full" onClick={handleSave} disabled={updateUser.isPending} data-testid="button-save-helper-profile">
        {updateUser.isPending ? <span className="flex items-center gap-2"><Zap className="w-4 h-4 animate-spin" /> Saving...</span> : "Save Preferences"}
      </Button>
    </div>
  );
}

// ── Root: /helper-mode is purely the Settings page ───────────────────────────
export default function HelperModePage() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="text-center py-20">
        <Zap className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-30" />
        <h2 className="font-serif text-xl font-semibold mb-2">Sign in to enable Helper Mode</h2>
        <Link href="/login"><Button>Sign In</Button></Link>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <SettingsView />
    </motion.div>
  );
}
