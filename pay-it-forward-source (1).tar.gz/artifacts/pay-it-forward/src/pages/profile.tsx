import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import {
  useUpdateUser, useGetMyPledges, useRepayPledge,
  getGetMeQueryKey, getGetMyPledgesQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import {
  CheckCircle2, Clock, User, Shield, Loader2, HandCoins,
  ChevronRight, Star, Wallet, TrendingUp, DollarSign,
  HeartHandshake, Award, Zap,
} from "lucide-react";
import { ReputationCard } from "@/components/ReputationBadges";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

const AVATAR_COLORS = [
  "#4CAF50", "#2196F3", "#FF5722", "#9C27B0", "#FF9800",
  "#00BCD4", "#E91E63", "#607D8B", "#795548", "#3F51B5",
];

const editSchema = z.object({
  name: z.string().min(2),
  bio: z.string().optional(),
  neighborhood: z.string().min(1),
  avatar_color: z.string(),
});

const VERIFICATION_TIERS = [
  { key: "email_verified" as const, label: "Email Verified", desc: "Confirm your email address", level: 1 },
  { key: "phone_verified" as const, label: "Phone Verified", desc: "Add and verify a phone number", level: 2 },
  { key: "id_verified" as const, label: "ID Verified", desc: "Upload a government-issued ID", level: 3 },
  { key: "background_checked" as const, label: "Background Checked", desc: "Complete a community background check", level: 4 },
  { key: "community_trusted" as const, label: "Community Trusted", desc: "Endorsed by 5+ community members", level: 5 },
];

const TRUST_META: Record<string, { title: string; stars: number; color: string; badge: string }> = {
  community_leader: { title: "Community Hero", stars: 5, color: "text-purple-600", badge: "bg-purple-100 text-purple-700" },
  trusted: { title: "Trusted Neighbor", stars: 4, color: "text-green-600", badge: "bg-green-100 text-green-700" },
  verified: { title: "Verified Neighbor", stars: 3, color: "text-blue-600", badge: "bg-blue-100 text-blue-700" },
  newcomer: { title: "New Neighbor", stars: 2, color: "text-amber-600", badge: "bg-amber-100 text-amber-700" },
};

const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.08 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.3 } } };

function StarRating({ count, color }: { count: number; color: string }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          className={`w-4 h-4 ${i <= count ? `${color} fill-current` : "text-muted-foreground/30"}`}
        />
      ))}
    </div>
  );
}

function OverviewTab() {
  const { user } = useAuth();
  if (!user) return null;

  const meta = TRUST_META[user.trust_level] ?? TRUST_META["newcomer"]!;

  // Trust Score calculation: based on help_count, hours, verification, pay-forward
  const trustScore = Math.min(
    999,
    user.help_count * 8 + user.volunteer_hours * 2 + (user.is_verified ? 100 : 0) + Math.floor(user.pay_forward_total)
  );

  // Estimated service breakdowns (real breakdown needs category ledger)
  const totalHelps = user.help_count;
  const estRides = Math.floor(totalHelps * 0.28);
  const estMeals = Math.floor(totalHelps * 0.22);
  const estSenior = Math.floor(totalHelps * 0.15);

  return (
    <div className="space-y-5">
      {/* ── Community Hero Card ── */}
      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-card border-2 border-primary/20 rounded-2xl p-5"
      >
        <div className="flex items-start gap-4 mb-4">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center text-white text-xl font-bold shrink-0"
            style={{ backgroundColor: user.avatar_color ?? "#4CAF50" }}
          >
            {user.avatar_initials ?? user.name.slice(0, 2).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="font-serif text-xl font-bold leading-tight">{user.name}</h2>
            <p className="text-sm text-muted-foreground">{user.neighborhood} · Fort Worth, TX</p>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              <Badge className={`text-xs ${meta.badge}`}>{meta.title}</Badge>
              {user.is_verified && (
                <span className="flex items-center gap-0.5 text-xs text-primary font-medium">
                  <CheckCircle2 className="w-3 h-3" /> Verified
                </span>
              )}
            </div>
          </div>
        </div>

        <StarRating count={meta.stars} color={meta.color} />

        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="text-center">
            <div className={`text-2xl font-bold ${meta.color}`}>{totalHelps.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">People Helped</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-amber-600">{user.volunteer_hours.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">Hours Served</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{estMeals.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">Meals Delivered</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{estRides.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">Rides Provided</div>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-primary" />
            <span className="text-sm font-semibold">Community Trust Score</span>
          </div>
          <span className={`text-2xl font-bold ${meta.color}`}>{trustScore}</span>
        </div>

        {user.pay_forward_total > 0 && (
          <div className="mt-3 flex items-center gap-2 bg-primary/5 rounded-xl px-3 py-2">
            <Award className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold text-primary">
              Pay It Forward Champion · ${user.pay_forward_total.toFixed(0)} contributed
            </span>
          </div>
        )}

        {/* Reliability % row inside hero card */}
        <div className="mt-3 pt-3 border-t border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-500" />
            <span className="text-sm font-semibold">Reliability Rate</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full ${(user.reliability_pct ?? 90) >= 95 ? "bg-green-500" : (user.reliability_pct ?? 90) >= 85 ? "bg-amber-500" : "bg-red-500"}`}
                style={{ width: `${user.reliability_pct ?? 90}%` }}
              />
            </div>
            <span className={`text-sm font-bold ${(user.reliability_pct ?? 90) >= 95 ? "text-green-600" : (user.reliability_pct ?? 90) >= 85 ? "text-amber-600" : "text-red-500"}`}>
              {user.reliability_pct ?? 90}%
            </span>
          </div>
        </div>

        {user.bio && (
          <p className="mt-3 text-sm text-muted-foreground italic leading-relaxed">"{user.bio}"</p>
        )}
      </motion.div>

      {/* ── Reputation Economy ── */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.08 }}
      >
        <ReputationCard
          user={{
            trust_level: user.trust_level,
            help_count: user.help_count,
            volunteer_hours: user.volunteer_hours,
            reliability_pct: user.reliability_pct ?? 90,
            is_verified: user.is_verified,
            email_verified: user.email_verified ?? false,
            phone_verified: user.phone_verified ?? false,
            id_verified: user.id_verified ?? false,
            background_checked: user.background_checked ?? false,
            community_trusted: user.community_trusted ?? false,
          }}
        />
      </motion.div>

      {/* ── Community Wallet ── */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-card border border-card-border rounded-2xl p-5"
      >
        <h3 className="font-semibold mb-4 flex items-center gap-2">
          <Wallet className="w-4 h-4 text-primary" />
          Community Wallet
        </h3>
        <div className="space-y-3">
          {[
            { label: "Cash Balance", value: `$${(user.balance ?? 0).toFixed(2)}`, icon: DollarSign, color: "text-green-600", desc: "Payments from completed requests" },
            { label: "Pay It Forward Balance", value: `$${user.pay_forward_total.toFixed(2)}`, icon: HeartHandshake, color: "text-primary", desc: "Contributed to neighbors in need" },
            { label: "Community Credits", value: `$${user.community_balance.toFixed(2)}`, icon: TrendingUp, color: "text-blue-600", desc: "Fund assistance received" },
            { label: "Sponsor Rewards", value: `$${user.sponsored_balance.toFixed(2)}`, icon: Award, color: "text-amber-600", desc: "Bonuses from business sponsors" },
          ].map((row) => (
            <div key={row.label} className="flex items-center justify-between py-2 border-b border-border last:border-0">
              <div className="flex items-center gap-3">
                <row.icon className={`w-4 h-4 ${row.color} shrink-0`} />
                <div>
                  <p className="text-sm font-medium">{row.label}</p>
                  <p className="text-xs text-muted-foreground">{row.desc}</p>
                </div>
              </div>
              <span className={`text-sm font-bold ${row.color}`}>{row.value}</span>
            </div>
          ))}
          <div className="flex items-center justify-between pt-2">
            <span className="font-semibold text-sm">Total Available</span>
            <span className="text-lg font-bold text-primary">
              ${((user.balance ?? 0) + user.community_balance + user.sponsored_balance).toFixed(2)}
            </span>
          </div>
        </div>
      </motion.div>

      {/* ── Senior / Veteran stats ── */}
      {estSenior > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-muted/40 border border-border rounded-xl p-4"
        >
          <p className="text-xs font-semibold text-muted-foreground mb-3 uppercase tracking-wide">Estimated Service Breakdown</p>
          <div className="grid grid-cols-3 gap-3 text-center text-xs">
            <div><div className="font-bold text-purple-600 text-base">{estSenior}</div><div className="text-muted-foreground">Senior Visits</div></div>
            <div><div className="font-bold text-green-600 text-base">{Math.floor(totalHelps * 0.1)}</div><div className="text-muted-foreground">Veteran Assists</div></div>
            <div><div className="font-bold text-red-600 text-base">{Math.floor(totalHelps * 0.05)}</div><div className="text-muted-foreground">Emergency Responses</div></div>
          </div>
        </motion.div>
      )}
    </div>
  );
}

function SettingsTab() {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const updateUser = useUpdateUser();

  const form = useForm<z.infer<typeof editSchema>>({
    resolver: zodResolver(editSchema),
    defaultValues: {
      name: user?.name ?? "",
      bio: user?.bio ?? "",
      neighborhood: user?.neighborhood ?? "",
      avatar_color: user?.avatar_color ?? "#4CAF50",
    },
  });

  useEffect(() => {
    if (user) {
      form.reset({ name: user.name, bio: user.bio ?? "", neighborhood: user.neighborhood, avatar_color: user.avatar_color ?? "#4CAF50" });
    }
  }, [user]);

  function onSubmit(values: z.infer<typeof editSchema>) {
    if (!user) return;
    updateUser.mutate({ id: user.id, data: values }, {
      onSuccess: (updated) => {
        qc.setQueryData(getGetMeQueryKey(), updated);
        toast({ title: "Profile updated!" });
      },
      onError: () => toast({ title: "Error", description: "Could not update profile.", variant: "destructive" }),
    });
  }

  if (!user) return null;

  const selectedColor = form.watch("avatar_color");

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
        <FormField control={form.control} name="name" render={({ field }) => (
          <FormItem>
            <FormLabel>Display Name</FormLabel>
            <FormControl><Input {...field} data-testid="input-profile-name" /></FormControl>
            <FormMessage />
          </FormItem>
        )} />

        <FormField control={form.control} name="bio" render={({ field }) => (
          <FormItem>
            <FormLabel>Bio (optional)</FormLabel>
            <FormControl>
              <Textarea placeholder="Tell your neighbors about yourself..." className="min-h-[80px]" {...field} data-testid="textarea-bio" />
            </FormControl>
            <FormMessage />
          </FormItem>
        )} />

        <FormField control={form.control} name="neighborhood" render={({ field }) => (
          <FormItem>
            <FormLabel>Neighborhood</FormLabel>
            <FormControl><Input {...field} data-testid="input-neighborhood" /></FormControl>
            <FormMessage />
          </FormItem>
        )} />

        <FormField control={form.control} name="avatar_color" render={({ field }) => (
          <FormItem>
            <FormLabel>Avatar Color</FormLabel>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-sm font-bold" style={{ backgroundColor: selectedColor }}>
                {user.avatar_initials ?? "?"}
              </div>
              <div className="flex flex-wrap gap-2">
                {AVATAR_COLORS.map((color) => (
                  <button
                    key={color} type="button"
                    className={`w-7 h-7 rounded-lg border-2 transition-transform hover:scale-110 ${field.value === color ? "border-foreground scale-110" : "border-transparent"}`}
                    style={{ backgroundColor: color }}
                    onClick={() => field.onChange(color)}
                    data-testid={`color-${color}`}
                  />
                ))}
              </div>
            </div>
          </FormItem>
        )} />

        <Button type="submit" className="w-full" disabled={updateUser.isPending} data-testid="button-save-profile">
          {updateUser.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save Changes"}
        </Button>
      </form>
    </Form>
  );
}

function VerificationTab() {
  const { user } = useAuth();
  const { toast } = useToast();
  if (!user) return null;

  const verifiedCount = VERIFICATION_TIERS.filter((t) => user[t.key]).length;
  const progressPct = (verifiedCount / VERIFICATION_TIERS.length) * 100;

  return (
    <div className="space-y-6">
      <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
        <p className="text-sm text-muted-foreground mb-3">
          Verification builds trust with your neighbors and unlocks higher-value community requests.
          Each level adds to your Community Trust Score.
        </p>
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-semibold flex items-center gap-2"><Shield className="w-4 h-4 text-primary" /> Verification Progress</span>
          <span className="text-sm font-bold text-primary">{verifiedCount}/{VERIFICATION_TIERS.length}</span>
        </div>
        <Progress value={progressPct} className="h-2 mb-1" />
        <p className="text-xs text-muted-foreground">
          {verifiedCount === 0 && "Start verifying to build trust with your neighbors."}
          {verifiedCount > 0 && verifiedCount < 5 && `${VERIFICATION_TIERS.length - verifiedCount} more step${VERIFICATION_TIERS.length - verifiedCount !== 1 ? "s" : ""} to full verification.`}
          {verifiedCount === 5 && "Fully verified — your neighbors can trust you completely."}
        </p>
      </div>

      <div className="space-y-3">
        {VERIFICATION_TIERS.map((tier) => {
          const verified = user[tier.key];
          return (
            <div
              key={tier.key}
              className={`flex items-center justify-between p-4 rounded-xl border transition-colors ${verified ? "bg-green-50 border-green-200" : "bg-card border-card-border"}`}
              data-testid={`verification-${tier.key}`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${verified ? "bg-green-100 text-green-700" : "bg-muted text-muted-foreground"}`}>
                  {verified ? <CheckCircle2 className="w-4 h-4" /> : <span>{tier.level}</span>}
                </div>
                <div>
                  <p className="text-sm font-semibold">{tier.label}</p>
                  <p className="text-xs text-muted-foreground">{tier.desc}</p>
                </div>
              </div>
              {verified ? (
                <span className="text-xs text-green-600 font-medium flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                </span>
              ) : (
                <Button
                  size="sm" variant="outline" className="text-xs h-7"
                  onClick={() => toast({ title: "Verification requested", description: `We'll guide you through ${tier.label.toLowerCase()}. Check your email.` })}
                  data-testid={`button-verify-${tier.key}`}
                >
                  <ChevronRight className="w-3.5 h-3.5 mr-0.5" /> Verify
                </Button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PledgesSection() {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [repayAmounts, setRepayAmounts] = useState<Record<number, string>>({});

  const { data: pledgeSummary, isLoading } = useGetMyPledges({
    query: { enabled: !!user, queryKey: getGetMyPledgesQueryKey() },
  });

  const repayPledge = useRepayPledge();

  function handleRepay(pledgeId: number) {
    const amount = parseFloat(repayAmounts[pledgeId] ?? "0");
    if (!amount || amount <= 0) return;
    repayPledge.mutate({ id: pledgeId, data: { amount } }, {
      onSuccess: (r) => {
        qc.invalidateQueries({ queryKey: getGetMyPledgesQueryKey() });
        setRepayAmounts((prev) => ({ ...prev, [pledgeId]: "" }));
        toast({ title: "Payment recorded!", description: `Community fund updated: $${r.new_balance?.toFixed(2)}` });
      },
    });
  }

  if (!user || isLoading) return <Skeleton className="h-32 rounded-xl" />;
  if (!pledgeSummary || pledgeSummary.pledges.length === 0) return null;

  return (
    <div className="mt-6">
      <h3 className="font-semibold mb-3 flex items-center gap-2">
        <HandCoins className="w-4 h-4 text-primary" />
        Pay It Forward Pledges
      </h3>
      <div className="bg-muted/40 rounded-xl p-4 mb-4 grid grid-cols-2 gap-4 text-sm">
        <div><span className="text-muted-foreground">Open pledges:</span> <span className="font-bold">{pledgeSummary.open_count}</span></div>
        <div><span className="text-muted-foreground">Total owed:</span> <span className="font-bold text-destructive">${pledgeSummary.total_owed.toFixed(2)}</span></div>
        <div><span className="text-muted-foreground">Lifetime received:</span> <span className="font-bold">${pledgeSummary.lifetime_received.toFixed(2)}</span></div>
        <div><span className="text-muted-foreground">Lifetime repaid:</span> <span className="font-bold text-green-600">${pledgeSummary.lifetime_repaid.toFixed(2)}</span></div>
      </div>
      <div className="space-y-3">
        {pledgeSummary.pledges.filter((p) => p.status !== "fulfilled").map((pledge) => {
          const owed = pledge.original_amount - pledge.amount_returned;
          return (
            <div key={pledge.id} className="bg-card border border-card-border rounded-xl p-4">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="font-semibold text-sm">{pledge.source_request_title ?? "Help received"}</p>
                  <p className="text-xs text-muted-foreground">
                    Received: ${pledge.original_amount} · Repaid: ${pledge.amount_returned.toFixed(2)}
                    {pledge.repayment_timeline && ` · ${pledge.repayment_timeline}`}
                  </p>
                </div>
                <Badge variant="outline" className="text-xs capitalize">{pledge.status}</Badge>
              </div>
              <Progress value={(pledge.amount_returned / pledge.original_amount) * 100} className="h-1.5 mb-3" />
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <span className="absolute left-2.5 top-2 text-xs text-muted-foreground">$</span>
                  <Input
                    type="number" placeholder={`${owed.toFixed(2)} owed`} className="pl-6 h-8 text-xs"
                    value={repayAmounts[pledge.id] ?? ""}
                    onChange={(e) => setRepayAmounts((p) => ({ ...p, [pledge.id]: e.target.value }))}
                    data-testid={`input-repay-${pledge.id}`}
                  />
                </div>
                <Button size="sm" className="h-8 text-xs" onClick={() => handleRepay(pledge.id)} data-testid={`button-repay-${pledge.id}`}>Pay Back</Button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function ProfilePage() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="text-center py-20">
        <User className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-30" />
        <h2 className="font-serif text-xl font-semibold mb-2">Sign in to view your profile</h2>
        <Link href="/login"><Button>Sign In</Button></Link>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto pb-16">
      <div className="mb-5">
        <h1 className="font-serif text-2xl font-bold">My Profile</h1>
        <p className="text-sm text-muted-foreground">Your community identity &amp; wallet</p>
      </div>

      <Tabs defaultValue="overview">
        <TabsList className="w-full grid grid-cols-3 mb-6">
          <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
          <TabsTrigger value="settings" data-testid="tab-settings">Settings</TabsTrigger>
          <TabsTrigger value="verification" data-testid="tab-verification">Verification</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <OverviewTab />
          <PledgesSection />
        </TabsContent>
        <TabsContent value="settings"><SettingsTab /></TabsContent>
        <TabsContent value="verification"><VerificationTab /></TabsContent>
      </Tabs>
    </div>
  );
}
