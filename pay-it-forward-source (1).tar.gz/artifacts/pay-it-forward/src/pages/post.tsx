import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { useCreateRequest, getListRequestsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useAuth } from "@/contexts/AuthContext";
import { Link } from "wouter";
import { Loader2, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const CATEGORIES = [
  "Transportation", "Food Delivery", "Elder Care", "Childcare", "Home Repairs",
  "Moving", "Financial Assistance", "Yard Work", "Technology Help", "Pet Care",
  "Medical", "Mental Health", "Education", "Other",
];

const NEIGHBORHOODS = [
  "Near Southside", "Fairmount", "Eastside", "Arlington Heights",
  "Haltom City", "Polytechnic Heights", "Downtown Fort Worth", "Benbrook",
  "Wedgwood", "Como", "Riverside", "North Fort Worth",
];

const schema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  description: z.string().min(20, "Please describe what you need (at least 20 chars)"),
  category: z.string().min(1, "Select a category"),
  neighborhood: z.string().min(1, "Select your neighborhood"),
  urgency: z.string().default("normal"),
  funding_source: z.string().default("volunteer"),
  budget: z.string().optional(),
  recurring: z.string().default("one_time"),
  is_anonymous: z.boolean().default(false),
  is_business: z.boolean().default(false),
  business_name: z.string().optional(),
  repayment_timeline: z.string().optional(),
});

export default function PostPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const createRequest = useCreateRequest();

  const form = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
    defaultValues: {
      title: "", description: "", category: "", neighborhood: user?.neighborhood ?? "",
      urgency: "normal", funding_source: "volunteer", budget: "",
      recurring: "one_time", is_anonymous: false, is_business: false,
      business_name: "", repayment_timeline: "",
    },
  });

  const fundingSource = form.watch("funding_source");
  const isBusiness = form.watch("is_business");

  function onSubmit(values: z.infer<typeof schema>) {
    createRequest.mutate({
      data: {
        ...values,
        budget: values.budget ? parseFloat(values.budget) : undefined,
      }
    }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListRequestsQueryKey() });
        toast({ title: "Request posted!", description: "Neighbors will be notified." });
        setLocation("/opportunities");
      },
      onError: () => {
        toast({ title: "Could not post request", description: "Please try again.", variant: "destructive" });
      },
    });
  }

  if (!user) {
    return (
      <div className="text-center py-20">
        <h2 className="font-serif text-xl font-semibold mb-2">Sign in to post a request</h2>
        <Link href="/login"><Button>Sign In</Button></Link>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto pb-16">
      <div className="flex items-center gap-3 mb-6">
        <Link href="/" className="text-muted-foreground hover:text-foreground">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="font-serif text-2xl font-bold">Ask for Help</h1>
          <p className="text-sm text-muted-foreground">Your Fort Worth neighbors are here</p>
        </div>
      </div>

      <div className="bg-card border border-card-border rounded-2xl p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <FormField control={form.control} name="title" render={({ field }) => (
              <FormItem>
                <FormLabel>What do you need?</FormLabel>
                <FormControl>
                  <Input placeholder="e.g. Ride to medical appointment Thursday" data-testid="input-title" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <FormField control={form.control} name="description" render={({ field }) => (
              <FormItem>
                <FormLabel>Tell us more</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Details: when, how long, any special requirements..."
                    className="min-h-[100px]"
                    data-testid="textarea-description"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <div className="grid grid-cols-2 gap-4">
              <FormField control={form.control} name="category" render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-category">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField control={form.control} name="urgency" render={({ field }) => (
                <FormItem>
                  <FormLabel>Urgency</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-urgency">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                      <SelectItem value="emergency">Emergency</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
            </div>

            <FormField control={form.control} name="neighborhood" render={({ field }) => (
              <FormItem>
                <FormLabel>Your Neighborhood</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-neighborhood">
                      <SelectValue placeholder="Select neighborhood" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {NEIGHBORHOODS.map((n) => <SelectItem key={n} value={n}>{n}</SelectItem>)}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )} />

            {/* FUNDING SOURCE - 4 options as required */}
            <FormField control={form.control} name="funding_source" render={({ field }) => (
              <FormItem>
                <FormLabel>How will this be covered?</FormLabel>
                <FormDescription>Choose how you'd like this request to be funded.</FormDescription>
                <div className="grid grid-cols-1 gap-2 mt-2">
                  {[
                    {
                      value: "direct",
                      label: "Pay Now",
                      desc: "You'll pay the helper directly",
                    },
                    {
                      value: "community_fund",
                      label: "Community Fund Assistance",
                      desc: "Request funding from the community pool (admin review required)",
                    },
                    {
                      value: "pay_forward",
                      label: "Pay It Forward",
                      desc: "Receive help now and pay it back when you're able",
                    },
                    {
                      value: "volunteer",
                      label: "Volunteer Request",
                      desc: "Looking for someone to volunteer their time",
                    },
                  ].map((opt) => (
                    <label
                      key={opt.value}
                      className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-colors ${
                        field.value === opt.value
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/30"
                      }`}
                      data-testid={`funding-option-${opt.value}`}
                    >
                      <input
                        type="radio"
                        className="mt-1 accent-primary"
                        checked={field.value === opt.value}
                        onChange={() => field.onChange(opt.value)}
                      />
                      <div>
                        <div className="text-sm font-semibold">{opt.label}</div>
                        <div className="text-xs text-muted-foreground">{opt.desc}</div>
                      </div>
                    </label>
                  ))}
                </div>
                <FormMessage />
              </FormItem>
            )} />

            {(fundingSource === "direct" || fundingSource === "community_fund") && (
              <FormField control={form.control} name="budget" render={({ field }) => (
                <FormItem>
                  <FormLabel>Budget (optional)</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5 text-muted-foreground text-sm">$</span>
                      <Input type="number" placeholder="0.00" className="pl-7" data-testid="input-budget" {...field} />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            )}

            {fundingSource === "pay_forward" && (
              <div className="rounded-xl bg-primary/5 border border-primary/20 p-4 space-y-3">
                <div className="flex items-start gap-3">
                  <span className="text-2xl">🤝</span>
                  <div>
                    <p className="text-sm font-semibold text-primary">Pay It Forward Network</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Nobody is excluded because they're temporarily struggling. Your request will be covered by the community.
                    </p>
                  </div>
                </div>

                {/* Funding chain */}
                <div className="flex flex-col gap-1.5 text-xs">
                  {[
                    { step: "Your Request", note: "Posted to community", color: "bg-primary" },
                    { step: "Community Fund", note: "First source checked", color: "bg-green-500" },
                    { step: "Business Sponsors", note: "Local businesses top up the fund", color: "bg-amber-500" },
                    { step: "County Assistance", note: "CDBG-eligible backup funding", color: "bg-blue-500" },
                    { step: "Deferred Payment", note: "You repay when you're able", color: "bg-purple-500" },
                    { step: "Helper Gets Paid", note: "Always. Community ensures it.", color: "bg-emerald-500" },
                  ].map((s, i, arr) => (
                    <div key={s.step} className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full shrink-0 ${s.color}`} />
                      <span className="font-semibold text-foreground">{s.step}</span>
                      <span className="text-muted-foreground">— {s.note}</span>
                      {i < arr.length - 1 && <div className="w-px h-3 bg-border ml-0.5 mt-3 absolute" style={{ display: "none" }} />}
                    </div>
                  ))}
                </div>

                <FormField control={form.control} name="repayment_timeline" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs">Your Repayment Timeline</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-repayment" className="h-9 text-sm">
                          <SelectValue placeholder="When can you repay?" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="1_month">Within 1 month</SelectItem>
                        <SelectItem value="3_months">Within 3 months</SelectItem>
                        <SelectItem value="6_months">Within 6 months</SelectItem>
                        <SelectItem value="when_able">When I'm able — no pressure</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <p className="text-[11px] text-muted-foreground">
                  Choosing "when able" means the community trusts you to repay when your situation improves. Your account is never blocked for non-payment.
                </p>
              </div>
            )}

            <FormField control={form.control} name="recurring" render={({ field }) => (
              <FormItem>
                <FormLabel>Frequency</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-recurring">
                      <SelectValue />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="one_time">One Time</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )} />

            <div className="space-y-3 pt-2 border-t border-border">
              <FormField control={form.control} name="is_anonymous" render={({ field }) => (
                <FormItem className="flex items-center justify-between">
                  <div>
                    <FormLabel>Post anonymously</FormLabel>
                    <FormDescription className="text-xs">Your name won't be shown publicly</FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-anonymous" />
                  </FormControl>
                </FormItem>
              )} />

              <FormField control={form.control} name="is_business" render={({ field }) => (
                <FormItem className="flex items-center justify-between">
                  <div>
                    <FormLabel>Business request</FormLabel>
                    <FormDescription className="text-xs">This is on behalf of a local business</FormDescription>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-business" />
                  </FormControl>
                </FormItem>
              )} />

              {isBusiness && (
                <FormField control={form.control} name="business_name" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Business Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Your business name" data-testid="input-business-name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              )}
            </div>

            <Button type="submit" className="w-full" disabled={createRequest.isPending} data-testid="button-submit-request">
              {createRequest.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Post Request"}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
