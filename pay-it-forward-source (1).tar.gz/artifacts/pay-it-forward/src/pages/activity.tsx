import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  useListJobs, useUpdateJob, useListNotifications,
  useMarkNotificationRead, useMarkAllNotificationsRead,
  useListRequests, useCreateGratitude, useListGratitude,
  getListJobsQueryKey, getListNotificationsQueryKey, getListRequestsQueryKey,
  getListGratitudeQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  Bell, Clock, CheckCircle2, MapPin, AlertCircle, XCircle,
  Heart, Sparkles, Send, MessageSquare, HeartHandshake, Star,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.06 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.28 } } };

const STATUS_COLORS: Record<string, string> = {
  accepted: "bg-blue-100 text-blue-700",
  in_progress: "bg-amber-100 text-amber-700",
  completed: "bg-green-100 text-green-700",
  cancelled: "bg-muted text-muted-foreground",
};

const STATUS_LABELS: Record<string, string> = {
  accepted: "Accepted",
  in_progress: "In Progress",
  completed: "Completed",
  cancelled: "Cancelled",
};

// ── Inline gratitude card for completed requests ─────────────────────────────
function ThankYouCard({
  jobId,
  requestId,
}: {
  jobId: number;
  requestId: number;
}) {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);
  const { toast } = useToast();
  const qc = useQueryClient();
  const createGratitude = useCreateGratitude();

  if (sent) {
    return (
      <div className="mt-3 flex items-center gap-2 text-xs text-green-600 font-medium">
        <Heart className="w-3.5 h-3.5 fill-green-600" />
        Thank-you note sent to your helper
      </div>
    );
  }

  return (
    <div className="mt-3">
      {!open ? (
        <button
          className="flex items-center gap-1.5 text-xs font-semibold text-primary hover:text-primary/80 transition-colors"
          onClick={() => setOpen(true)}
          data-testid={`button-send-thanks-${jobId}`}
        >
          <Heart className="w-3.5 h-3.5" />
          Send a thank-you note to your helper
        </button>
      ) : (
        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-green-50 border border-green-200 rounded-xl p-3 space-y-2"
          >
            <p className="text-xs font-semibold text-green-800 flex items-center gap-1">
              <Heart className="w-3.5 h-3.5" />
              Write a note for your helper
            </p>
            <Textarea
              placeholder="Their help meant so much because..."
              className="text-sm min-h-[72px] bg-white border-green-200 focus:ring-green-400"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              data-testid={`textarea-thanks-${jobId}`}
            />
            <div className="flex gap-2">
              <Button
                size="sm"
                className="bg-green-600 hover:bg-green-700 text-white text-xs h-7"
                disabled={!message.trim() || createGratitude.isPending}
                onClick={() => {
                  createGratitude.mutate(
                    { data: { request_id: requestId, message, is_public: true } },
                    {
                      onSuccess: () => {
                        setSent(true);
                        setOpen(false);
                        qc.invalidateQueries({ queryKey: getListGratitudeQueryKey() });
                        toast({ title: "Thank-you note sent!", description: "Your gratitude has been shared with the community." });
                      },
                      onError: () => toast({ title: "Could not send", description: "Please try again.", variant: "destructive" }),
                    }
                  );
                }}
                data-testid={`button-submit-thanks-${jobId}`}
              >
                <Send className="w-3 h-3 mr-1" /> Send Thanks
              </Button>
              <Button size="sm" variant="ghost" className="text-xs h-7" onClick={() => setOpen(false)}>
                Cancel
              </Button>
            </div>
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  );
}

// ── Gratitude tab ─────────────────────────────────────────────────────────────
function GratitudeTab() {
  const { user } = useAuth();
  // API only supports request_id filter — load all public gratitude and display community-wide
  const { data: allGratitude, isLoading } = useListGratitude(undefined, {
    query: { queryKey: getListGratitudeQueryKey() },
  });

  if (isLoading) return <div className="space-y-2">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 rounded-xl" />)}</div>;

  // Tag notes where the current user is sender or recipient
  const allNotes = (allGratitude ?? []).map((n) => ({
    ...n,
    direction:
      user && n.to_user_id === user.id
        ? ("received" as const)
        : ("sent" as const),
  }));

  if (allNotes.length === 0) {
    return (
      <div className="text-center py-14 text-muted-foreground">
        <Heart className="w-10 h-10 mx-auto mb-2 opacity-30" />
        <p className="font-medium">No gratitude notes yet</p>
        <p className="text-sm">Complete an act of service or send a thank-you to a helper.</p>
      </div>
    );
  }

  return (
    <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-3">
      {allNotes.map((note) => (
        <motion.div
          key={`${note.direction}-${note.id}`}
          variants={item}
          className={`rounded-xl border p-4 ${
            note.direction === "received"
              ? "bg-green-50 border-green-200"
              : "bg-card border-card-border"
          }`}
          data-testid={`gratitude-${note.direction}-${note.id}`}
        >
          <div className="flex items-start gap-3">
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0"
              style={{ backgroundColor: note.from_user_avatar_color ?? "#4CAF50" }}
            >
              {note.from_user_name?.slice(0, 2).toUpperCase() ?? "?"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold mb-0.5">
                {note.direction === "received" ? (
                  <span className="text-green-700">
                    {note.from_user_name ?? "A neighbor"} thanked you
                  </span>
                ) : (
                  <span className="text-muted-foreground">
                    You thanked {note.to_user_name ?? "your helper"}
                  </span>
                )}
              </p>
              <p className="text-sm text-foreground italic leading-relaxed">"{note.message}"</p>
              <p className="text-xs text-muted-foreground mt-1.5">
                {new Date(note.created_at).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                {note.is_public && <span className="ml-2 text-primary font-medium">Shared publicly</span>}
              </p>
            </div>
            <Heart className={`w-4 h-4 shrink-0 mt-0.5 ${note.direction === "received" ? "text-green-500 fill-green-200" : "text-muted-foreground"}`} />
          </div>
        </motion.div>
      ))}
    </motion.div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export default function ActivityPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data: myJobs, isLoading: jobsLoading } = useListJobs(
    user ? { helper_id: user.id } : {},
    { query: { enabled: !!user, queryKey: getListJobsQueryKey(user ? { helper_id: user.id } : {}) } }
  );

  const { data: myRequests, isLoading: reqsLoading } = useListRequests(
    user ? { requester_id: user.id } : {},
    { query: { enabled: !!user, queryKey: getListRequestsQueryKey(user ? { requester_id: user.id } : {}) } }
  );

  const { data: notifications, isLoading: notifsLoading } = useListNotifications({
    query: { enabled: !!user, queryKey: getListNotificationsQueryKey() },
  });

  const markRead = useMarkNotificationRead();
  const markAllRead = useMarkAllNotificationsRead();
  const updateJob = useUpdateJob();

  function handleMarkAllRead() {
    markAllRead.mutate(undefined, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListNotificationsQueryKey() });
        toast({ title: "All notifications marked as read" });
      },
    });
  }

  function handleCompleteJob(jobId: number) {
    updateJob.mutate({ id: jobId, data: { status: "completed" } }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListJobsQueryKey() });
        toast({
          title: "Act of service complete!",
          description: "Your neighbor has been notified. Thank you for making a difference.",
        });
      },
    });
  }

  function handleCancelJob(jobId: number) {
    updateJob.mutate({ id: jobId, data: { status: "cancelled" } }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListJobsQueryKey() });
        toast({ title: "Cancelled." });
      },
    });
  }

  if (!user) {
    return (
      <div className="text-center py-20">
        <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-30" />
        <h2 className="font-serif text-xl font-semibold mb-2">Sign in to see your impact</h2>
        <Link href="/login"><Button>Sign In</Button></Link>
      </div>
    );
  }

  const unreadCount = (notifications ?? []).filter((n) => !n.read).length;

  return (
    <div className="pb-8">
      <div className="mb-6">
        <h1 className="font-serif text-2xl font-bold mb-1">My Impact</h1>
        <p className="text-sm text-muted-foreground">
          Your acts of service, neighbor requests &amp; community connections
        </p>
      </div>

      {/* Quick stats banner */}
      {user && (
        <div className="grid grid-cols-3 gap-3 mb-6">
          {[
            { label: "Acts of Service", value: user.help_count, icon: HeartHandshake, color: "text-primary" },
            { label: "Volunteer Hours", value: user.volunteer_hours, icon: Clock, color: "text-amber-600" },
            { label: "Paid Forward", value: `$${user.pay_forward_total.toFixed(0)}`, icon: Star, color: "text-green-600" },
          ].map((s) => (
            <div key={s.label} className="bg-card border border-card-border rounded-xl p-3 text-center">
              <s.icon className={`w-4 h-4 mx-auto mb-1 ${s.color}`} />
              <div className={`text-lg font-bold ${s.color}`}>{s.value}</div>
              <div className="text-[10px] text-muted-foreground leading-tight">{s.label}</div>
            </div>
          ))}
        </div>
      )}

      <Tabs defaultValue="jobs">
        <TabsList className="w-full grid grid-cols-4 mb-6">
          <TabsTrigger value="jobs" data-testid="tab-acts-of-service">
            <Sparkles className="w-3.5 h-3.5 mr-1" /> Service
          </TabsTrigger>
          <TabsTrigger value="requests" data-testid="tab-neighbor-requests">
            Requests
          </TabsTrigger>
          <TabsTrigger value="gratitude" data-testid="tab-gratitude">
            <Heart className="w-3.5 h-3.5 mr-1" /> Thanks
          </TabsTrigger>
          <TabsTrigger value="notifications" data-testid="tab-notifications">
            Alerts
            {unreadCount > 0 && (
              <span className="ml-1 bg-destructive text-destructive-foreground text-[10px] rounded-full w-4 h-4 inline-flex items-center justify-center font-bold">
                {unreadCount}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        {/* ── Acts of Service (was "My Jobs") ── */}
        <TabsContent value="jobs">
          <p className="text-xs text-muted-foreground mb-4 flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            Every act of service you complete shows up here.
          </p>
          {jobsLoading ? (
            <div className="space-y-3">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-28 rounded-xl" />)}</div>
          ) : (myJobs ?? []).length === 0 ? (
            <div className="text-center py-14 text-muted-foreground">
              <HeartHandshake className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="font-medium">No acts of service yet</p>
              <p className="text-sm mt-1">Browse community missions and help a neighbor today.</p>
              <Link href="/opportunities">
                <Button className="mt-4" variant="outline" data-testid="button-browse-missions">
                  Browse Community Missions
                </Button>
              </Link>
            </div>
          ) : (
            <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-3">
              {(myJobs ?? []).map((job) => (
                <motion.div
                  key={job.id}
                  variants={item}
                  className="bg-card border border-card-border rounded-xl p-4"
                  data-testid={`card-service-${job.id}`}
                >
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm">{job.request_title ?? "Neighbor Request"}</p>
                      <p className="text-xs text-muted-foreground line-clamp-2">{job.request_description}</p>
                    </div>
                    <Badge className={`text-xs shrink-0 ${STATUS_COLORS[job.status] ?? ""}`}>
                      {STATUS_LABELS[job.status] ?? job.status}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap gap-3 text-xs text-muted-foreground mb-3">
                    {job.request_neighborhood && (
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />{job.request_neighborhood}
                      </span>
                    )}
                    {job.request_category && <span>{job.request_category}</span>}
                    {job.budget && <span className="font-semibold text-foreground">${job.budget}</span>}
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />{new Date(job.created_at).toLocaleDateString()}
                    </span>
                  </div>

                  {(job.status === "accepted" || job.status === "in_progress") && (
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => handleCompleteJob(job.id)}
                        data-testid={`button-complete-service-${job.id}`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Mark Complete
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleCancelJob(job.id)}
                        className="text-destructive border-destructive/30"
                        data-testid={`button-cancel-service-${job.id}`}
                      >
                        <XCircle className="w-3.5 h-3.5 mr-1" /> Cancel
                      </Button>
                    </div>
                  )}

                  {job.status === "completed" && (
                    <div>
                      <p className="text-xs text-green-600 flex items-center gap-1 mb-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Completed {job.completed_at ? new Date(job.completed_at).toLocaleDateString() : ""}
                        {job.requester_name && ` · helped ${job.requester_name}`}
                      </p>
                    </div>
                  )}
                </motion.div>
              ))}
            </motion.div>
          )}
        </TabsContent>

        {/* ── Neighbor Requests (was "My Requests") ── */}
        <TabsContent value="requests">
          <p className="text-xs text-muted-foreground mb-4">
            Requests you've posted to the community. When a request is completed, you can send a thank-you note.
          </p>
          {reqsLoading ? (
            <div className="space-y-3">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-24 rounded-xl" />)}</div>
          ) : (myRequests ?? []).length === 0 ? (
            <div className="text-center py-14 text-muted-foreground">
              <AlertCircle className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="font-medium">No neighbor requests yet</p>
              <Link href="/post">
                <Button className="mt-4" data-testid="button-post-request">Post a Request</Button>
              </Link>
            </div>
          ) : (
            <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-3">
              {(myRequests ?? []).map((req) => (
                <motion.div
                  key={req.id}
                  variants={item}
                  className={`bg-card border rounded-xl p-4 transition-colors ${
                    req.status === "completed" ? "border-green-200 bg-green-50/30" : "border-card-border"
                  }`}
                  data-testid={`card-my-request-${req.id}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm">{req.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{req.description}</p>
                      <div className="flex flex-wrap gap-2 mt-2 text-xs text-muted-foreground">
                        <span>{req.category}</span>
                        <span><MapPin className="w-3 h-3 inline mr-0.5" />{req.neighborhood}</span>
                        <span>{new Date(req.created_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <div className="shrink-0 text-right">
                      <Badge
                        variant="outline"
                        className={`text-xs capitalize ${req.status === "completed" ? "border-green-300 text-green-700 bg-green-50" : ""}`}
                      >
                        {req.status.replace("_", " ")}
                      </Badge>
                      {req.budget && <p className="text-xs font-bold mt-1">${req.budget}</p>}
                    </div>
                  </div>

                  {/* Gratitude flow — only when completed and there's a helper */}
                  {req.status === "completed" && (
                    <ThankYouCard jobId={req.id} requestId={req.id} />
                  )}
                </motion.div>
              ))}
            </motion.div>
          )}
        </TabsContent>

        {/* ── Gratitude Notes ── */}
        <TabsContent value="gratitude">
          <p className="text-xs text-muted-foreground mb-4 flex items-center gap-1">
            <Heart className="w-3 h-3 text-green-500" />
            Thank-you notes you've sent and received from neighbors.
          </p>
          <GratitudeTab />
        </TabsContent>

        {/* ── Notifications ── */}
        <TabsContent value="notifications">
          {notifsLoading ? (
            <div className="space-y-2">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-16 rounded-xl" />)}</div>
          ) : (
            <>
              {unreadCount > 0 && (
                <div className="flex justify-end mb-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleMarkAllRead}
                    data-testid="button-mark-all-read"
                  >
                    Mark all read
                  </Button>
                </div>
              )}
              {(notifications ?? []).length === 0 ? (
                <div className="text-center py-14 text-muted-foreground">
                  <Bell className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  <p>No notifications yet</p>
                </div>
              ) : (
                <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-2">
                  {(notifications ?? []).map((n) => (
                    <motion.div
                      key={n.id}
                      variants={item}
                      className={`flex gap-3 rounded-xl p-4 border transition-colors cursor-pointer ${
                        n.read ? "bg-card border-card-border" : "bg-primary/5 border-primary/20"
                      }`}
                      onClick={() => {
                        if (!n.read) {
                          markRead.mutate({ id: n.id }, {
                            onSuccess: () => qc.invalidateQueries({ queryKey: getListNotificationsQueryKey() }),
                          });
                        }
                      }}
                      data-testid={`notification-${n.id}`}
                    >
                      <MessageSquare className={`w-4 h-4 mt-0.5 shrink-0 ${n.read ? "text-muted-foreground" : "text-primary"}`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{n.title}</p>
                        <p className="text-xs text-muted-foreground">{n.message}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(n.created_at).toLocaleString()}
                        </p>
                      </div>
                      {!n.read && <div className="w-2 h-2 rounded-full bg-primary shrink-0 mt-1.5" />}
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
