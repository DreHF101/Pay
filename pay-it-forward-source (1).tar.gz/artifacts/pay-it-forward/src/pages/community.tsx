import { useState } from "react";
import { motion } from "framer-motion";
import {
  useGetCommunityFund, useGetPayForwardLog, useListFundRequests, useContributeToFund,
  useApproveFundRequest, useDenyFundRequest, useListImpactStories,
  getGetCommunityFundQueryKey, getGetPayForwardLogQueryKey, getListFundRequestsQueryKey,
  getListImpactStoriesQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  HandCoins, Users, Timer, Utensils, Car, AlertTriangle,
  CheckCircle2, XCircle, BookOpen, Building2, Star, TrendingUp,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.08 } } };
const item = { hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0 } };

const SPONSORS = [
  { name: "Fort Worth Chamber of Commerce", type: "Business", contribution: "$2,500", focus: "Transportation" },
  { name: "Tarrant Area Food Bank", type: "Nonprofit", contribution: "In-Kind", focus: "Food Delivery" },
  { name: "Frost Bank - Near Southside Branch", type: "Financial", contribution: "$1,000", focus: "Financial Assistance" },
  { name: "Cook Children's Community Services", type: "Healthcare", contribution: "$5,000", focus: "Childcare" },
  { name: "Trinity Habitat for Humanity", type: "Housing", contribution: "Volunteer Labor", focus: "Home Repairs" },
  { name: "Fort Worth ISD Community Partners", type: "Education", contribution: "$750", focus: "Education" },
];

function FundTab() {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [contributeAmount, setContributeAmount] = useState("");

  const { data: fund, isLoading } = useGetCommunityFund({ query: { queryKey: getGetCommunityFundQueryKey() } });
  const contribute = useContributeToFund();

  const stats = fund ? [
    { icon: Users, label: "Neighbors Helped", value: fund.neighbors_helped },
    { icon: Car, label: "Rides Provided", value: fund.rides_provided },
    { icon: Utensils, label: "Meals Delivered", value: fund.meals_delivered },
    { icon: AlertTriangle, label: "Emergency Responses", value: fund.emergency_responses },
    { icon: Timer, label: "Volunteer Hours", value: fund.hours_donated },
    { icon: HandCoins, label: "Requests Funded", value: fund.requests_funded },
  ] : [];

  function handleContribute() {
    const amount = parseFloat(contributeAmount);
    if (!amount || amount <= 0) return;
    contribute.mutate({ data: { amount } }, {
      onSuccess: (r) => {
        setContributeAmount("");
        qc.invalidateQueries({ queryKey: getGetCommunityFundQueryKey() });
        toast({ title: "Contribution recorded!", description: `Fund balance: $${r.new_balance?.toFixed(2)}` });
      },
      onError: () => toast({ title: "Error", description: "Could not process contribution.", variant: "destructive" }),
    });
  }

  if (isLoading) return <div className="space-y-3">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 rounded-xl" />)}</div>;

  return (
    <div className="space-y-6">
      {/* Balance card */}
      <div className="bg-primary text-primary-foreground rounded-2xl p-6">
        <p className="text-sm font-medium opacity-80 mb-1">Community Fund Balance</p>
        <p className="font-serif text-4xl font-bold">${fund?.balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
        <div className="flex gap-4 mt-3 text-sm opacity-80">
          <span>Contributed: ${fund?.total_contributed.toLocaleString()}</span>
          <span>Disbursed: ${fund?.total_disbursed.toLocaleString()}</span>
        </div>
      </div>

      {/* Stats grid */}
      <motion.div variants={stagger} initial="hidden" animate="show" className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {stats.map((s) => (
          <motion.div key={s.label} variants={item} className="bg-card border border-card-border rounded-xl p-4 text-center">
            <s.icon className="w-5 h-5 text-primary mx-auto mb-1.5" />
            <div className="text-2xl font-bold">{s.value}</div>
            <div className="text-xs text-muted-foreground">{s.label}</div>
          </motion.div>
        ))}
      </motion.div>

      {/* Contribute */}
      {user && (
        <div className="bg-card border border-card-border rounded-xl p-5">
          <h3 className="font-semibold mb-3">Contribute to the Fund</h3>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <span className="absolute left-3 top-2.5 text-muted-foreground text-sm">$</span>
              <Input
                type="number"
                placeholder="Amount"
                className="pl-7"
                value={contributeAmount}
                onChange={(e) => setContributeAmount(e.target.value)}
                data-testid="input-contribute-amount"
              />
            </div>
            <Button onClick={handleContribute} disabled={contribute.isPending || !contributeAmount} data-testid="button-contribute">
              Contribute
            </Button>
          </div>
          {[10, 25, 50, 100].map((amt) => (
            <button
              key={amt}
              className="mr-2 mt-2 text-xs bg-muted hover:bg-muted/80 px-3 py-1 rounded-full transition-colors"
              onClick={() => setContributeAmount(String(amt))}
              data-testid={`button-quick-${amt}`}
            >
              ${amt}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function PayForwardTab() {
  const { data: log, isLoading } = useGetPayForwardLog({ query: { queryKey: getGetPayForwardLogQueryKey() } });

  if (isLoading) return <div className="space-y-2">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-14 rounded-lg" />)}</div>;

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground mb-4">
        Every contribution creates a ripple. Here's who's paying it forward.
      </p>
      {(log ?? []).length === 0 ? (
        <div className="text-center py-10 text-muted-foreground">
          <HandCoins className="w-10 h-10 mx-auto mb-2 opacity-30" />
          <p>No contributions yet — be the first!</p>
        </div>
      ) : (
        <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-2">
          {(log ?? []).map((entry) => (
            <motion.div key={entry.id} variants={item} className="flex items-center justify-between bg-card border border-card-border rounded-xl px-4 py-3">
              <div>
                <p className="text-sm font-medium">Neighbor #{entry.from_user_id}</p>
                {entry.note && <p className="text-xs text-muted-foreground">"{entry.note}"</p>}
              </div>
              <div className="text-right">
                <p className="font-bold text-primary">${entry.amount}</p>
                <p className="text-xs text-muted-foreground">{new Date(entry.created_at).toLocaleDateString()}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  );
}

function ImpactTab() {
  const { data: fund } = useGetCommunityFund({ query: { queryKey: getGetCommunityFundQueryKey() } });

  const metrics = fund ? [
    { label: "Families Assisted", value: fund.families_assisted, color: "text-primary" },
    { label: "Households Supported", value: fund.households_supported, color: "text-secondary-foreground" },
    { label: "Mentorship Relationships", value: fund.mentorship_relationships, color: "text-blue-600" },
    { label: "Repeat Connections", value: fund.repeat_connections, color: "text-green-600" },
    { label: "Emergency Responses", value: fund.emergency_responses, color: "text-red-600" },
    { label: "Total People Helped", value: fund.people_helped, color: "text-purple-600" },
  ] : [];

  return (
    <div className="space-y-6">
      <p className="text-sm text-muted-foreground">
        Real numbers. Real people. The measurable impact of Fort Worth neighbors helping each other.
      </p>
      <motion.div variants={stagger} initial="hidden" animate="show" className="grid grid-cols-2 gap-3">
        {metrics.map((m) => (
          <motion.div key={m.label} variants={item} className="bg-card border border-card-border rounded-xl p-5 text-center">
            <TrendingUp className={`w-5 h-5 mx-auto mb-2 ${m.color}`} />
            <div className={`text-3xl font-bold ${m.color}`}>{m.value}</div>
            <div className="text-xs text-muted-foreground mt-1">{m.label}</div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}

function SponsorsTab() {
  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground mb-4">
        Local businesses and organizations partnering with Fort Worth neighbors.
      </p>
      <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-3">
        {SPONSORS.map((s) => (
          <motion.div key={s.name} variants={item} className="bg-card border border-card-border rounded-xl p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-muted-foreground" />
                </div>
                <div>
                  <p className="font-semibold text-sm">{s.name}</p>
                  <p className="text-xs text-muted-foreground">{s.type} • Focus: {s.focus}</p>
                </div>
              </div>
              <div className="text-right shrink-0">
                <Badge variant="secondary" className="text-xs font-semibold">{s.contribution}</Badge>
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>
      <div className="bg-muted/40 rounded-xl p-4 text-center mt-6">
        <Star className="w-6 h-6 text-secondary mx-auto mb-2" />
        <p className="font-semibold text-sm">Become a Sponsor</p>
        <p className="text-xs text-muted-foreground mt-1">Partner with the Pay It Forward network to support Fort Worth families.</p>
        <Button variant="outline" size="sm" className="mt-3">Learn More</Button>
      </div>
    </div>
  );
}

function StoriesTab() {
  const { data, isLoading } = useListImpactStories({ query: { queryKey: getListImpactStoriesQueryKey() } });

  if (isLoading) return <div className="space-y-3">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-36 rounded-xl" />)}</div>;

  const stats = data?.weekly_stats;

  return (
    <div className="space-y-6">
      {stats && (
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "Helped This Week", value: stats.completions_this_week },
            { label: "Volunteer Hours", value: stats.volunteer_hours },
            { label: "New Requests", value: stats.requests_this_week },
          ].map((s) => (
            <div key={s.label} className="bg-muted/40 rounded-xl p-3 text-center">
              <div className="text-2xl font-bold text-primary">{s.value}</div>
              <div className="text-xs text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      )}

      <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-4">
        {(data?.stories ?? []).map((story) => (
          <motion.div
            key={story.id}
            variants={item}
            className="bg-card border border-card-border rounded-xl p-5"
            data-testid={`card-story-${story.id}`}
          >
            <div className="flex items-start gap-3 mb-3">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-bold shrink-0"
                style={{ backgroundColor: story.avatar_color ?? "#4CAF50" }}
              >
                {story.avatar_initials ?? story.name.slice(0, 2).toUpperCase()}
              </div>
              <div>
                <p className="font-semibold text-sm">{story.name}</p>
                <p className="text-xs text-muted-foreground">{story.neighborhood} • {story.category}</p>
              </div>
              <BookOpen className="w-4 h-4 text-muted-foreground ml-auto" />
            </div>
            <p className="text-sm text-foreground leading-relaxed italic">"{story.story}"</p>
            <p className="text-xs text-muted-foreground mt-3">{new Date(story.created_at).toLocaleDateString("en-US", { month: "long", year: "numeric" })}</p>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}

export default function CommunityPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: pendingRequests } = useListFundRequests({ status: "open" }, {
    query: { queryKey: getListFundRequestsQueryKey({ status: "open" }) },
  });
  const approveFund = useApproveFundRequest();
  const denyFund = useDenyFundRequest();

  function handleApprove(id: number) {
    approveFund.mutate({ id }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListFundRequestsQueryKey() });
        qc.invalidateQueries({ queryKey: getGetCommunityFundQueryKey() });
        toast({ title: "Request approved and funded!" });
      },
    });
  }

  function handleDeny(id: number) {
    denyFund.mutate({ id }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListFundRequestsQueryKey() });
        toast({ title: "Request denied." });
      },
    });
  }

  return (
    <div className="pb-8">
      <div className="mb-6">
        <h1 className="font-serif text-2xl font-bold mb-1">Community Hub</h1>
        <p className="text-sm text-muted-foreground">Fort Worth neighbors coming together</p>
      </div>

      {/* Admin: Pending fund requests */}
      {user && (user.role === "admin" || user.role === "county") && (pendingRequests ?? []).length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
          <h3 className="font-semibold text-amber-800 mb-3 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" />
            Pending Fund Requests ({pendingRequests?.length})
          </h3>
          <div className="space-y-2">
            {(pendingRequests ?? []).map((req) => (
              <div key={req.id} className="flex items-center justify-between bg-white rounded-lg p-3 border border-amber-100">
                <div>
                  <p className="text-sm font-medium">{req.title}</p>
                  <p className="text-xs text-muted-foreground">{req.neighborhood} • {req.budget ? `$${req.budget}` : "No budget"}</p>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-red-600 border-red-200 hover:bg-red-50 h-7 text-xs"
                    onClick={() => handleDeny(req.id)}
                    data-testid={`button-deny-${req.id}`}
                  >
                    <XCircle className="w-3.5 h-3.5 mr-1" /> Deny
                  </Button>
                  <Button
                    size="sm"
                    className="h-7 text-xs"
                    onClick={() => handleApprove(req.id)}
                    data-testid={`button-approve-${req.id}`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Approve
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <Tabs defaultValue="fund">
        <TabsList className="w-full flex overflow-x-auto gap-0.5 mb-6 h-auto p-1 justify-start sm:justify-center">
          <TabsTrigger value="fund" className="shrink-0 text-xs sm:text-sm" data-testid="tab-fund">Fund</TabsTrigger>
          <TabsTrigger value="pay-forward" className="shrink-0 text-xs sm:text-sm whitespace-nowrap" data-testid="tab-pay-forward">Pay It Forward</TabsTrigger>
          <TabsTrigger value="impact" className="shrink-0 text-xs sm:text-sm" data-testid="tab-impact">Impact</TabsTrigger>
          <TabsTrigger value="sponsors" className="shrink-0 text-xs sm:text-sm" data-testid="tab-sponsors">Sponsors</TabsTrigger>
          <TabsTrigger value="stories" className="shrink-0 text-xs sm:text-sm" data-testid="tab-stories">Stories</TabsTrigger>
        </TabsList>
        <TabsContent value="fund"><FundTab /></TabsContent>
        <TabsContent value="pay-forward"><PayForwardTab /></TabsContent>
        <TabsContent value="impact"><ImpactTab /></TabsContent>
        <TabsContent value="sponsors"><SponsorsTab /></TabsContent>
        <TabsContent value="stories"><StoriesTab /></TabsContent>
      </Tabs>
    </div>
  );
}
