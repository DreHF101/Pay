import { pgTable, serial, text, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const communityFundTable = pgTable("community_fund", {
  id: serial("id").primaryKey(),
  city_id: text("city_id").notNull().default("fort-worth-tx"),
  balance: real("balance").notNull().default(0),
  total_contributed: real("total_contributed").notNull().default(0),
  total_disbursed: real("total_disbursed").notNull().default(0),
  people_helped: integer("people_helped").notNull().default(0),
  hours_donated: integer("hours_donated").notNull().default(0),
  requests_funded: integer("requests_funded").notNull().default(0),
  neighbors_helped: integer("neighbors_helped").notNull().default(0),
  rides_provided: integer("rides_provided").notNull().default(0),
  meals_delivered: integer("meals_delivered").notNull().default(0),
  emergency_responses: integer("emergency_responses").notNull().default(0),
  repeat_connections: integer("repeat_connections").notNull().default(0),
  households_supported: integer("households_supported").notNull().default(0),
  mentorship_relationships: integer("mentorship_relationships").notNull().default(0),
  families_assisted: integer("families_assisted").notNull().default(0),
  updated_at: timestamp("updated_at").notNull().defaultNow(),
});

export const payForwardLogTable = pgTable("pay_forward_log", {
  id: serial("id").primaryKey(),
  from_user_id: integer("from_user_id").notNull().references(() => usersTable.id),
  amount: real("amount").notNull(),
  note: text("note"),
  created_at: timestamp("created_at").notNull().defaultNow(),
});

export const insertPayForwardLogSchema = createInsertSchema(payForwardLogTable).omit({ id: true, created_at: true });
export type InsertPayForwardLog = z.infer<typeof insertPayForwardLogSchema>;
export type PayForwardLog = typeof payForwardLogTable.$inferSelect;
