import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { requestsTable } from "./requests";

export const jobsTable = pgTable("jobs", {
  id: serial("id").primaryKey(),
  request_id: integer("request_id").notNull().references(() => requestsTable.id),
  helper_id: integer("helper_id").notNull().references(() => usersTable.id),
  status: text("status").notNull().default("accepted"), // accepted | in_progress | completed | cancelled
  notes: text("notes"),
  completed_at: timestamp("completed_at"),
  created_at: timestamp("created_at").notNull().defaultNow(),
  updated_at: timestamp("updated_at").notNull().defaultNow(),
});

export const insertJobSchema = createInsertSchema(jobsTable).omit({ id: true, created_at: true, updated_at: true });
export type InsertJob = z.infer<typeof insertJobSchema>;
export type Job = typeof jobsTable.$inferSelect;
