import { pgTable, serial, text, integer, boolean, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const requestsTable = pgTable("requests", {
  id: serial("id").primaryKey(),
  requester_id: integer("requester_id").notNull().references(() => usersTable.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  neighborhood: text("neighborhood").notNull().default("Fort Worth"),
  city_id: text("city_id").notNull().default("fort-worth-tx"),
  urgency: text("urgency").notNull().default("normal"), // low | normal | urgent | emergency
  status: text("status").notNull().default("open"), // open | in_progress | funded | completed | cancelled
  budget: real("budget"),
  funding_source: text("funding_source").notNull().default("direct"), // direct | community_fund | pay_forward | volunteer
  recurring: text("recurring").notNull().default("one_time"),
  is_anonymous: boolean("is_anonymous").notNull().default(false),
  is_business: boolean("is_business").notNull().default(false),
  business_name: text("business_name"),
  scheduled_for: text("scheduled_for"),
  repayment_timeline: text("repayment_timeline"),
  lat: real("lat"),
  lng: real("lng"),
  created_at: timestamp("created_at").notNull().defaultNow(),
  updated_at: timestamp("updated_at").notNull().defaultNow(),
});

export const insertRequestSchema = createInsertSchema(requestsTable).omit({ id: true, created_at: true, updated_at: true });
export type InsertRequest = z.infer<typeof insertRequestSchema>;
export type Request = typeof requestsTable.$inferSelect;
