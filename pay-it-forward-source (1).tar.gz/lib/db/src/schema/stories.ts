import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const impactStoriesTable = pgTable("impact_stories", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").references(() => usersTable.id),
  name: text("name").notNull(),
  neighborhood: text("neighborhood").notNull(),
  story: text("story").notNull(),
  category: text("category").notNull(),
  avatar_color: text("avatar_color"),
  avatar_initials: text("avatar_initials"),
  created_at: timestamp("created_at").notNull().defaultNow(),
});

export const insertImpactStorySchema = createInsertSchema(impactStoriesTable).omit({ id: true, created_at: true });
export type InsertImpactStory = z.infer<typeof insertImpactStorySchema>;
export type ImpactStory = typeof impactStoriesTable.$inferSelect;
