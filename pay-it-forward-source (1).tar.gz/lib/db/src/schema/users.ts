import { pgTable, serial, text, integer, boolean, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  password_hash: text("password_hash").notNull(),
  role: text("role").notNull().default("neighbor"), // neighbor | admin | county
  trust_level: text("trust_level").notNull().default("newcomer"),
  emergency_role: text("emergency_role"),
  availability: text("availability").default("Available Now"),
  service_radius: integer("service_radius").default(10),
  services_offered: text("services_offered"),
  neighborhood: text("neighborhood").notNull().default("Fort Worth"),
  city_id: text("city_id").notNull().default("fort-worth-tx"),
  bio: text("bio"),
  avatar_initials: text("avatar_initials"),
  avatar_color: text("avatar_color").default("#4CAF50"),
  help_count: integer("help_count").notNull().default(0),
  request_count: integer("request_count").notNull().default(0),
  volunteer_hours: integer("volunteer_hours").notNull().default(0),
  community_balance: real("community_balance").notNull().default(0),
  sponsored_balance: real("sponsored_balance").notNull().default(0),
  pay_forward_total: real("pay_forward_total").notNull().default(0),
  is_verified: boolean("is_verified").notNull().default(false),
  email_verified: boolean("email_verified").notNull().default(false),
  phone_verified: boolean("phone_verified").notNull().default(false),
  id_verified: boolean("id_verified").notNull().default(false),
  background_checked: boolean("background_checked").notNull().default(false),
  community_trusted: boolean("community_trusted").notNull().default(false),
  reliability_pct: integer("reliability_pct").notNull().default(90),
  lat: real("lat"),
  lng: real("lng"),
  created_at: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, created_at: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
