import { pgTable, serial, text, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { jobsTable } from "./jobs";

export const pledgesTable = pgTable("pledges", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => usersTable.id),
  source_job_id: integer("source_job_id").notNull().references(() => jobsTable.id),
  original_amount: real("original_amount").notNull(),
  amount_returned: real("amount_returned").notNull().default(0),
  status: text("status").notNull().default("open"), // open | partial | fulfilled
  repayment_timeline: text("repayment_timeline"),
  created_at: timestamp("created_at").notNull().defaultNow(),
});

export const pledgeRepaymentsTable = pgTable("pledge_repayments", {
  id: serial("id").primaryKey(),
  pledge_id: integer("pledge_id").notNull().references(() => pledgesTable.id),
  amount: real("amount").notNull(),
  note: text("note"),
  created_at: timestamp("created_at").notNull().defaultNow(),
});

export const insertPledgeSchema = createInsertSchema(pledgesTable).omit({ id: true, created_at: true });
export type InsertPledge = z.infer<typeof insertPledgeSchema>;
export type Pledge = typeof pledgesTable.$inferSelect;
