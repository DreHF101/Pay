import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { requestsTable } from "./requests";

export const gratitudeTable = pgTable("gratitude", {
  id: serial("id").primaryKey(),
  request_id: integer("request_id").notNull().references(() => requestsTable.id),
  from_user_id: integer("from_user_id").notNull().references(() => usersTable.id),
  to_user_id: integer("to_user_id").references(() => usersTable.id),
  message: text("message").notNull(),
  is_public: boolean("is_public").notNull().default(true),
  created_at: timestamp("created_at").notNull().defaultNow(),
});

export const insertGratitudeSchema = createInsertSchema(gratitudeTable).omit({ id: true, created_at: true });
export type InsertGratitude = z.infer<typeof insertGratitudeSchema>;
export type Gratitude = typeof gratitudeTable.$inferSelect;
